"use client";

import { createContext, useContext, useEffect, useState } from "react";

const API_URL = (process.env.NEXT_PUBLIC_SAIL_API_URL || "http://127.0.0.1:8000").replace(/\/+$/, "");

const ProjectContext = createContext(null);

export function ProjectProvider({ children }) {
  const [activeProject, setActiveProjectState] = useState(null);
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    fetch(`${API_URL}/projects`).then((response) => response.ok ? response.json() : null).then((data) => {
      if (Array.isArray(data?.projects)) { setProjects(data.projects); localStorage.setItem("sail-project-cache", JSON.stringify(data.projects)); }
      else { const cached = JSON.parse(localStorage.getItem("sail-project-cache") || "[]"); setProjects(cached); }
    }).catch(() => { try { setProjects(JSON.parse(localStorage.getItem("sail-project-cache") || "[]")); } catch {} });
  }, []);

  useEffect(() => {
    const savedId = localStorage.getItem("sail-active-project");
    if (!savedId || activeProject) return;
    const savedName = localStorage.getItem("sail-active-project-name");
    // An older backend may have recreated project IDs while retaining the
    // user's project names. Fall back only to one exact name match.
    const byName = savedName ? projects.filter((project) => project.name === savedName) : [];
    const savedProject = projects.find((project) => project.id === savedId) || (byName.length === 1 ? byName[0] : null);
    if (savedProject) {
      const timer = setTimeout(() => setActiveProjectState(savedProject), 0);
      return () => clearTimeout(timer);
    }
  }, [activeProject, projects]);

  function setActiveProject(project) {
    setActiveProjectState(project);
    if (project) {
      localStorage.setItem("sail-active-project", project.id);
      localStorage.setItem("sail-active-project-name", project.name);
    } else {
      localStorage.removeItem("sail-active-project");
      localStorage.removeItem("sail-active-project-name");
    }
  }

  function updateProjects(updater) {
    setProjects((current) => {
      const next = typeof updater === "function" ? updater(current) : updater;
      localStorage.setItem("sail-project-cache", JSON.stringify(next));
      fetch(`${API_URL}/projects`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(next) }).catch(() => {});
      return next;
    });
  }

  async function deleteProject(id) {
    const response = await fetch(`${API_URL}/projects/${encodeURIComponent(id)}`, { method: "DELETE" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Project outputs could not be deleted.");
    setProjects(data.projects);
    localStorage.setItem("sail-project-cache", JSON.stringify(data.projects));
    if (activeProject?.id === id) setActiveProject(null);
  }

  return (
    <ProjectContext.Provider value={{ activeProject, setActiveProject, projects, updateProjects, deleteProject }}>
      {children}
    </ProjectContext.Provider>
  );
}

export function useActiveProject() {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error("useActiveProject must be used within ProjectProvider");
  return ctx;
}
