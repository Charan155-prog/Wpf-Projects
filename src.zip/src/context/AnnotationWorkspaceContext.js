"use client";

import { createContext, useCallback, useContext, useState } from "react";

const AnnotationWorkspaceContext = createContext(null);

export function AnnotationWorkspaceProvider({ children }) {
  const [workspaces, setWorkspaces] = useState({});

  const saveWorkspace = useCallback((projectId, workspace) => {
    setWorkspaces((current) => ({ ...current, [projectId]: workspace }));
  }, []);

  const clearWorkspace = useCallback((projectId) => {
    setWorkspaces((current) => {
      const next = { ...current };
      delete next[projectId];
      return next;
    });
  }, []);

  return (
    <AnnotationWorkspaceContext.Provider value={{ workspaces, saveWorkspace, clearWorkspace }}>
      {children}
    </AnnotationWorkspaceContext.Provider>
  );
}

export function useAnnotationWorkspace() {
  const context = useContext(AnnotationWorkspaceContext);
  if (!context) throw new Error("useAnnotationWorkspace must be used within AnnotationWorkspaceProvider");
  return context;
}
