import TrainingPage from "@/components/training/TrainingPage";

export default function Training() {
  return <TrainingPage />;
}
