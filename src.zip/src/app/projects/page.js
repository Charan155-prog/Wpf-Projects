import ProjectManagement from "@/components/projects/ProjectManagement";

export default function Projects() {
  return <ProjectManagement />;
}
