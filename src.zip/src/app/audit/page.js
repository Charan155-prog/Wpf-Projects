"use client";

import { motion } from "framer-motion";
import { useAuditLogs } from "@/hooks/useAuditLogs";
import AuditHeader from "@/components/audit/AuditHeader";
import AuditFilters from "@/components/audit/AuditFilters";
import AuditTable from "@/components/audit/AuditTable";
import { PAGE_PLACEHOLDERS } from "@/config/constants";

export default function AuditPage() {
  const content = PAGE_PLACEHOLDERS.audit;
  const {
    paginatedLogs,
    loading,
    stats,
    totalFiltered,
    totalLogs,
    page, setPage,
    pageSize, setPageSize,
    searchTerm, setSearchTerm,
    filterModule, setFilterModule,
    filterLevel, setFilterLevel,
    fromDate, handleFromDateChange,
    toDate, handleToDateChange,
    activeDateShortcut, setDateShortcut,
    clearFilters,
  } = useAuditLogs();

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col md:h-full w-full mx-auto pb-1"
    >
      <AuditHeader
        title={content.title}
        description={content.description}
        stats={stats}
      />

      <AuditFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        filterModule={filterModule}
        setFilterModule={setFilterModule}
        filterLevel={filterLevel}
        setFilterLevel={setFilterLevel}
        fromDate={fromDate}
        handleFromDateChange={handleFromDateChange}
        toDate={toDate}
        handleToDateChange={handleToDateChange}
        activeDateShortcut={activeDateShortcut}
        setDateShortcut={setDateShortcut}
        filteredEntries={totalFiltered}
        totalEntries={totalLogs}
        clearFilters={clearFilters}
      />

      <AuditTable
        logs={paginatedLogs}
        loading={loading}
        page={page}
        pageSize={pageSize}
        totalFiltered={totalFiltered}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
      />
    </motion.div>
  );
}
