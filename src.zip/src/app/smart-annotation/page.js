import SmartAnnotationPage from "@/components/smart-annotation/SmartAnnotationPage";

export default function SmartAnnotation() {
  return <SmartAnnotationPage />;
}
