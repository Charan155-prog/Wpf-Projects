import ModelsPage from "@/components/models/TrainedModelsPage";

export default function Models() {
  return <ModelsPage />;
}
