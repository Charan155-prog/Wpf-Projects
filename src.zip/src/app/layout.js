import "./globals.css";
import { ThemeProvider } from "@/context/ThemeContext";
import { ProjectProvider } from "@/context/ProjectContext";
import { AnnotationWorkspaceProvider } from "@/context/AnnotationWorkspaceContext";
import AppLayout from "@/components/layout/AppLayout";

import { APP_CONFIG } from "@/config/constants";

export const metadata = {
  title: APP_CONFIG.name,
  description: APP_CONFIG.description,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="dark">
      <body suppressHydrationWarning>
        <ThemeProvider>
          <ProjectProvider>
            <AnnotationWorkspaceProvider>
              <AppLayout>
                {children}
              </AppLayout>
            </AnnotationWorkspaceProvider>
          </ProjectProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
