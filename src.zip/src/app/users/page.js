"use client";

import { motion } from "framer-motion";
import { useUserManagement } from "@/hooks/useUserManagement";
import { usePermissions } from "@/hooks/usePermissions";
import { useSecuritySettings } from "@/hooks/useSecuritySettings";
import UserManagementLayout from "@/components/users/UserManagementLayout";

export default function UsersPage() {
  const {
    filteredUsers,
    stats,
    searchTerm,
    setSearchTerm,
    viewMode,
    setViewMode,
    activeTab,
    setActiveTab,
    addUser,
    deleteUser,
    updateUser,
  } = useUserManagement();

  const {
    permissions,
    selectedRole,
    setSelectedRole,
    togglePermission,
    savePermissions,
    hasChanges: permissionsHasChanges,
  } = usePermissions();

  const {
    settings,
    updateSetting,
    saveSettings,
    hasChanges: securityHasChanges,
  } = useSecuritySettings();

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="w-full md:h-full flex flex-col"
    >
      <UserManagementLayout
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        filteredUsers={filteredUsers}
        stats={stats}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        viewMode={viewMode}
        setViewMode={setViewMode}
        addUser={addUser}
        deleteUser={deleteUser}
        updateUser={updateUser}
        permissions={permissions}
        selectedRole={selectedRole}
        setSelectedRole={setSelectedRole}
        togglePermission={togglePermission}
        savePermissions={savePermissions}
        permissionsHasChanges={permissionsHasChanges}
        settings={settings}
        updateSetting={updateSetting}
        saveSettings={saveSettings}
        securityHasChanges={securityHasChanges}
      />
    </motion.div>
  );
}
