import DatasetManagement from "@/components/datasets/DatasetManagement";

export default function Datasets() {
  return <DatasetManagement />;
}
