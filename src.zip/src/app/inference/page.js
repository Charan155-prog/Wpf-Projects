import InferencePage from "@/components/inference/LiveInferencePage";

export default function Inference() {
  return <InferencePage />;
}
