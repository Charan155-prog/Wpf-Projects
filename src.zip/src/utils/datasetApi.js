export const DATASET_API = (process.env.NEXT_PUBLIC_SAIL_API_URL || "http://127.0.0.1:8000").trim().replace(/\/+$/, "");
export function assetUrl(path) { return path ? `${DATASET_API}${path}` : ""; }
export async function datasetRequest(path, options = {}) {
  const response = await fetch(`${DATASET_API}${path}`, { cache: "no-store", ...options, headers: { "Content-Type": "application/json", ...options.headers } });
  if (response.status === 404 && ["/datasets", "/training/datasets", "/training/runs", "/models"].includes(path)) {
    throw new Error(`The backend at ${DATASET_API} does not provide ${path}. Copy the updated complete backend folder (including routers, services and ml), restart it, and check NEXT_PUBLIC_SAIL_API_URL points to that server.`);
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof payload.detail === "string" ? payload.detail : "The request could not be completed. Check your input and try again.");
  return payload;
}
