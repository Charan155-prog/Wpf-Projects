import {
  FolderOpen,
  Database,
  Brain,
  Wand2,
  Boxes,
  ScanLine,
  Settings,
  Users,
  ClipboardList
} from "lucide-react";

export const APP_CONFIG = {
  name: "Smart Annotation & Incremental Learning",
  companyName: "Emage Group",
  brandTitle: "Smart Annotation",
  brandSubtitle: "& Incremental Learning",
  shortName: "SAIL",
  description: "Annotation & Incremental Learning Platform",
};

export const NAVIGATION = [
  {
    category: "Pipeline",
    items: [
      { name: "Projects",         href: "/projects",         icon: FolderOpen },
      { name: "Smart Annotation", href: "/smart-annotation", icon: Wand2 },
      { name: "Datasets",         href: "/datasets",         icon: Database },
      { name: "Training",         href: "/training",         icon: Brain },
      { name: "Models",           href: "/models",           icon: Boxes },
      { name: "Inference",        href: "/inference",        icon: ScanLine },
    ]
  },
  {
    category: "Administration",
    items: [
      { name: "User Management", href: "/users",    icon: Users },
      { name: "Audit Trail",     href: "/audit",    icon: ClipboardList },
      { name: "Settings",        href: "/settings", icon: Settings },
    ]
  }
];

export const PAGE_PLACEHOLDERS = {
  projects: {
    title: "Projects",
    description: "Manage your computer vision projects, tracking experiments and deployments.",
  },
  datasets: {
    title: "Datasets",
    description: "Upload, version, and manage the image datasets for your models.",
  },
  training: {
    title: "Training",
    description: "Train new models or fine-tune existing ones with custom configurations.",
  },
  models: {
    title: "Models Registry",
    description: "View, manage, and export your trained machine learning models.",
  },
  users: {
    title: "User Management",
    description: "Manage roles, permissions, and access control for your team.",
  },
  audit: {
    title: "Audit Trail",
    description: "View system logs, user actions, and security events.",
  },
  settings: {
    title: "Settings",
    description: "Configure application preferences, user access, and pipeline defaults.",
  },
};
