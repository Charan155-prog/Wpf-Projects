"use client";
import { useCallback, useEffect, useState } from "react";
import { Play, RefreshCw, Download, FolderOpen, FileVideo, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { useActiveProject } from "@/context/ProjectContext";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";

import SidePanel from "@/components/ui/SidePanel";
import Modal from "@/components/ui/Modal";

const active = (r) => ["queued", "waiting", "running"].includes(r?.state);

// Small "type a page number and jump" control, dropped in next to the
// Prev/Next pager buttons wherever there are multiple pages of results.
function PageJump({ page, pages, onJump }) {
  if (pages <= 1) return <span>{page} / {pages}</span>;
  function commit(e) {
    const n = Math.min(pages, Math.max(1, Math.round(Number(e.target.value)) || page));
    if (n !== page) onJump(n);
    e.target.value = n;
  }
  return <span className="flex items-center gap-1">
    <input
      key={page}
      type="number"
      min={1}
      max={pages}
      defaultValue={page}
      aria-label="Jump to page"
      onKeyDown={(e) => { if (e.key === "Enter") e.target.blur(); }}
      onBlur={commit}
      className="w-12 rounded border border-[var(--border-color)] bg-[var(--bg-hover)] px-1 py-0.5 text-center text-xs"
    />
    <span>/ {pages}</span>
  </span>;
}
export default function LiveInferencePage() {
  const { activeProject } = useActiveProject();
  return <Inference key={activeProject?.id || "none"} project={activeProject} />;
}
function Inference({ project }) {
  const [models, setModels] = useState([]), [runs, setRuns] = useState([]);
  const [modelId, setModelId] = useState(""), [sourcePath, setSourcePath] = useState("");
  const [confidence, setConfidence] = useState(.9), [iou, setIou] = useState(.45);
  const [imageSize, setImageSize] = useState(640), [drawBoxes, setDrawBoxes] = useState(true);
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  const [runId, setRunId] = useState("");
  // Once a new model or input is picked, the previous run's outputs must not
  // keep showing on the main page — hide them until Run Inference is clicked.
  const [awaitingRun, setAwaitingRun] = useState(false);
  const [inputOpen, setInputOpen] = useState(false), [controlsOpen, setControlsOpen] = useState(false);
  const [uploading, setUploading] = useState(false), [refreshing, setRefreshing] = useState(false);
  const [refreshVersion, setRefreshVersion] = useState(0), [notice, setNotice] = useState("");
  async function manualRefresh() {
    setRefreshing(true); setNotice("");
    try { const ok = await refresh(); setRefreshVersion((v) => v + 1); setNotice(ok ? "Refreshed" : "Refresh failed"); }
    finally { setRefreshing(false); }
  }
  // Wrap every place a *new* model/input is chosen so the previously shown
  // run gets hidden immediately, rather than waiting for the next poll.
  function selectModel(id) { setModelId(id); setRunId(""); setAwaitingRun(true); }
  function selectSource(path) { setSourcePath(path); setRunId(""); setAwaitingRun(true); }
  async function upload(event) {
    const files = Array.from(event.target.files || []);
    if (!files.length) return;
    setUploading(true); setError(""); setNotice(""); setSourcePath(""); setRunId(""); setAwaitingRun(true);
    try {
      const body = new FormData(); files.forEach((file) => body.append("files", file));
      const response = await fetch(assetUrl("/inference/inputs"), { method: "POST", body });
      const result = await response.json();
      if (!response.ok) throw new Error(typeof result.detail === "string" ? result.detail : "Media upload failed.");
      selectSource(result.path); setNotice(`${result.count} input file(s) ready`);
    } catch (e) { setError(e.message); }
    finally { setUploading(false); event.target.value = ""; }
  }
  const matches = (item) => project && [project.name, project.name.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._]+|[._]+$/g, "")].includes(item.projectName);
  const refresh = useCallback(async () => {
    try {
      const [m, r] = await Promise.all([datasetRequest("/models"), datasetRequest("/inference/runs")]);
      setModels(m.items); setRuns(r.items);
      return true;
    } catch (e) { setError(e.message); return false; }
  }, []);
  useEffect(() => {
    const first = setTimeout(() => { const id = new URLSearchParams(window.location.search).get("model"); if (id) setModelId(id); refresh(); }, 0);
    const timer = setInterval(refresh, 5000);
    return () => { clearTimeout(first); clearInterval(timer); };
  }, [refresh]);
  const available = models.filter(matches), history = runs.filter(matches);
  const model = available.find((m) => m.id === modelId);
  const current = awaitingRun ? null : (history.find((r) => r.id === runId) || history[0]);
  async function start(e) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const run = await datasetRequest("/inference/runs", { method: "POST", body: JSON.stringify({ modelId, sourcePath, confidence: Number(confidence), iou: Number(iou), imageSize: Number(imageSize), drawBoxes, maskAlpha: .35 }) });
      setRunId(run.id); setAwaitingRun(false); await refresh();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  const field = "w-full px-2.5 py-2 text-xs rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)]";
  const controls = <div className="space-y-4">
    <form onSubmit={start} className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <label className="text-xs space-y-1 block">Confidence<input required className={field} type="number" min="0.01" max="1" step="0.01" value={confidence} onChange={(e) => setConfidence(e.target.value)} /></label>
        <label className="text-xs space-y-1 block">NMS IoU<input required className={field} type="number" min="0.01" max="1" step="0.01" value={iou} onChange={(e) => setIou(e.target.value)} /></label>
      </div>
      <label className="block text-xs space-y-1">Image size<select className={field} value={imageSize} onChange={(e) => setImageSize(e.target.value)}>{[320, 480, 640, 960, 1280].map((n) => <option key={n}>{n}</option>)}</select></label>
      <label className="flex gap-2 items-center text-xs"><input type="checkbox" checked={drawBoxes} onChange={(e) => setDrawBoxes(e.target.checked)} />Draw boxes</label>
      {model && <p className="text-xs capitalize break-words">{model.mode} · {model.classes.join(", ")}</p>}
      <p className="text-xs truncate text-[var(--text-secondary)]" title={sourcePath}>{sourcePath || "No input selected"}</p>
      <button disabled={busy || uploading || !model || !sourcePath.trim()} className="w-full flex justify-center items-center gap-2 bg-[var(--accent-500)] text-white rounded-lg py-2 text-xs font-semibold disabled:opacity-40"><Play size={14} />{uploading ? "Uploading…" : busy ? "Starting…" : !model ? "Select a model" : !sourcePath.trim() ? "Choose input media" : "Start inference"}</button>
    </form>
    {/* Selecting a past run must also clear awaitingRun — otherwise a run
        picked here still renders as empty while awaitingRun is left over
        from an earlier model/input change. */}
    {!!history.length && <label className="block text-xs space-y-1">Run history<select aria-label="Inference history" className={field} value={current?.id || ""} onChange={(e) => { setRunId(e.target.value); setAwaitingRun(false); }}>{history.map((r) => <option key={r.id} value={r.id}>{r.name} · {r.modelName} · {r.state} · {new Date(r.createdAt).toLocaleString()}</option>)}</select></label>}
  </div>;
  return <section className="surface rounded-xl h-full min-h-0 flex flex-col overflow-hidden">
    <header className="flex shrink-0 items-center gap-2 border-b border-[var(--border-color)] px-3 py-2">
      <h1 className="text-sm font-bold">Inference</h1><span className="truncate text-xs font-semibold">{project?.name || "Select a project"}</span>
      <span role="status" className="ml-auto text-xs">{notice}</span><button className="p-1 rounded hover:bg-[var(--bg-hover)]" aria-label="Refresh inference" disabled={refreshing} onClick={manualRefresh}><RefreshCw size={16} className={refreshing ? "animate-spin" : ""} /></button>
    </header>
    <div className="flex shrink-0 flex-wrap items-center gap-2 px-3 py-2">
      <select aria-label="Trained model" title={model?.filename || "Trained model"} className={field + " !w-auto min-w-0 max-w-full sm:max-w-[50%]"} value={model ? modelId : ""} onChange={(e) => selectModel(e.target.value)}><option value="">Select trained model</option>{available.map((m) => <option key={m.id} value={m.id}>{m.filename || `${m.name}_${m.mode}_${m.id.slice(0,8)}_best.pt`}</option>)}</select>
      <button onClick={() => setInputOpen(true)} title={sourcePath || "Select input media"} className="rounded-lg border border-[var(--border-color)] px-3 py-2 text-xs font-semibold">Load Inference Input{sourcePath ? " ✓" : ""}</button>
      <button onClick={() => setControlsOpen(!controlsOpen)} aria-expanded={controlsOpen} className="inline-flex items-center gap-1.5 rounded-lg bg-[var(--accent-500)] text-white px-3 py-2 text-xs font-semibold"><Play size={13} />Run Inference</button>
    </div>
    {error && <p role="alert" className="px-3 text-xs text-red-400">{error}</p>}
    {!available.length && <p className="px-3 text-xs">No completed models for this project.</p>}
    <Run key={current?.id || "empty"} id={current?.id} refreshVersion={refreshVersion} onFinished={refresh} onDeleted={() => { setRunId(""); refresh(); }} controls={controls} controlsOpen={controlsOpen} closeControls={() => setControlsOpen(false)} />
    <Modal open={inputOpen} onClose={() => setInputOpen(false)} title="Inference Input" size="lg">
      <InputBrowser sourcePath={sourcePath} setSourcePath={selectSource} field={field} />
      <label className="block mt-4 text-xs">{uploading ? "Uploading media to GPU PC…" : "Upload input from this PC"}<input disabled={uploading || busy} type="file" multiple accept="image/*,video/*" onChange={upload} className="block mt-2 text-xs max-w-full" /></label>
      {error && <p role="alert" className="mt-2 text-xs text-red-400">{error}</p>}
      <button disabled={uploading} onClick={() => setInputOpen(false)} className="mt-4 rounded-lg bg-[var(--accent-500)] px-4 py-2 text-xs text-white disabled:opacity-40">Done</button>
    </Modal>
  </section>;
}

function InputBrowser({ sourcePath, setSourcePath, field }) {
  const [listing, setListing] = useState(null), [kind, setKind] = useState("folder");
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  async function browse(path, mode = kind, page = 1) {
    setBusy(true); setError(""); setKind(mode);
    try { setListing(await datasetRequest(`/inference/browse?path=${encodeURIComponent(path)}&kind=${mode}&page=${page}`)); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  return <div className="space-y-3">
    <label className="block text-xs" htmlFor="inference-source">Input path on backend PC</label>
    <div className="flex gap-1 items-center">
      <input id="inference-source" className={field + " min-w-0 font-mono"} value={sourcePath} onChange={(e) => setSourcePath(e.target.value)} placeholder="Paste image folder, image or video path" />
      <button disabled={busy} onClick={() => browse(sourcePath, "folder")} aria-label="Choose image folder" title="Browse backend image folders" className="p-2 rounded-lg hover:bg-[var(--bg-hover)]"><FolderOpen size={18} /></button>
      <button disabled={busy} onClick={() => browse(sourcePath, "media")} aria-label="Choose image or video" title="Browse backend images/videos" className="p-2 rounded-lg hover:bg-[var(--bg-hover)]"><FileVideo size={18} /></button>
    </div>
    {busy && <p role="status" className="text-xs">Loading folders…</p>}
    {error && <p role="alert" className="text-xs text-red-400">{error}</p>}
    {listing && <div className="border border-[var(--border-color)] rounded-lg p-2 space-y-2 text-xs">
      <div className="flex gap-2 items-center"><button disabled={busy || listing.path === listing.parent} onClick={() => browse(listing.parent)} className="p-1 rounded border border-[var(--border-color)] disabled:opacity-40">Up</button><select aria-label="Backend drive" value={listing.roots.find((root) => listing.path.replaceAll("\\", "/").toLowerCase().startsWith(root.toLowerCase())) || listing.roots[0]} onChange={(e) => browse(e.target.value)} className="rounded bg-[var(--bg-hover)] p-1">{listing.roots.map((root) => <option key={root}>{root}</option>)}</select><span className="truncate" title={listing.path}>{listing.path}</span></div>
      <div className="max-h-52 overflow-auto">{listing.items.map((item) => <button key={item.path} disabled={busy} onClick={() => item.directory ? browse(item.path) : (setSourcePath(item.path), setListing(null))} className="w-full flex items-center gap-2 text-left p-2 rounded hover:bg-[var(--bg-hover)]">{item.directory ? <FolderOpen size={14} /> : <FileVideo size={14} />}<span className="truncate">{item.name}</span></button>)}{!listing.items.length && <p className="p-2">No matching files or folders.</p>}</div>
      {listing.total > 200 && <div className="flex justify-center gap-3"><button disabled={busy || listing.page === 1} onClick={() => browse(listing.path, kind, listing.page - 1)}>Previous</button><span>{listing.page} / {Math.ceil(listing.total / 200)}</span><button disabled={busy || listing.page * 200 >= listing.total} onClick={() => browse(listing.path, kind, listing.page + 1)}>Next</button></div>}
      {kind === "folder" && <button onClick={() => { setSourcePath(listing.path); setListing(null); }} className="rounded bg-[var(--accent-500)] text-white px-3 py-2">Use this image folder</button>}
    </div>}
  </div>;
}

function Run({ id, refreshVersion, onFinished, onDeleted, controls, controlsOpen, closeControls }) {
  const [run, setRun] = useState(null), [error, setError] = useState("");
  const [page, setPage] = useState(1), [expandedAsset, setExpandedAsset] = useState(null), [stopping, setStopping] = useState(false);
  const [carouselBusy, setCarouselBusy] = useState(false);
  const serverPage = Math.ceil(page / 4);
  useEffect(() => {
    if (!id) return;
    let live = true, timer;
    async function poll() {
      try {
        const r = await datasetRequest(`/inference/runs/${id}?page=${serverPage}`);
        if (!live) return;
        setRun(r); setError("");
        if (!active(r)) { setStopping(false); onFinished(); }
        if (active(r)) timer = setTimeout(poll, 1500);
      } catch (e) { if (live) { setError(e.message); timer = setTimeout(poll, 5000); } }
    }
    poll(); return () => { live = false; clearTimeout(timer); };
  }, [id, serverPage, refreshVersion, onFinished]);
  async function cancel() {
    setStopping(true);
    try { await datasetRequest(`/inference/runs/${id}/cancel`, { method: "POST" }); }
    catch (e) { setError(e.message); setStopping(false); }
  }
  async function removeAsset(asset) {
    if (!window.confirm(`Permanently delete “${asset.name}”? This cannot be undone.`)) return;
    try {
      await datasetRequest(`/inference/runs/${id}/asset/${asset.index}`, { method: "DELETE" });
      setExpandedAsset(null);
      const r = await datasetRequest(`/inference/runs/${id}?page=${serverPage}`); setRun(r);
    } catch (e) { setError(e.message); }
  }
  async function removeRun() {
    if (!window.confirm("Permanently delete this inference run and all of its output files? This cannot be undone.")) return;
    try { await datasetRequest(`/inference/runs/${id}`, { method: "DELETE" }); onDeleted(); }
    catch (e) { setError(e.message); }
  }
  async function openExpanded(asset) {
    setExpandedAsset(asset);
  }
  async function moveExpanded(direction) {
    if (!expandedAsset || !run || carouselBusy) return;
    const target = expandedAsset.index + direction;
    if (target < 0 || target >= (run.totalAssets || 0)) return;
    setCarouselBusy(true);
    try {
      // Result pages contain 24 assets. Fetch only the page containing the
      // neighbouring image, so carousel navigation is continuous across the
      // normal gallery's six-image page boundaries.
      const resultPage = Math.floor(target / 24) + 1;
      const payload = await datasetRequest(`/inference/runs/${id}?page=${resultPage}`);
      const raw = (payload.assets || [])[target % 24];
      if (!raw) throw new Error("The neighbouring output is no longer available.");
      setExpandedAsset({ ...raw, index: target });
    } catch (e) { setError(e.message); }
    finally { setCarouselBusy(false); }
  }
  const progress = run?.progress || {};
  const assets = (run?.assets || []).slice(((page - 1) % 4) * 6, ((page - 1) % 4 + 1) * 6).map((asset, offset) => ({ ...asset, index: (serverPage - 1) * 24 + ((page - 1) % 4) * 6 + offset }));
  const pages = Math.max(1, Math.ceil((run?.totalAssets || 0) / 6));
  const expanded = expandedAsset;
  const preview = run?.previewUrl && (!run.totalAssets || (run.sourceType === "video" && active(run)));
  return <div className="flex flex-1 min-h-0 flex-col md:flex-row">
    <div className="flex flex-1 min-w-0 min-h-0 flex-col">
      {error && <p role="alert" className="px-3 text-xs text-red-400">{error}</p>}
      <div className="flex-1 min-h-0 overflow-auto p-2">
        {preview ? <img src={assetUrl(`${run.previewUrl}?frame=${progress.processed}`)} className="h-full w-full object-contain bg-black/30 rounded-lg" alt={progress.current || "Last processed frame"} /> :
        assets.length ? <div className={`grid h-full min-h-0 gap-2 ${assets.length === 1 && assets[0].type === "video" ? "grid-cols-1 grid-rows-1" : "grid-cols-2 lg:grid-cols-3 grid-rows-3 lg:grid-rows-2"}`}>
          {assets.map((a) => <div key={a.url} className="group relative flex min-h-0 min-w-0 flex-col rounded-lg border border-[var(--border-color)] overflow-hidden">
            {a.type === "video" ? <video controls src={assetUrl(a.url)} className="flex-1 min-h-0 w-full bg-black object-contain" /> : <button onClick={() => openExpanded(a)} aria-label={`Expand ${a.name}`} className="relative flex-1 min-h-0 w-full bg-black/30"><img loading="lazy" src={assetUrl(a.url)} alt={a.name} className="absolute inset-0 h-full w-full object-contain" /></button>}
            <button onClick={() => removeAsset(a)} aria-label={`Delete ${a.name}`} title="Permanently delete output" className="absolute right-2 top-2 rounded bg-black/80 p-1.5 text-red-300 hover:bg-red-950"><Trash2 size={14} /></button>
            <a href={assetUrl(`${a.url}?download=true`)} title={`Download ${a.name}`} className="shrink-0 p-1.5 text-[11px] flex gap-1 items-center"><Download size={12} className="shrink-0" /><span className="truncate">{a.name}</span></a>
          </div>)}
        </div> : <div className="h-full flex items-center justify-center text-xs text-[var(--text-secondary)]">{id ? active(run) ? "Waiting for first output…" : "No processed outputs yet." : "Select a model and input to begin."}</div>}
      </div>
      <div className="flex shrink-0 items-center justify-center gap-3 border-t border-[var(--border-color)] px-3 py-2 text-xs">
        <button aria-label="Previous results" disabled={page <= 1} onClick={() => setPage(page - 1)} className="disabled:opacity-30"><ChevronLeft size={16} /></button>
        <PageJump page={page} pages={pages} onJump={setPage} />
        <button aria-label="Next results" disabled={page >= pages} onClick={() => setPage(page + 1)} className="disabled:opacity-30"><ChevronRight size={16} /></button>
        {run && <span className="ml-2 truncate capitalize">{stopping ? "Stopping…" : run.state} · {progress.processed || 0}/{progress.total || "—"}</span>}
      </div>
    </div>
    <SidePanel open={controlsOpen} onClose={closeControls} title="Run Inference">
      {controls}
      {run && <div className="mt-4 pt-3 border-t border-[var(--border-color)] space-y-3 text-xs">
        <div className="flex items-center gap-2"><strong className="capitalize">{stopping ? "Stopping…" : run.state}</strong>{active(run) ? <button disabled={stopping} onClick={cancel} className="ml-auto rounded-lg border border-red-400/50 px-3 py-1 text-red-400 disabled:opacity-40">Stop</button> : <button onClick={removeRun} className="ml-auto rounded-lg p-1.5 text-red-400 hover:bg-red-500/10" aria-label="Delete inference run" title="Permanently delete all output files"><Trash2 size={16} /></button>}</div>
        <p>{progress.processed || 0} / {progress.total || "—"} {run.sourceType === "video" ? "frames" : "images"} · {progress.objects || 0} objects</p>
        <progress aria-label="Inference progress" className="w-full h-2 accent-[var(--accent-500)]" value={progress.processed || 0} max={progress.total || 1} />
        {run.error && <p role="alert" className="text-red-400">{run.error}</p>}
        <details open><summary className="cursor-pointer font-semibold">Run details &amp; log</summary>
          <p className="mt-2 break-all">Input: {run.name}</p><p className="break-all">Model: {run.modelName}</p>
          <p>Started: {new Date(run.createdAt).toLocaleString()}</p>
          {progress.current && <p className="break-all">Current: {progress.current}</p>}
          {progress.elapsedSeconds != null && <p>Elapsed: {progress.elapsedSeconds}s</p>}
          <p className="font-mono text-[11px] break-all my-2">Output: {run.directory}</p>
          <pre aria-label="Inference log" className="max-h-64 overflow-auto whitespace-pre-wrap rounded bg-black/20 p-2 text-[11px]">{run.log || `${run.state}: ${progress.processed || 0}/${progress.total || "—"} processed. ${active(run) ? "Waiting for worker log…" : "No worker log was recorded for this older run."}`}</pre>
        </details>
      </div>}
    </SidePanel>
    {expanded && <div role="dialog" aria-modal="true" aria-label="Inference result" className="fixed inset-0 z-[110] flex items-center justify-center bg-black/95 p-6 sm:p-12">
      <button onClick={() => setExpandedAsset(null)} aria-label="Close" className="absolute right-4 top-4 rounded-lg bg-white/10 px-3 py-1.5 text-sm text-white">Close</button>
      <button onClick={() => removeAsset(expanded)} aria-label={`Delete ${expanded.name}`} title="Permanently delete output" className="absolute left-4 top-4 rounded-lg bg-red-500/20 p-2 text-red-300"><Trash2 size={16} /></button>
      {expanded.index > 0 && <button onClick={() => moveExpanded(-1)} aria-label="Previous image" className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-white sm:left-6"><ChevronLeft size={22} /></button>}
      {expanded.index < (run?.totalAssets || 0) - 1 && <button onClick={() => moveExpanded(1)} aria-label="Next image" className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-white sm:right-6"><ChevronRight size={22} /></button>}
      {expanded.type === "video" ? <video controls src={assetUrl(expanded.url)} className="max-h-[85vh] max-w-full object-contain" /> : <img src={assetUrl(expanded.url)} alt={expanded.name} className="max-h-[85vh] max-w-full object-contain" />}
      <p className="absolute bottom-4 text-xs text-white/70">{expanded.index + 1} / {run?.totalAssets || 0} · {expanded.name}</p>
    </div>}
  </div>;
}