"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronLeft, ChevronRight, Folder,
  Play, ScanLine, Square, X,
} from "lucide-react";
import { useActiveProject } from "@/context/ProjectContext";
import { MOCK_DATASETS } from "@/data/mockDatasetData";
import { useInference } from "@/hooks/useInference";
import FormSelect from "@/components/ui/FormSelect";

// ─── Detection overlay ────────────────────────────────────────────────────────

function DetectionOverlay({ detections, size }) {
  const { w, h } = size;
  if (!detections?.length) return null;
  return (
    <>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        className="absolute inset-0 w-full h-full pointer-events-none"
        preserveAspectRatio="none"
      >
        {detections.map((d) => (
          <g key={d.id}>
            <rect
              x={d.x * w} y={d.y * h} width={d.w * w} height={d.h * h}
              fill={d.color + "1a"} stroke={d.color} strokeWidth="2.5" rx="3"
              style={{ vectorEffect: "non-scaling-stroke" }}
            />
            {/* Corner brackets */}
            {[[d.x, d.y], [d.x + d.w, d.y], [d.x, d.y + d.h], [d.x + d.w, d.y + d.h]].map(([cx, cy], i) => {
              const dx = i % 2 === 1 ? -1 : 1;
              const dy = i >= 2 ? -1 : 1;
              const len = 12;
              return (
                <g key={i}>
                  <line x1={cx * w} y1={cy * h} x2={cx * w + dx * len} y2={cy * h}
                    stroke={d.color} strokeWidth="3" strokeLinecap="round"
                    style={{ vectorEffect: "non-scaling-stroke" }} />
                  <line x1={cx * w} y1={cy * h} x2={cx * w} y2={cy * h + dy * len}
                    stroke={d.color} strokeWidth="3" strokeLinecap="round"
                    style={{ vectorEffect: "non-scaling-stroke" }} />
                </g>
              );
            })}
          </g>
        ))}
      </svg>

      {detections.map((d) => (
        <div key={`lbl_${d.id}`}
          className="absolute pointer-events-none"
          style={{ left: `${d.x * 100}%`, top: `${d.y * 100}%`, transform: "translateY(-100%)" }}
        >
          <span className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold text-white leading-none shadow-lg"
            style={{ backgroundColor: d.color }}>
            {d.alias}
            <span className="opacity-75">{(d.confidence * 100).toFixed(0)}%</span>
          </span>
        </div>
      ))}
    </>
  );
}

// ─── Live frame viewer ────────────────────────────────────────────────────────

function LiveViewer({ frame, phase }) {
  const containerRef = useRef(null);
  const [size, setSize] = useState({ w: 1, h: 1 });

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(([e]) =>
      setSize({ w: e.contentRect.width || 1, h: e.contentRect.height || 1 })
    );
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-full bg-black overflow-hidden">
      <AnimatePresence mode="wait">
        {frame ? (
          <motion.div
            key={frame.id}
            initial={{ opacity: 0.6 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15 }}
            className="absolute inset-0"
          >
            <img src={frame.imageUrl} alt={`Frame ${frame.frameIdx}`} className="w-full h-full object-contain" />
            <DetectionOverlay detections={frame.detections} size={size} />

            {/* Frame info overlay */}
            <div className="absolute bottom-3 left-3 flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-sm text-xs font-mono text-white/70 border border-white/10">
                {frame.frameIdx} / {frame.total}
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-sm text-xs font-mono text-white/70 border border-white/10">
                {frame.ms}ms
              </span>
              {frame.detections.length > 0 && (
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/80 backdrop-blur-sm text-xs font-bold text-white">
                  {frame.detections.length} detected
                </span>
              )}
            </div>

            {/* Running indicator */}
            {phase === "running" && (
              <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-sm border border-[var(--accent-500)]/30">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-500)] animate-pulse" />
                <span className="text-[10px] font-bold text-[var(--accent-500)]">LIVE</span>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div key="empty" className="absolute inset-0 flex flex-col items-center justify-center gap-3">
            <ScanLine size={36} className="text-white/20" strokeWidth={1.5} />
            <p className="text-sm text-white/30 font-medium">
              {phase === "idle" ? "Configure and run inference" : "Starting…"}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Filmstrip ────────────────────────────────────────────────────────────────

function Filmstrip({ frames, onPreview }) {
  const stripRef = useRef(null);

  // Auto-scroll to latest
  useEffect(() => {
    if (stripRef.current)
      stripRef.current.scrollLeft = stripRef.current.scrollWidth;
  }, [frames.length]);

  if (!frames.length) return null;

  return (
    <div className="flex-shrink-0 border-t border-[var(--border-color)] bg-[var(--bg-main)]">
      <div ref={stripRef} className="flex items-center gap-2 px-4 py-2.5 overflow-x-auto">
        {frames.map((f, i) => (
          <button
            key={f.id}
            onClick={() => onPreview(i)}
            className="relative flex-shrink-0 w-20 h-14 rounded-lg overflow-hidden border border-[var(--border-color)] hover:border-[var(--accent-500)]/50 hover:scale-105 transition-all group"
          >
            <img src={f.imageUrl} alt={`Frame ${f.frameIdx}`} className="w-full h-full object-cover" />
            {f.detections.length > 0 && (
              <span className="absolute bottom-0.5 right-0.5 bg-emerald-500 text-white text-[8px] font-bold rounded px-1 leading-tight">
                {f.detections.length}
              </span>
            )}
            <span className="absolute top-0.5 left-0.5 bg-black/60 text-white text-[8px] font-mono rounded px-1 leading-tight">
              {f.frameIdx}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Lightbox ─────────────────────────────────────────────────────────────────

function Lightbox({ frames, index, onClose }) {
  const [current, setCurrent] = useState(index);
  const containerRef = useRef(null);
  const [size, setSize] = useState({ w: 1, h: 1 });
  const frame = frames[current];

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(([e]) =>
      setSize({ w: e.contentRect.width || 1, h: e.contentRect.height || 1 })
    );
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const h = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft")  setCurrent((i) => Math.max(0, i - 1));
      if (e.key === "ArrowRight") setCurrent((i) => Math.min(frames.length - 1, i + 1));
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [frames.length, onClose]);

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex flex-col bg-black/94 backdrop-blur-md"
      onClick={onClose}
    >
      {/* Top bar */}
      <div className="flex-shrink-0 flex items-center justify-between px-6 py-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3">
          <span className="text-sm font-mono text-white/60">Frame {frame.frameIdx}</span>
          <span className="text-xs font-mono text-white/40">{frame.ms}ms</span>
          {frame.detections.length > 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-white">
              {frame.detections.length} detections
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-white/30">{current + 1} / {frames.length}</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-all">
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Image */}
      <div ref={containerRef} className="flex-1 min-h-0 relative mx-14 mb-5" onClick={(e) => e.stopPropagation()}>
        <AnimatePresence mode="wait">
          <motion.div key={current} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.12 }} className="absolute inset-0">
            <img src={frame.imageUrl} className="w-full h-full object-contain" />
            <DetectionOverlay detections={frame.detections} size={size} />
          </motion.div>
        </AnimatePresence>
        <button onClick={() => setCurrent((i) => Math.max(0, i - 1))} disabled={current === 0}
          className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white disabled:opacity-20 transition-all">
          <ChevronLeft size={20} />
        </button>
        <button onClick={() => setCurrent((i) => Math.min(frames.length - 1, i + 1))} disabled={current === frames.length - 1}
          className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white disabled:opacity-20 transition-all">
          <ChevronRight size={20} />
        </button>
      </div>

      {/* Detection chips */}
      {frame.detections.length > 0 && (
        <div className="flex-shrink-0 flex items-center gap-2 px-6 pb-4 justify-center flex-wrap" onClick={(e) => e.stopPropagation()}>
          {frame.detections.map((d) => (
            <span key={d.id} className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold text-white border border-white/10 bg-white/5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }} />
              {d.alias} · {(d.confidence * 100).toFixed(1)}%
            </span>
          ))}
        </div>
      )}
    </motion.div>
  );
}

// ─── Slider ───────────────────────────────────────────────────────────────────

function Slider({ label, value, onChange, disabled }) {
  const pct = value * 100;
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-[var(--text-tertiary)] whitespace-nowrap">{label}</span>
      <div className="relative w-24 h-1.5 rounded-full bg-[var(--bg-hover)] border border-[var(--border-color)]">
        <div className="absolute left-0 top-0 h-full rounded-full bg-[var(--accent-500)]" style={{ width: `${pct}%` }} />
        <input type="range" min={0} max={1} step={0.05} value={value}
          onChange={(e) => onChange(Number(e.target.value))} disabled={disabled}
          className="absolute inset-0 w-full opacity-0 cursor-pointer h-full disabled:cursor-not-allowed" />
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-[var(--accent-500)] border-2 border-[var(--bg-surface)] shadow pointer-events-none"
          style={{ left: `${pct}%` }} />
      </div>
      <span className="text-xs font-bold tabular-nums text-[var(--text-primary)] w-8">{value.toFixed(2)}</span>
    </div>
  );
}

// ─── InferencePage ────────────────────────────────────────────────────────────

export default function InferencePage() {
  const { activeProject } = useActiveProject();
  const {
    phase, folderPath, setFolderPath,
    config, updateConfig,
    currentFrame, processedFrames, stats,
    start, stop, reset,
  } = useInference();

  const [lightboxIdx, setLightboxIdx] = useState(null);

  const projectDatasets = activeProject
    ? MOCK_DATASETS.filter((d) => d.projectId === activeProject.id)
    : [];
  const classes = projectDatasets[0]?.classes ?? [];

  const isRunning = phase === "running";
  const canRun    = !!folderPath.trim() && !isRunning;
  const pct       = stats.total > 0 ? Math.round((stats.processed / stats.total) * 100) : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="w-full md:h-full flex flex-col gap-4"
    >
      {/* Header */}
      <div className="app-page-header flex-shrink-0 flex items-center justify-between gap-4 p-5 surface rounded-xl shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)] flex items-center justify-center flex-shrink-0 border border-[var(--accent-500)]/20">
            <ScanLine size={22} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] leading-tight">Inference</h1>
            <p className="text-sm text-[var(--text-secondary)] mt-0.5">
              {activeProject
                ? <>Project: <span className="font-semibold text-[var(--accent-500)]">{activeProject.name}</span></>
                : <span className="text-amber-500">No project selected.</span>}
            </p>
          </div>
        </div>

        {/* Live stats */}
        {(isRunning || phase === "done") && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3">
            {[
              { label: "Processed",  value: `${stats.processed}/${stats.total}`, color: "text-[var(--accent-500)]" },
              { label: "Detections", value: stats.detections,                    color: "text-emerald-500" },
              { label: "Avg",        value: stats.avgMs ? `${stats.avgMs}ms` : "—", color: "text-[var(--text-primary)]" },
            ].map((s) => (
              <div key={s.label} className="flex flex-col items-center px-3 py-2 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] min-w-[72px]">
                <span className={`text-base font-bold leading-none ${s.color}`}>{s.value}</span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)] mt-1">{s.label}</span>
              </div>
            ))}
          </motion.div>
        )}
      </div>

      {/* Main card */}
      <div className="md:flex-1 md:min-h-0 flex flex-col surface rounded-xl [overflow:clip]">

        {/* Controls */}
        <div className="flex-shrink-0 flex flex-wrap items-center gap-3 px-4 py-3 bg-[var(--bg-main)] border-b border-[var(--border-color)]">

          {/* Folder path */}
          <div className="flex items-center gap-2 flex-1 min-w-[240px]">
            <Folder size={15} className="text-[var(--text-tertiary)] flex-shrink-0" />
            <input
              value={folderPath}
              onChange={(e) => setFolderPath(e.target.value)}
              placeholder="C:/datasets/images"
              disabled={isRunning}
              className="flex-1 px-3 py-1.5 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] text-sm text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all font-mono disabled:opacity-50"
            />
          </div>

          <div className="w-px h-5 bg-[var(--border-color)]" />

          {/* Model */}
          <div className="w-44">
            <FormSelect
              value={config.modelId}
              onChange={(v) => updateConfig("modelId", v)}
              options={[]}
              placeholder="Select model"
              disabled={isRunning}
            />
          </div>

          <div className="w-px h-5 bg-[var(--border-color)]" />

          <Slider label="Confidence" value={config.confidenceThreshold} onChange={(v) => updateConfig("confidenceThreshold", v)} disabled={isRunning} />
          <Slider label="IoU"        value={config.iouThreshold}        onChange={(v) => updateConfig("iouThreshold", v)}        disabled={isRunning} />

          {/* Run / Stop */}
          <div className="flex items-center gap-2 ml-auto">
            {(phase === "done" || phase === "stopped") && (
              <button onClick={reset}
                className="px-3 py-2 rounded-lg border border-[var(--border-color)] text-xs font-semibold text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors">
                Reset
              </button>
            )}
            {isRunning ? (
              <button onClick={stop}
                className="flex items-center gap-2 px-5 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm font-bold transition-colors shadow-sm">
                <Square size={13} fill="white" /> Stop
              </button>
            ) : (
              <button onClick={() => start(classes)} disabled={!canRun}
                className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-bold transition-all shadow-sm ${
                  canRun
                    ? "bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white"
                    : "bg-[var(--bg-hover)] text-[var(--text-tertiary)] border border-[var(--border-color)] cursor-not-allowed"
                }`}>
                <Play size={14} /> Run Inference
              </button>
            )}
          </div>
        </div>

        {/* Progress bar */}
        {(isRunning || phase === "done") && (
          <div className="flex-shrink-0 h-1 bg-[var(--bg-hover)]">
            <motion.div
              animate={{ width: `${pct}%` }}
              transition={{ duration: 0.3 }}
              className={`h-full ${phase === "done" ? "bg-emerald-500" : "bg-[var(--accent-500)]"}`}
            />
          </div>
        )}

        {/* Live frame viewer */}
        <div className="flex-1 min-h-0">
          <LiveViewer frame={currentFrame} phase={phase} />
        </div>

        {/* Processed frames filmstrip */}
        <Filmstrip frames={processedFrames} onPreview={(i) => setLightboxIdx(i)} />
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxIdx !== null && processedFrames.length > 0 && (
          <Lightbox
            frames={processedFrames}
            index={lightboxIdx}
            onClose={() => setLightboxIdx(null)}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}
