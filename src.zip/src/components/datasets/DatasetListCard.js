"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Database, LayoutGrid, List, Search } from "lucide-react";
import DatasetCard, { cardVariants } from "./DatasetCard";
import DatasetTable from "./DatasetTable";
import Pagination from "@/components/ui/Pagination";

const gridVariants = {
  hidden: {},
  show:   { transition: { staggerChildren: 0.07 } },
};

export default function DatasetListCard({
  paginatedDatasets,
  filteredDatasets,
  searchTerm, setSearchTerm,
  viewMode,   setViewMode,
  page,       setPage,
  pageSize,   setPageSize,
  onView,
}) {
  return (
    <div className="md:flex-1 md:min-h-0 flex flex-col surface rounded-xl [overflow:clip]">

      {/* Toolbar */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3 bg-[var(--bg-main)] border-b border-[var(--border-color)]">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)] pointer-events-none" />
          <input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by name, project or status…"
            className="w-full pl-9 pr-4 py-2 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] text-sm text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all"
          />
        </div>
        <div className="flex items-center bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-lg p-0.5">
          {[{ mode: "grid", Icon: LayoutGrid }, { mode: "list", Icon: List }].map(({ mode, Icon }) => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`p-2 rounded-md transition-all ${viewMode === mode ? "bg-[var(--accent-500)] text-white shadow-sm" : "text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"}`}
              title={mode === "grid" ? "Card view" : "List view"}
            >
              <Icon size={15} />
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 min-h-0 overflow-auto">
        {filteredDatasets.length === 0 ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full min-h-[200px] flex items-center justify-center text-center p-8">
            <div>
              <Database size={40} className="text-[var(--text-tertiary)] mx-auto mb-3" strokeWidth={1.5} />
              <p className="text-sm font-medium text-[var(--text-secondary)]">No datasets found</p>
              <p className="text-xs text-[var(--text-tertiary)] mt-1">Try a different search term.</p>
            </div>
          </motion.div>
        ) : (
          <AnimatePresence mode="wait">
            {viewMode === "grid" ? (
              <motion.div
                key="grid"
                variants={gridVariants}
                initial="hidden"
                animate="show"
                exit={{ opacity: 0, transition: { duration: 0.12 } }}
                className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-3 p-4"
              >
                {paginatedDatasets.map((d) => (
                  <DatasetCard key={d.id} dataset={d} onView={onView} />
                ))}
              </motion.div>
            ) : (
              <motion.div key="list" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, transition: { duration: 0.12 } }}>
                <DatasetTable datasets={paginatedDatasets} onView={onView} />
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>

      {/* Pagination */}
      {filteredDatasets.length > 0 && (
        <div className="flex-shrink-0 px-4 py-3 bg-[var(--bg-main)] border-t border-[var(--border-color)]">
          <Pagination
            page={page}
            pageSize={pageSize}
            totalItems={filteredDatasets.length}
            onPageChange={setPage}
            onPageSizeChange={(s) => { setPageSize(s); setPage(1); }}
          />
        </div>
      )}
    </div>
  );
}
