"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, Pencil, Trash2, Undo2, RefreshCw, SlidersHorizontal, Square } from "lucide-react";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";
import ValidationEditor from "./ValidationEditor";
import AutomaticValidation from "./AutomaticValidation";
import ValidationCarousel from "./ValidationCarousel";

export default function DatasetValidation({ datasetId, onBack }) {
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [deleted, setDeleted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [validationMode, setValidationMode] = useState("manual");
  const [confirm, setConfirm] = useState(null);
  const [snapshot, setSnapshot] = useState(null);
  const [automaticSidebarOpen, setAutomaticSidebarOpen] = useState(false);
  const [automaticStatus, setAutomaticStatus] = useState({ running: false, hasError: false });
  const [manualJob, setManualJob] = useState(null);
  const [jobBusy, setJobBusy] = useState(false);
  const refresh = useCallback(async () => {
    try {
      const payload = await datasetRequest(`/datasets/${datasetId}?page=${page}&page_size=48&deleted=${deleted}`);
      if (page > 1 && !payload.items.length) { setPage(page - 1); return; }
      setData(payload);
      setError("");
    } catch (error) { setError(error.message); }
    finally { setLoading(false); }
  }, [datasetId, page, deleted]);
  useEffect(() => { const initialFetch = window.setTimeout(refresh, 0); return () => window.clearTimeout(initialFetch); }, [refresh]);
  const dataset = data?.dataset;
  const editable = dataset && dataset.state !== "running";
  async function toggleDelete(item, remove) {
    setBusy(true); setError("");
    try {
      await datasetRequest(`/datasets/${datasetId}/images/${item.id}`, { method: "PATCH", body: JSON.stringify({ revision: dataset.revision, deleted: remove }) });
      setConfirm(null); setViewing(null); await refresh();
    } catch (error) { setError(error.message); }
    finally { setBusy(false); }
  }
  const pollManualStatus = useCallback(async () => {
    try { const payload = await datasetRequest(`/datasets/${datasetId}/validate/status`); setManualJob(payload.job); return payload.job; }
    catch { return null; }
  }, [datasetId]);
  useEffect(() => { if (validationMode === "manual") { const initial = window.setTimeout(pollManualStatus, 0); return () => window.clearTimeout(initial); } }, [validationMode, pollManualStatus]);
  useEffect(() => {
    if (manualJob?.state !== "running") return;
    const interval = window.setInterval(async () => {
      const job = await pollManualStatus();
      if (job && job.state !== "running") { if (job.snapshot) setSnapshot(job.snapshot); await refresh(); }
    }, 1200);
    return () => window.clearInterval(interval);
  }, [manualJob?.state, pollManualStatus, refresh]);
  async function validate() {
    setBusy(true); setError("");
    try {
      const result = await datasetRequest(`/datasets/${datasetId}/validate/start`, { method: "POST", body: JSON.stringify({ revision: dataset.revision }) });
      setManualJob(result.job);
      if (result.snapshot) setSnapshot(result.snapshot);
      setConfirm(null);
      if (!result.job) await refresh();
    } catch (error) { setError(error.message); }
    finally { setBusy(false); }
  }
  async function stopManualValidation() {
    setJobBusy(true);
    try { await datasetRequest(`/datasets/${datasetId}/validate/cancel`, { method: "POST" }); }
    catch (error) { setError(error.message); }
    finally { setJobBusy(false); }
  }
  const currentSnapshot = dataset?.snapshots.find((value) => value.revision === dataset.revision && value.validationMethod !== "automatic");
  return <section className="surface rounded-xl h-full min-h-0 flex flex-col overflow-hidden">
    <div className="flex-shrink-0 grid grid-cols-[1fr_auto_1fr] items-center gap-3 p-3 border-b border-[var(--border-color)]">
      <div className="flex items-center gap-2.5 min-w-0">
        <button onClick={onBack} disabled={busy} aria-label="Back to datasets" className="p-2 rounded-lg hover:bg-[var(--bg-hover)] flex-shrink-0"><ArrowLeft size={18} /></button>
        <div className="min-w-0">
          <h1 className="text-sm font-semibold break-all leading-tight">{dataset?.name || "Dataset validation"}</h1>
          <p className="text-xs text-[var(--text-secondary)] truncate">{dataset && `${dataset.projectName} · ${dataset.mode} · Run ${dataset.runNumber} · ${dataset.passCount} included Pass images`}</p>
        </div>
      </div>

      <div className="flex items-center gap-2 justify-self-center">
        {["manual", "automatic"].map((mode) => <button key={mode} aria-pressed={validationMode === mode} disabled={busy || manualJob?.state === "running"} onClick={() => setValidationMode(mode)} className={`capitalize px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors ${validationMode === mode ? "bg-[var(--accent-500)] text-white shadow-sm" : "bg-[var(--bg-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`}>{mode}</button>)}
      </div>

      <div className="flex items-center gap-2 justify-self-end">
        {validationMode === "manual" && (manualJob?.state === "running" ? <>
          <span role="status" className="text-xs text-[var(--text-secondary)] whitespace-nowrap">Validating… {manualJob.completed}/{manualJob.total}</span>
          <button disabled={jobBusy} onClick={stopManualValidation} className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--border-color)] px-3 py-1.5 text-xs font-semibold disabled:opacity-40 whitespace-nowrap"><Square size={12} />{jobBusy ? "Stopping…" : "Stop"}</button>
        </> : <button disabled={busy || loading || dataset?.state !== "complete" || !dataset?.passCount || !!currentSnapshot} onClick={() => setConfirm({ type: "validate" })} className="inline-flex items-center gap-1.5 rounded-lg bg-[var(--accent-500)] text-white px-3 py-1.5 text-xs font-semibold disabled:opacity-40 whitespace-nowrap"><CheckCircle2 size={14} />{currentSnapshot ? "Validated" : busy ? "Working…" : "Validate"}</button>)}
        {validationMode === "automatic" && <button onClick={() => setAutomaticSidebarOpen(true)} aria-label="Run validation" className="relative inline-flex items-center gap-1.5 rounded-lg border border-[var(--border-color)] px-3 py-1.5 text-xs font-semibold hover:bg-[var(--bg-hover)] whitespace-nowrap">
          <SlidersHorizontal size={14} />Run Validation
          {(automaticStatus.running || automaticStatus.hasError) && <span className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border-2 border-[var(--bg-main)] ${automaticStatus.hasError ? "bg-red-500" : "bg-emerald-500 animate-pulse"}`} />}
        </button>}
        <button onClick={refresh} disabled={busy || loading} aria-label="Refresh images" className="p-2 rounded-lg hover:bg-[var(--bg-hover)]"><RefreshCw size={16} /></button>
      </div>
    </div>
    {validationMode === "automatic" && dataset ? <AutomaticValidation dataset={dataset} onInspect={(item, items, context) => setViewing({ item, items, ...context })} onEdit={setEditing} onDelete={(item) => setConfirm({ type: "delete", item })} onExport={refresh} sidebarOpen={automaticSidebarOpen} onCloseSidebar={() => setAutomaticSidebarOpen(false)} onStatusChange={setAutomaticStatus} /> : <>
    <div className="px-4 py-2 flex flex-wrap justify-center items-center gap-2 border-b border-[var(--border-color)] text-xs">
      <button onClick={() => { setDeleted(false); setPage(1); }} disabled={busy} className={`px-3 py-1.5 rounded-lg font-semibold ${!deleted ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`}>Pass images ({dataset?.passCount || 0})</button>
      <button onClick={() => { setDeleted(true); setPage(1); }} disabled={busy} className={`px-3 py-1.5 rounded-lg font-semibold ${deleted ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`}>Deleted ({dataset?.deletedCount || 0})</button>
    </div>
    <div className="flex-1 min-h-0 overflow-auto p-3">
      {error && <p role="alert" className="text-red-400 mb-3">{error}</p>}
      {manualJob?.state === "running" && <div className="mb-4 space-y-1">
        <p role="status" className="text-xs text-[var(--text-secondary)]">Validating {manualJob.completed}/{manualJob.total} images…</p>
        <progress className="h-1.5 w-full rounded-full [&::-moz-progress-bar]:rounded-full [&::-moz-progress-bar]:bg-emerald-500 [&::-webkit-progress-bar]:rounded-full [&::-webkit-progress-bar]:bg-[var(--bg-hover)] [&::-webkit-progress-value]:rounded-full [&::-webkit-progress-value]:bg-emerald-500" max={manualJob.total || 1} value={manualJob.completed} aria-label="Validation progress" />
      </div>}
      {manualJob?.state === "cancelled" && <p className="text-amber-400 text-sm mb-4">Validation stopped after {manualJob.completed}/{manualJob.total} images. {manualJob.snapshot ? "The images checked so far were saved below." : "No images were checked before stopping."}</p>}
      {manualJob?.state === "failed" && manualJob.error && <p className="text-red-400 text-sm mb-4">{manualJob.error}</p>}
      {manualJob?.invalid?.length > 0 && <p className="text-amber-400 text-sm mb-4">{manualJob.invalid.length} image{manualJob.invalid.length === 1 ? "" : "s"} skipped due to invalid labels: {manualJob.invalid.map((value) => value.filename).join(", ")}</p>}
      {(snapshot || currentSnapshot) && <div role="status" className="rounded-lg border border-emerald-600/40 p-3 mb-4 text-sm"><p className="text-emerald-400">Validated snapshot saved: {(snapshot || currentSnapshot).imageCount} raw images + matching labels.</p><p className="break-all text-xs mt-1 text-[var(--text-secondary)]">{(snapshot || currentSnapshot).directory}</p><Link className="inline-block mt-2 underline" href={`/training?dataset=${(snapshot || currentSnapshot).id}`}>Use in Training →</Link>{snapshot && !currentSnapshot && <p className="mt-2">This review has changed since that snapshot. Validate again to include the latest edits.</p>}</div>}
      {dataset?.state !== "complete" && dataset && <p className="text-amber-400 text-sm mb-4">Run status: {dataset.state}. Only completed runs can be validated.{!editable && " Refresh when annotation finishes."}</p>}
      {loading && <p role="status" className="mb-3 text-sm">Loading annotated images…</p>}
      {!loading && !data?.items.length && <p className="p-12 text-center text-[var(--text-secondary)]">{deleted ? "No deleted images." : "No Pass images available for review."}</p>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4">
        {data?.items.map((item) => <article key={item.id} className="rounded-xl overflow-hidden border border-[var(--border-color)] bg-[var(--bg-hover)]">
          <div className="relative bg-black/30 aspect-[4/3]">
            <button onClick={() => { setViewing({ item, items: data.items, page, size: 48, total: data.total, deleted, automatic: false }); }} className="w-full h-full" title={`Inspect ${item.filename}`}><img loading="lazy" src={assetUrl(item.annotatedUrl)} alt={`Annotated ${item.filename}`} className="w-full h-full object-contain" /></button>
            <div className="absolute top-2 right-2 flex gap-1">
              {deleted ? <button onClick={() => toggleDelete(item, false)} disabled={busy || !editable} title="Restore image" aria-label={`Restore ${item.filename}`} className="p-2 rounded-lg bg-black/80 text-white disabled:opacity-40"><Undo2 size={15} /></button> : <>
                <button onClick={() => setEditing(item)} disabled={busy || !editable} title="Edit annotation with ROI" aria-label={`Edit ${item.filename}`} className="p-2 rounded-lg bg-black/80 text-white disabled:opacity-40"><Pencil size={15} /></button>
                <button onClick={() => setConfirm({ type: "delete", item })} disabled={busy || !editable} title="Delete from review" aria-label={`Delete ${item.filename}`} className="p-2 rounded-lg bg-black/80 text-red-300 disabled:opacity-40"><Trash2 size={15} /></button>
              </>}
            </div>
          </div>
          <div className="p-3"><p className="text-xs font-medium truncate" title={item.filename}>{item.filename}</p><p className="text-xs text-[var(--text-secondary)] mt-1">{item.detections} objects{item.edited ? " · Corrected" : ""}{item.deleted ? " · Excluded" : ""}</p></div>
        </article>)}
      </div>
    </div>
    <div className="p-3 border-t border-[var(--border-color)] flex justify-center gap-5 items-center text-sm"><button disabled={page === 1 || loading || busy} onClick={() => setPage(page - 1)} className="disabled:opacity-30">Previous</button><span>{data?.total || 0} images · Page {page} of {Math.max(1, Math.ceil((data?.total || 0) / 48))}</span><button disabled={page * 48 >= (data?.total || 0) || loading || busy} onClick={() => setPage(page + 1)} className="disabled:opacity-30">Next</button></div>
    </>}
    {editing && dataset && <ValidationEditor dataset={dataset} item={editing} onClose={() => setEditing(null)} onSaved={async () => { setEditing(null); await refresh(); }} />}
    {viewing && <ValidationCarousel datasetId={datasetId} revision={dataset.revision} initial={viewing} editable={editable} blocked={busy || !!confirm} onClose={() => setViewing(null)} onEdit={(item) => { setEditing(item); setViewing(null); }} onDelete={(item) => setConfirm({ type: "delete", item })} onRestore={(item) => toggleDelete(item, false)} />}
    {confirm && <div role="dialog" aria-modal="true" aria-label={confirm.type === "delete" ? "Confirm deletion" : "Confirm validation"} className="fixed inset-0 z-[110] bg-black/70 flex items-center justify-center p-4"><div className="surface rounded-xl p-6 max-w-lg w-full shadow-xl"><h2 className="font-semibold mb-3">{confirm.type === "delete" ? "Delete this image from review?" : "Validate this dataset?"}</h2><p className="text-sm text-[var(--text-secondary)]">{confirm.type === "delete" ? `${confirm.item.filename} will be excluded from future training snapshots. Its raw image and labels remain recoverable in the Deleted tab.` : `Confirm that all ${dataset.passCount} included Pass images are correctly annotated. We will copy their raw images and ${dataset.mode} labels into a fixed Training dataset. Fail and deleted images are not included.`}</p>{error && <p role="alert" className="mt-3 text-sm text-red-400">{error}</p>}<div className="flex justify-end gap-4 mt-5"><button disabled={busy} onClick={() => setConfirm(null)}>Cancel</button><button disabled={busy} onClick={() => confirm.type === "delete" ? toggleDelete(confirm.item, true) : validate()} className="rounded-lg bg-[var(--accent-500)] text-white px-4 py-2">{busy ? "Working…" : "Confirm"}</button></div></div></div>}
  </section>;
}