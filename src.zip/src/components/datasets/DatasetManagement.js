"use client";
import { useEffect, useState } from "react";
import { FolderOpen, CheckCircle2, Trash2 } from "lucide-react";
import { useDatasets } from "@/hooks/useDatasets";
import { datasetRequest } from "@/utils/datasetApi";
import DatasetValidation from "./DatasetValidation";
import { useActiveProject } from "@/context/ProjectContext";
export default function DatasetManagement() {
  const { activeProject } = useActiveProject();
  return <ProjectDatasets key={activeProject?.id || "none"} project={activeProject} />;
}
function ProjectDatasets({ project }) {
  const { datasets, loading, error, refresh } = useDatasets();
  const [selected, setSelected] = useState(null);
  // No manual refresh control on this page anymore, so keep the grid current
  // on its own — this is also what makes a re-run's replacement (below) show
  // up promptly without the user having to navigate away and back.
  useEffect(() => { const interval = setInterval(refresh, 8000); return () => clearInterval(interval); }, [refresh]);
  const projectNames = project ? [project.name, project.name.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._]+|[._]+$/g, "")] : [];
  const matching = datasets.filter((item) => project && projectNames.includes(item.projectName));
  async function remove(item) {
    if (!window.confirm(`Permanently delete “${item.name}”, its annotation files, and its validated snapshots? This cannot be undone.`)) return;
    try { await datasetRequest(`/datasets/${item.id}`, { method: "DELETE" }); await refresh(); }
    catch (error) { window.alert(error.message); }
  }
  // Old records remain safely stored, but re-running Smart Annotation on the
  // same source folder/video, in the same mode, should present exactly one
  // current card for it — the newest run for that name+mode combination wins
  // and replaces whatever was shown before. A different mode (e.g. running
  // Segmentation on a folder previously used for Detection) is a distinct,
  // intentional output and still gets its own card.
  const filtered = Object.values(matching.reduce((latest, item) => {
    const key = `${item.mode}:${item.name}`;
    if (!latest[key] || new Date(item.createdAt) > new Date(latest[key].createdAt)) latest[key] = item;
    return latest;
  }, {}));
  if (selected) return <DatasetValidation datasetId={selected} onBack={() => { setSelected(null); refresh(); }} />;
  return <section className="surface rounded-xl flex flex-col min-h-0 h-full overflow-hidden" aria-label="Datasets">
    <div className="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-[var(--border-color)]">
      <div className="flex items-baseline gap-2 min-w-fit"><h1 className="text-lg font-bold">Datasets</h1>{project && <span className="text-xs font-semibold text-[var(--text-secondary)]">{project.name}</span>}</div>
    </div>
    <div className="p-4 overflow-auto flex-1">
      {!project && <p className="text-sm text-[var(--text-secondary)] mb-4">Select a project.</p>}
      {error && <p role="alert" className="text-red-400 mb-4">{error} <button onClick={refresh} className="underline">Retry</button></p>}
      {loading && !datasets.length && <p role="status">Loading source output folders…</p>}
      {!loading && !error && !filtered.length && <div className="p-12 text-center border border-dashed border-[var(--border-color)] rounded-xl"><FolderOpen className="mx-auto mb-3" /><p>No annotation datasets found.</p><p className="text-sm text-[var(--text-secondary)] mt-2">Complete Smart Annotation for an image folder or video, then refresh this page.</p></div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-4">{filtered.map((item) => {
        const validated = item.snapshots.some((snapshot) => snapshot.revision === item.revision && snapshot.validationMethod !== "automatic");
        return <article key={item.id} className="group relative text-left p-4 rounded-2xl border border-[var(--border-color)] bg-gradient-to-br from-[var(--bg-hover)] to-[var(--bg-surface)] hover:border-[var(--accent-500)] hover:-translate-y-0.5 hover:shadow-lg transition-all">
          <button onClick={() => remove(item)} aria-label={`Delete ${item.name}`} title="Permanently delete output" className="absolute right-3 top-3 rounded-lg p-2 text-red-400 hover:bg-red-500/10"><Trash2 size={16} /></button>
          <button onClick={() => setSelected(item.id)} className="w-full text-left">
          <div className="flex items-start gap-2"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)]"><FolderOpen size={19} /></span><h2 className="font-semibold break-all flex-1 pt-1">{item.name}</h2>{validated && <CheckCircle2 size={18} className="text-emerald-400 shrink-0 mt-1" />}</div>
          <p className="text-xs text-[var(--text-secondary)] mt-2">{item.projectName} · <span className="capitalize">{item.mode}</span> · Run {item.runNumber}</p>
          <div className="flex gap-4 my-5"><div><strong className="text-2xl">{item.passCount}</strong><span className="block text-xs text-emerald-400">Pass to review</span></div><div><strong className="text-2xl">{item.failCount}</strong><span className="block text-xs text-[var(--text-tertiary)]">Fail</span></div></div>
          <div className="flex justify-between items-center text-xs mt-4 border-t border-[var(--border-color)] pt-3"><span className="capitalize">{item.state === "complete" ? (validated ? "Validated" : "Ready for review") : item.state}</span><span className="text-[var(--accent-500)]">Validate images →</span></div>
          </button></article>;
      })}</div>
    </div>
  </section>;
}
