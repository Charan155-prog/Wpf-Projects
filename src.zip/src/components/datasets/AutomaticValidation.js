"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Pencil, Trash2, X } from "lucide-react";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";

export default function AutomaticValidation({ dataset, onInspect, onEdit, onDelete, onExport, sidebarOpen, onCloseSidebar, onStatusChange }) {
  const [result, setResult] = useState(null);
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState("review");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [snapshot, setSnapshot] = useState(null);
  const refresh = useCallback(async () => {
    try { setResult(await datasetRequest(`/datasets/${dataset.id}/automatic?page=${page}&status=${filter}`)); setError(""); }
    catch (error) { setError(error.message === "Not Found" ? "Automatic validation API is unavailable. Update the complete backend folder on the model server and restart it." : error.message); }
  }, [dataset.id, page, filter]);
  useEffect(() => {
    const initial = setTimeout(refresh, 0);
    const poll = setInterval(refresh, 5000);
    return () => { clearTimeout(initial); clearInterval(poll); };
  }, [refresh]);
  const report = result?.report;
  const stale = report && (report.stale || report.revision !== dataset.revision);
  useEffect(() => { onStatusChange?.({ running: report?.state === "running", hasError: !!(error || report?.error) }); }, [report?.state, report?.error, error, onStatusChange]);
  async function action(kind) {
    setBusy(true); setError("");
    try {
      const payload = await datasetRequest(`/datasets/${dataset.id}/automatic${kind ? `/${kind}` : ""}`, {
        method: "POST", body: kind === "cancel" ? undefined : JSON.stringify({ revision: dataset.revision, reportId: report?.id }),
      });
      if (payload.snapshot) { setSnapshot(payload.snapshot); setConfirm(false); onExport(); }
      await refresh();
    } catch (error) { setError(error.message); }
    finally { setBusy(false); }
  }
  return <div className="flex-1 min-h-0 overflow-auto p-3 space-y-3">
    {sidebarOpen && <aside aria-label="Run validation" className="fixed top-0 right-0 z-[105] w-full max-w-sm h-full overflow-y-auto bg-[var(--bg-main)] border-l border-[var(--border-color)] shadow-xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-[var(--text-primary)]">Automatic validation · local VLM + geometry checks</h2>
          <button onClick={onCloseSidebar} aria-label="Close" className="p-1.5 rounded-lg hover:bg-[var(--bg-hover)] flex-shrink-0"><X size={16} /></button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="group relative inline-flex">
            <button disabled={busy || report?.state === "running" || dataset.state !== "complete"} onClick={() => action("")} className="rounded-md bg-[var(--accent-500)] text-white px-3 py-1.5 text-xs font-semibold disabled:opacity-40">{report ? "Run new checks" : "Start automatic checks"}</button>
            <div role="tooltip" className="pointer-events-none absolute left-0 top-full z-20 mt-2 w-72 max-w-[80vw] rounded-lg border border-[var(--border-color)] bg-[var(--bg-main)] p-2.5 text-left text-[11px] leading-relaxed text-[var(--text-secondary)] opacity-0 shadow-xl transition-opacity duration-150 group-hover:opacity-100 group-focus-within:opacity-100">
              In the expanded image viewer, use “Use as ground truth” only after carefully checking/correcting every label. Future annotations of that exact raw image are compared with the frozen reference using class-aware IoU ≥ 0.90. Reference annotations are not scored against themselves. Images without references use model recommendations, not guaranteed accuracy; spot-check before accepting. Flagged images are excluded, not deleted.
            </div>
          </div>
          <button disabled={busy || stale || report?.state !== "complete" || !report?.candidate} onClick={() => setConfirm(true)} className="rounded-md border border-emerald-600 px-3 py-1.5 text-xs font-semibold text-emerald-500 disabled:opacity-40">Accept candidates &amp; create dataset</button>
        </div>
        {report && <div className="space-y-1">
          <div className="flex items-center justify-between gap-2">
            <p role="status" className="text-xs text-[var(--text-secondary)]">{report.state} · {report.completed}/{report.total} checked · {report.candidate} candidates · {report.review} need review</p>
            {report.state === "running" && <button disabled={busy} onClick={() => action("cancel")} className="rounded-md border border-[var(--border-color)] px-2.5 py-1 text-[11px] font-semibold disabled:opacity-40 whitespace-nowrap flex-shrink-0">Stop</button>}
          </div>
          <progress
            className="h-1.5 w-full rounded-full [&::-moz-progress-bar]:rounded-full [&::-moz-progress-bar]:bg-emerald-500 [&::-webkit-progress-bar]:rounded-full [&::-webkit-progress-bar]:bg-[var(--bg-hover)] [&::-webkit-progress-value]:rounded-full [&::-webkit-progress-value]:bg-emerald-500"
            max={report.total || 1} value={report.completed} aria-label="Automatic review progress"
          />
        </div>}
        {stale && <p className="text-xs text-amber-400">Annotations changed after these checks. Rerun before exporting.</p>}
        {report?.error && <p className="text-xs text-red-400">{report.error}</p>}
        {error && <p role="alert" className="text-xs text-red-400">{error}</p>}
        {snapshot && <p role="status" className="text-xs text-emerald-400">Created {snapshot.imageCount} raw-image + label pairs. <Link className="underline" href={`/training?dataset=${snapshot.id}`}>Use in Training</Link></p>}
      </aside>}
    <div className="flex flex-wrap justify-center gap-2">{[["review", "Needs review"], ["candidate", "Candidates (spot-check)"], ["all", "All checked"]].map(([id, title]) => <button key={id} aria-pressed={filter === id} onClick={() => { setFilter(id); setPage(1); }} className={`rounded-md px-2.5 py-1.5 text-xs font-semibold ${filter === id ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`}>{title}</button>)}</div>
    <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-4 gap-3">{result?.items.map((entry) => <article key={entry.itemId} className="border border-[var(--border-color)] rounded-lg overflow-hidden">
      <div className="relative"><button className="w-full" onClick={() => onInspect(entry.image, result.items.map((value) => value.image), { page, size: 24, total: result.total, automatic: true, filter, reportId: result.report?.id })}><img src={assetUrl(entry.image.annotatedUrl)} alt={entry.filename} loading="lazy" className="w-full aspect-[4/3] object-contain bg-black/30" /></button><div className="absolute top-2 right-2 flex gap-2"><button aria-label={`Edit ${entry.filename}`} disabled={busy || entry.image.deleted} onClick={() => onEdit(entry.image)} className="bg-black/80 text-white rounded p-2"><Pencil size={15} /></button><button aria-label={`Delete ${entry.filename}`} disabled={busy || entry.image.deleted} onClick={() => onDelete(entry.image)} className="bg-black/80 text-red-300 rounded p-2"><Trash2 size={15} /></button></div></div>
      <div className="p-3 text-xs space-y-1.5"><p className="font-semibold break-all">{entry.filename}</p><p>{entry.status === "candidate" ? "Candidate" : "Needs review"}{entry.rating ? ` · model rating ${entry.rating}/5` : ""}</p><p className="text-[var(--text-secondary)]">{entry.reason}</p></div>
    </article>)}</div>
    {!result?.items.length && <p className="text-center text-sm text-[var(--text-secondary)]">No checked images in this filter yet.</p>}
    <div className="flex justify-center items-center gap-4 text-xs"><button disabled={page === 1} onClick={() => setPage(page-1)} className="font-semibold disabled:opacity-30">Previous</button><span className="text-[var(--text-secondary)]">Page {page} · {result?.total || 0} results</span><button disabled={page*24 >= (result?.total || 0)} onClick={() => setPage(page+1)} className="font-semibold disabled:opacity-30">Next</button></div>
    {confirm && <div role="dialog" aria-modal="true" aria-label="Accept automatic candidates" className="fixed inset-0 z-[110] bg-black/70 flex items-center justify-center p-4"><div className="surface rounded-xl p-6 max-w-lg space-y-4"><h3 className="font-semibold">Create model-reviewed dataset?</h3><p>Export only {report.candidate} candidate images with their matching raw images and labels. {report.review} flagged images remain excluded and available for manual correction. These checks cannot guarantee accuracy; spot-checking is recommended.</p>{error && <p role="alert" className="text-red-400">{error}</p>}<div className="flex justify-end gap-4"><button disabled={busy} onClick={() => setConfirm(false)}>Cancel</button><button disabled={busy} onClick={() => action("export")} className="bg-[var(--accent-500)] text-white px-4 py-2 rounded">{busy ? "Creating…" : "Accept & create"}</button></div></div></div>}
  </div>;
}