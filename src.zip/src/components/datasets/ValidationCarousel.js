"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Pencil, Trash2, Undo2, X } from "lucide-react";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";

export default function ValidationCarousel({ datasetId, initial, editable, blocked, onClose, onEdit, onDelete, onRestore, revision }) {
  const [current, setCurrent] = useState(initial);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const request = useRef(null);
  const dialog = useRef(null);
  const index = current.items.findIndex((item) => item.id === current.item.id);
  const position = (current.page - 1) * current.size + index;
  const previousDisabled = blocked || pending || position <= 0;
  const nextDisabled = blocked || pending || position >= current.total - 1;
  const move = useCallback(async (direction) => {
    if (blocked || request.current) return;
    const next = index + direction;
    if (next >= 0 && next < current.items.length) {
      setCurrent({ ...current, item: current.items[next] }); setError(""); return;
    }
    const page = current.page + direction;
    if (page < 1 || (page - 1) * current.size >= current.total) return;
    const controller = new AbortController(); request.current = controller;
    setPending(true); setError("");
    try {
      const path = current.automatic
        ? `/datasets/${datasetId}/automatic?page=${page}&status=${current.filter}`
        : `/datasets/${datasetId}?page=${page}&page_size=${current.size}&deleted=${current.deleted}`;
      const payload = await datasetRequest(path, { signal: controller.signal });
      if (controller.signal.aborted) return;
      if (current.automatic && payload.report?.id !== current.reportId) throw new Error("The automatic report changed. Close and reopen the viewer to browse the new results.");
      const items = current.automatic ? payload.items.map((entry) => entry.image) : payload.items;
      if (!items.length) throw new Error("This image list changed. Close and refresh the gallery.");
      setCurrent({ ...current, page, items, total: payload.total, item: direction > 0 ? items[0] : items[items.length - 1] });
    } catch (error) { if (!controller.signal.aborted) setError(error.message); }
    finally { if (!controller.signal.aborted) { request.current = null; setPending(false); } }
  }, [blocked, current, datasetId, index]);
  useEffect(() => {
    const original = document.activeElement;
    dialog.current?.focus();
    return () => { request.current?.abort(); original?.focus?.(); };
  }, []);
  function keyDown(event) {
    if (blocked) return;
    if (event.key === "Escape") { event.preventDefault(); onClose(); }
    if (event.key === "ArrowLeft" && !previousDisabled) { event.preventDefault(); move(-1); }
    if (event.key === "ArrowRight" && !nextDisabled) { event.preventDefault(); move(1); }
    if (event.key === "Tab") {
      const buttons = [...dialog.current.querySelectorAll("button:not(:disabled)")];
      const first = buttons[0], last = buttons[buttons.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog.current)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  }
  const item = current.item;
  async function saveReference() {
    if (!window.confirm("Use this image as ground truth? Confirm every expected object, class and boundary is correct; edit mistakes first. A frozen raw-image + label reference will be saved for future annotations of this exact image only. Comparing this annotation with itself will not count as automatic validation.")) return;
    setPending(true); setError(""); setNotice("");
    try { await datasetRequest(`/datasets/${datasetId}/images/${item.id}/ground-truth`, { method: "POST", body: JSON.stringify({ revision, confirmed: true }) }); setNotice(`Ground-truth reference saved for ${item.filename}.`); }
    catch (e) { setError(e.message); }
    finally { setPending(false); }
  }
  const arrow = "absolute top-1/2 -translate-y-1/2 rounded-full border border-white/30 bg-black/70 p-2 sm:p-3 text-white hover:bg-white/20 focus-visible:ring-2 focus-visible:ring-white disabled:opacity-25 disabled:cursor-not-allowed";
  return <div ref={dialog} tabIndex={-1} onKeyDown={keyDown} role="dialog" aria-modal="true" aria-label="Annotated image carousel" className="fixed inset-0 z-[100] bg-black/95 px-12 sm:px-20 pt-20 pb-24 flex items-center justify-center outline-none">
    <p className="absolute top-5 left-5 text-sm text-white max-w-[55%] truncate" title={item.filename}>{item.filename}</p>
    <div className="absolute top-4 right-4 flex gap-3 text-white">
      {!item.deleted && <button className="text-xs rounded border border-white/40 px-2" disabled={blocked || pending || !editable} onClick={saveReference}>Use as ground truth</button>}
      {item.deleted ? <button disabled={blocked || pending || !editable} onClick={() => onRestore(item)} aria-label="Restore expanded image" title="Restore image"><Undo2 /></button> : <>
        <button disabled={blocked || pending || !editable} onClick={() => onEdit(item)} aria-label="Edit expanded image" title="Edit annotation"><Pencil /></button>
        <button disabled={blocked || pending || !editable} onClick={() => onDelete(item)} aria-label="Delete expanded image" title="Delete from review"><Trash2 /></button>
      </>}
      <button disabled={blocked} onClick={onClose} aria-label="Close image" title="Close (Esc)"><X /></button>
    </div>
    <img key={item.annotatedUrl} src={assetUrl(item.annotatedUrl)} alt={item.filename} className="max-w-full max-h-full object-contain" />
    <button className={`${arrow} left-2 sm:left-5`} disabled={previousDisabled} onClick={() => move(-1)} aria-label="Previous image" title="Previous image (Left arrow)"><ChevronLeft size={30} /></button>
    <button className={`${arrow} right-2 sm:right-5`} disabled={nextDisabled} onClick={() => move(1)} aria-label="Next image" title="Next image (Right arrow)"><ChevronRight size={30} /></button>
    <div className="absolute bottom-5 inset-x-0 text-center text-white text-sm space-y-2 px-16">
      {error && <p role="alert" className="text-red-300">{error}</p>}
      {notice && <p role="status" className="text-emerald-300">{notice}</p>}
      <p role="status" aria-live="polite">{pending ? "Loading images…" : `${position + 1} / ${current.total}`}</p>
      <p className="text-xs text-white/60">← Previous · Next → · Esc to close</p>
    </div>
  </div>;
}
