"use client";

import { useState, useMemo } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ChevronLeft, ChevronRight, Folder, Images, X, ZoomIn } from "lucide-react";
import Pagination from "@/components/ui/Pagination";

const statusCfg = {
  Ready:      { badge: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" },
  Processing: { badge: "bg-amber-500/10  text-amber-500  border-amber-500/20"    },
  Error:      { badge: "bg-red-500/10    text-red-500    border-red-500/20"      },
};

const SPLIT_OPTIONS = ["All", "Train", "Val", "Test"];

const splitCfg = {
  Train: { color: "bg-[var(--accent-500)]", text: "text-[var(--accent-500)]", bg: "bg-[var(--accent-500)]/10", border: "border-[var(--accent-500)]/30" },
  Val:   { color: "bg-amber-500",           text: "text-amber-500",           bg: "bg-amber-500/10",           border: "border-amber-500/30"           },
  Test:  { color: "bg-emerald-500",         text: "text-emerald-500",         bg: "bg-emerald-500/10",         border: "border-emerald-500/30"         },
};

const PAGE_SIZE = 24;

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

// ─── Split stat card ──────────────────────────────────────────────────────────

function SplitStatCard({ label, value, total, color }) {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0;
  return (
    <div className="flex-1 flex flex-col gap-1.5 p-4 rounded-xl bg-[var(--bg-hover)] border border-[var(--border-color)]">
      <div className="flex items-center gap-2">
        <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${color}`} />
        <span className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)]">{label}</span>
      </div>
      <p className="text-2xl font-bold text-[var(--text-primary)]">{value.toLocaleString()}</p>
      <p className="text-xs text-[var(--text-tertiary)]">{pct}% of total</p>
    </div>
  );
}

// ─── Lightbox ─────────────────────────────────────────────────────────────────

function Lightbox({ images, index, onClose }) {
  const [current, setCurrent] = useState(index);
  const img = images[current];
  const sc  = splitCfg[img.split] ?? splitCfg.Train;

  function prev() { setCurrent((i) => (i - 1 + images.length) % images.length); }
  function next() { setCurrent((i) => (i + 1) % images.length); }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-[60] flex flex-col items-center justify-center bg-black/92 backdrop-blur-md"
      onClick={onClose}
    >
      {/* Top bar */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.08 }}
        className="absolute top-0 left-0 right-0 flex items-center justify-between px-6 py-4 z-10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          {/* Class badge */}
          <span
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold text-white shadow-lg"
            style={{ backgroundColor: img.class.color + "cc" }}
          >
            <span className="w-2 h-2 rounded-full bg-white/70 flex-shrink-0" />
            {img.class.alias}
          </span>
          {/* Split badge */}
          <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border ${sc.bg} ${sc.text} ${sc.border}`}>
            <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${sc.color}`} />
            {img.split}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-white/40 font-mono">{img.filename}</span>
          <span className="text-xs text-white/40">{current + 1} / {images.length}</span>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/70 hover:text-white transition-all"
          >
            <X size={16} />
          </button>
        </div>
      </motion.div>

      {/* Main image area */}
      <motion.div
        initial={{ scale: 0.92, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.92, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 28 }}
        className="relative flex items-center justify-center w-full px-16 py-20"
        onClick={(e) => e.stopPropagation()}
      >
        <AnimatePresence mode="wait">
          <motion.img
            key={current}
            src={img.url}
            alt={img.filename}
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.97 }}
            transition={{ duration: 0.18 }}
            className="max-h-[62vh] max-w-full object-contain rounded-xl shadow-2xl"
          />
        </AnimatePresence>

        {/* Prev */}
        <button
          onClick={prev}
          className="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white transition-all hover:scale-105"
        >
          <ChevronLeft size={20} />
        </button>

        {/* Next */}
        <button
          onClick={next}
          className="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white transition-all hover:scale-105"
        >
          <ChevronRight size={20} />
        </button>
      </motion.div>

      {/* Bottom thumbnail strip */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="absolute bottom-0 left-0 right-0 px-6 py-4 flex justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex gap-1.5 overflow-x-auto max-w-2xl pb-1">
          {images.map((im, i) => (
            <button
              key={im.id}
              onClick={() => setCurrent(i)}
              className={`flex-shrink-0 w-12 h-9 rounded-lg overflow-hidden border-2 transition-all ${
                i === current
                  ? "border-white scale-110 shadow-lg"
                  : "border-white/20 opacity-50 hover:opacity-80 hover:border-white/40"
              }`}
            >
              <img src={im.url} alt={im.filename} className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Image Card ───────────────────────────────────────────────────────────────

function ImageCard({ img, index, onClick }) {
  const sc = splitCfg[img.split] ?? splitCfg.Train;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.94 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.03, duration: 0.2, ease: "easeOut" }}
      whileHover={{ y: -3, transition: { duration: 0.18 } }}
      onClick={onClick}
      className="group relative rounded-xl overflow-hidden border border-[var(--border-color)] bg-[var(--bg-main)] cursor-pointer shadow-sm hover:shadow-xl hover:border-[var(--border-hover)] transition-shadow duration-200"
    >
      {/* Image */}
      <div className="aspect-[4/3] overflow-hidden">
        <img
          src={img.url}
          alt={img.filename}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-400"
        />
      </div>

      {/* Gradient overlay — always present, intensifies on hover */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent opacity-80 group-hover:opacity-100 transition-opacity duration-200" />

      {/* Zoom icon on hover */}
      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
          <ZoomIn size={18} className="text-white" />
        </div>
      </div>

      {/* Split badge — top right */}
      <div className="absolute top-2 right-2">
        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold border ${sc.bg} ${sc.text} ${sc.border} backdrop-blur-sm`}>
          <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${sc.color}`} />
          {img.split}
        </span>
      </div>

      {/* Class label — bottom */}
      <div className="absolute bottom-0 left-0 right-0 px-2.5 py-2">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full flex-shrink-0 ring-1 ring-white/30" style={{ backgroundColor: img.class.color }} />
          <span className="text-[10px] font-bold text-white truncate">{img.class.alias}</span>
        </div>
        <p className="text-[9px] text-white/50 font-mono mt-0.5 truncate">{img.filename}</p>
      </div>
    </motion.div>
  );
}

// ─── Image Browser ────────────────────────────────────────────────────────────

function ImageBrowser({ dataset }) {
  const [splitFilter, setSplitFilter]     = useState("All");
  const [classFilter, setClassFilter]     = useState("All");
  const [page, setPage]                   = useState(1);
  const [lightboxIndex, setLightboxIndex] = useState(null);

  const filtered = useMemo(() => {
    return (dataset.sampleImages ?? []).filter((img) => {
      const matchSplit = splitFilter === "All" || img.split === splitFilter;
      const matchClass = classFilter === "All" || img.class.name === classFilter;
      return matchSplit && matchClass;
    });
  }, [dataset.sampleImages, splitFilter, classFilter]);

  const paginated = useMemo(() => {
    const start = (page - 1) * PAGE_SIZE;
    return filtered.slice(start, start + PAGE_SIZE);
  }, [filtered, page]);

  function handleSplitChange(val) { setSplitFilter(val); setPage(1); }
  function handleClassChange(val) { setClassFilter(val); setPage(1); }

  const classOptions = [{ name: "All", alias: "All Classes", color: null }, ...dataset.classes];

  return (
    <div className="flex flex-col gap-4">

      {/* Filter bar — single responsive row */}
      <div className="flex flex-wrap items-center gap-2">

        {/* Split group */}
        <div className="flex items-center bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-lg p-0.5">
          {SPLIT_OPTIONS.map((s) => (
            <button
              key={s}
              onClick={() => handleSplitChange(s)}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                splitFilter === s
                  ? "bg-[var(--accent-500)] text-white shadow-sm"
                  : "text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Divider */}
        <span className="w-px h-5 bg-[var(--border-color)] hidden sm:block" />

        {/* Class group */}
        <div className="flex flex-wrap items-center gap-1.5">
          {classOptions.map((c) => (
            <button
              key={c.name}
              onClick={() => handleClassChange(c.name)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                classFilter === c.name
                  ? "border-[var(--accent-500)] bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
                  : "border-[var(--border-color)] text-[var(--text-tertiary)] hover:border-[var(--border-hover)] hover:text-[var(--text-primary)]"
              }`}
            >
              {c.color && <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: c.color }} />}
              {c.alias}
            </button>
          ))}
        </div>

        {/* Result count */}
        <span className="text-xs text-[var(--text-tertiary)] ml-auto whitespace-nowrap">
          <span className="font-semibold text-[var(--text-primary)]">{filtered.length.toLocaleString()}</span>
          {" "}images
          {(splitFilter !== "All" || classFilter !== "All") && (
            <span> · from {dataset.totalImages.toLocaleString()}</span>
          )}
        </span>
      </div>

      {/* Grid */}
      {paginated.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 py-16 rounded-xl border border-dashed border-[var(--border-color)]">
          <div className="w-12 h-12 rounded-xl bg-[var(--bg-hover)] flex items-center justify-center">
            <Images size={22} className="text-[var(--text-tertiary)]" strokeWidth={1.5} />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium text-[var(--text-secondary)]">No images match filters</p>
            <p className="text-xs text-[var(--text-tertiary)] mt-0.5">Try changing the split or class filter.</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
          {paginated.map((img, i) => (
            <ImageCard key={img.id} img={img} index={i} onClick={() => setLightboxIndex(i)} />
          ))}
        </div>
      )}

      {/* Pagination */}
      {filtered.length > PAGE_SIZE && (
        <div className="pt-2 border-t border-[var(--border-color)]">
          <Pagination
            page={page}
            pageSize={PAGE_SIZE}
            totalItems={filtered.length}
            onPageChange={setPage}
            onPageSizeChange={() => {}}
          />
        </div>
      )}

      <AnimatePresence>
        {lightboxIndex !== null && (
          <Lightbox images={paginated} index={lightboxIndex} onClose={() => setLightboxIndex(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── DatasetDetail ────────────────────────────────────────────────────────────

export default function DatasetDetail({ dataset, onBack }) {
  if (!dataset) return null;
  const cfg = statusCfg[dataset.status] ?? statusCfg.Ready;
  const maxCount = Math.max(...dataset.classes.map((c) => c.count));

  return (
    <motion.div
      key="detail"
      initial={{ opacity: 0, x: 40 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 40 }}
      transition={{ duration: 0.22, ease: "easeOut" }}
      className="md:flex-1 md:min-h-0 flex flex-col surface rounded-xl [overflow:clip]"
    >
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-3 px-5 py-4 bg-[var(--bg-main)] border-b border-[var(--border-color)] min-w-0">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-[var(--text-tertiary)] hover:text-[var(--text-primary)] transition-colors flex-shrink-0">
          <ArrowLeft size={16} />
          Datasets
        </button>
        <span className="text-[var(--border-color)]">/</span>
        <p className="text-sm font-bold text-[var(--text-primary)] truncate">{dataset.name}</p>
        <span className={`flex-shrink-0 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide border ${cfg.badge}`}>
          {dataset.status}
        </span>
      </div>

      {/* Info strip */}
      <div className="flex-shrink-0 flex flex-wrap items-center gap-x-4 gap-y-1 px-5 py-2.5 border-b border-[var(--border-color)]">
        {[
          { label: "Project", value: dataset.projectName },
          { label: "Images",  value: dataset.totalImages.toLocaleString() },
          { label: "Classes", value: dataset.classes.length },
        ].map((item) => (
          <span key={item.label} className="text-xs">
            <span className="text-[var(--text-tertiary)]">{item.label}: </span>
            <span className="font-semibold text-[var(--text-primary)]">{item.value}</span>
          </span>
        ))}
        <span className="text-[var(--border-color)] hidden sm:inline">·</span>
        <div className="flex items-center gap-1">
          <Folder size={11} className="text-[var(--text-tertiary)]" />
          <span className="text-xs font-mono text-[var(--text-tertiary)]">{dataset.path}</span>
        </div>
        <span className="text-[var(--border-color)] hidden sm:inline">·</span>
        <span className="text-xs text-[var(--text-tertiary)]">Updated {formatDate(dataset.updatedAt)}</span>
      </div>

      {/* Scrollable body */}
      <div className="flex-1 min-h-0 overflow-auto p-5 flex flex-col gap-6">

        {/* Split */}
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Dataset Split</h2>
          <div className="flex gap-3">
            <SplitStatCard label="Train" value={dataset.split.train} total={dataset.totalImages} color="bg-[var(--accent-500)]" />
            <SplitStatCard label="Val"   value={dataset.split.val}   total={dataset.totalImages} color="bg-amber-500" />
            <SplitStatCard label="Test"  value={dataset.split.test}  total={dataset.totalImages} color="bg-emerald-500" />
          </div>
          <div className="flex h-2 rounded-full overflow-hidden gap-px">
            <div className="bg-[var(--accent-500)] rounded-full" style={{ width: `${(dataset.split.train / dataset.totalImages) * 100}%` }} />
            <div className="bg-amber-500 rounded-full"           style={{ width: `${(dataset.split.val   / dataset.totalImages) * 100}%` }} />
            <div className="bg-emerald-500 rounded-full"         style={{ width: `${(dataset.split.test  / dataset.totalImages) * 100}%` }} />
          </div>
        </section>

        {/* Class distribution */}
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Class Distribution</h2>
          <div className="flex flex-col gap-2">
            {dataset.classes.map((cls) => {
              const pct = maxCount > 0 ? (cls.count / maxCount) * 100 : 0;
              return (
                <div key={cls.name} className="flex items-center gap-3">
                  <div className="flex items-center gap-2 w-32 flex-shrink-0">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: cls.color }} />
                    <span className="text-xs font-semibold text-[var(--text-primary)] truncate">{cls.alias}</span>
                  </div>
                  <div className="flex-1 h-2 rounded-full bg-[var(--bg-hover)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: cls.color }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-[var(--text-secondary)] w-16 text-right flex-shrink-0">
                    {cls.count.toLocaleString()}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        {/* Image browser */}
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Image Browser</h2>
          <ImageBrowser dataset={dataset} />
        </section>

      </div>
    </motion.div>
  );
}
