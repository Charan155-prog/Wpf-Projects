"use client";

import { motion } from "framer-motion";
import { Folder } from "lucide-react";

export const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.96 },
  show:   { opacity: 1, y: 0,  scale: 1, transition: { type: "spring", stiffness: 280, damping: 22 } },
  exit:   { opacity: 0, scale: 0.94,     transition: { duration: 0.15 } },
};

const statusCfg = {
  Ready:      { dot: "bg-emerald-500", badge: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" },
  Processing: { dot: "bg-amber-400",   badge: "bg-amber-500/10  text-amber-500  border-amber-500/20"    },
  Error:      { dot: "bg-red-500",     badge: "bg-red-500/10    text-red-500    border-red-500/20"      },
};

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export default function DatasetCard({ dataset, onView }) {
  const cfg = statusCfg[dataset.status] ?? statusCfg.Ready;
  const { totalImages, split, classes } = dataset;

  return (
    <motion.div
      variants={cardVariants}
      whileHover={{ y: -2, transition: { duration: 0.18 } }}
      onClick={() => onView(dataset)}
      className="bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-xl p-4 flex flex-col gap-3 cursor-pointer hover:shadow-md hover:border-[var(--border-hover)] transition-all duration-200 group"
    >
      {/* Name + status */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-sm font-bold text-[var(--text-primary)] leading-snug group-hover:text-[var(--accent-500)] transition-colors">{dataset.name}</p>
          <p className="text-xs text-[var(--text-tertiary)] mt-0.5 truncate">↳ {dataset.projectName}</p>
        </div>
        <span className={`flex-shrink-0 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide border ${cfg.badge}`}>
          {dataset.status}
        </span>
      </div>

      {/* Image count + split bar */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-end justify-between">
          <span className="text-2xl font-bold text-[var(--text-primary)]">{totalImages.toLocaleString()}</span>
          <span className="text-xs text-[var(--text-tertiary)] mb-0.5">images</span>
        </div>

        {/* Split bar */}
        <div className="flex h-1.5 rounded-full overflow-hidden gap-px">
          <div className="bg-[var(--accent-500)] rounded-full" style={{ width: `${(split.train / totalImages) * 100}%` }} />
          <div className="bg-amber-500 rounded-full"           style={{ width: `${(split.val   / totalImages) * 100}%` }} />
          <div className="bg-emerald-500 rounded-full"         style={{ width: `${(split.test  / totalImages) * 100}%` }} />
        </div>

        {/* Split labels */}
        <div className="flex items-center gap-3">
          {[
            { label: "Train", value: split.train, color: "bg-[var(--accent-500)]" },
            { label: "Val",   value: split.val,   color: "bg-amber-500" },
            { label: "Test",  value: split.test,  color: "bg-emerald-500" },
          ].map((s) => (
            <span key={s.label} className="flex items-center gap-1 text-[10px] text-[var(--text-tertiary)]">
              <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${s.color}`} />
              {s.label} {s.value.toLocaleString()}
            </span>
          ))}
        </div>
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-1.5">
        <span className="px-2 py-0.5 rounded-md bg-[var(--bg-main)] border border-[var(--border-color)] text-[10px] font-semibold text-[var(--text-tertiary)]">
          {classes.length} classes
        </span>
        {classes.slice(0, 2).map((c) => (
          <span key={c.name} className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-[var(--bg-main)] border border-[var(--border-color)] text-[10px] font-semibold text-[var(--text-tertiary)]">
            <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: c.color }} />
            {c.alias}
          </span>
        ))}
        {classes.length > 2 && (
          <span className="px-2 py-0.5 rounded-md bg-[var(--bg-main)] border border-[var(--border-color)] text-[10px] font-semibold text-[var(--text-tertiary)]">
            +{classes.length - 2}
          </span>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center gap-2 pt-1 border-t border-[var(--border-color)]">
        <Folder size={11} className="text-[var(--text-tertiary)] flex-shrink-0" />
        <span className="text-[10px] font-mono text-[var(--text-tertiary)] truncate flex-1">{dataset.path}</span>
        <span className="text-[10px] text-[var(--text-tertiary)] flex-shrink-0">Updated {formatDate(dataset.updatedAt)}</span>
      </div>
    </motion.div>
  );
}
