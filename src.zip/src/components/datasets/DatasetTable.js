"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Folder } from "lucide-react";

const rowVariants = {
  hidden: { opacity: 0, x: -14 },
  show:   (i) => ({ opacity: 1, x: 0, transition: { delay: i * 0.045, duration: 0.22, ease: "easeOut" } }),
  exit:   { opacity: 0, x: 12, transition: { duration: 0.14 } },
};

const statusCfg = {
  Ready:      { dot: "bg-emerald-500", text: "text-emerald-500" },
  Processing: { dot: "bg-amber-400",   text: "text-amber-500"   },
  Error:      { dot: "bg-red-500",     text: "text-red-500"     },
};

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export default function DatasetTable({ datasets, onView }) {
  if (datasets.length === 0) return null;

  return (
    <table className="w-full text-left min-w-[720px]">
      <thead className="sticky top-0 z-10 bg-[var(--bg-main)]">
        <tr className="border-b border-[var(--border-color)]">
          {["Dataset", "Project", "Images", "Train / Val / Test", "Classes", "Status", "Updated"].map((h) => (
            <th key={h} className="px-4 py-3 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest whitespace-nowrap">{h}</th>
          ))}
        </tr>
      </thead>
      <tbody className="divide-y divide-[var(--border-color)]/50">
        <AnimatePresence initial={false}>
          {datasets.map((d, i) => {
            const cfg = statusCfg[d.status] ?? statusCfg.Ready;
            return (
              <motion.tr
                key={d.id}
                custom={i}
                variants={rowVariants}
                initial="hidden"
                animate="show"
                exit="exit"
                onClick={() => onView(d)}
                className="hover:bg-[var(--bg-hover)] cursor-pointer transition-colors group"
              >
                <td className="px-4 py-3">
                  <div>
                    <p className="text-sm font-semibold text-[var(--text-primary)] group-hover:text-[var(--accent-500)] transition-colors">{d.name}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <Folder size={10} className="text-[var(--text-tertiary)]" />
                      <span className="text-[10px] font-mono text-[var(--text-tertiary)] truncate max-w-[160px]">{d.path}</span>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">{d.projectName}</td>
                <td className="px-4 py-3 text-sm font-semibold text-[var(--text-primary)]">{d.totalImages.toLocaleString()}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1 min-w-[140px]">
                    <div className="flex h-1.5 rounded-full overflow-hidden gap-px">
                      <div className="bg-[var(--accent-500)] rounded-full" style={{ width: `${(d.split.train / d.totalImages) * 100}%` }} />
                      <div className="bg-amber-500 rounded-full"           style={{ width: `${(d.split.val   / d.totalImages) * 100}%` }} />
                      <div className="bg-emerald-500 rounded-full"         style={{ width: `${(d.split.test  / d.totalImages) * 100}%` }} />
                    </div>
                    <p className="text-[10px] text-[var(--text-tertiary)]">
                      {d.split.train} · {d.split.val} · {d.split.test}
                    </p>
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">{d.classes.length}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                    <span className={`text-xs font-medium ${cfg.text}`}>{d.status}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs text-[var(--text-tertiary)] whitespace-nowrap">{formatDate(d.updatedAt)}</td>
              </motion.tr>
            );
          })}
        </AnimatePresence>
      </tbody>
    </table>
  );
}
