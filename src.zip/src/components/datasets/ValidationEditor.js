"use client";
import { useRef, useState } from "react";
import { X, Trash2, WandSparkles, Save } from "lucide-react";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";

export default function ValidationEditor({ dataset, item, onClose, onSaved, initialModel }) {
  const [regions, setRegions] = useState([]);
  const [points, setPoints] = useState([]);
  const [shape, setShape] = useState("rectangle");
  const [classId, setClassId] = useState(0);
  const [tab, setTab] = useState("raw");
  const [preview, setPreview] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const start = useRef(null);
  const svg = useRef(null);
  const [loaded, setLoaded] = useState(false);
  const [model, setModel] = useState(dataset.annotationModel === "sam2" ? "sam2" : initialModel || "sam3");
  const [method, setMethod] = useState("model");
  const [selectedRegion, setSelectedRegion] = useState(0);
  function point(event) {
    const box = svg.current.getBoundingClientRect();
    return [Math.max(0, Math.min(1, (event.clientX - box.left) / box.width)), Math.max(0, Math.min(1, (event.clientY - box.top) / box.height))];
  }
  function rectangle(a, b) { return [[a[0], a[1]], [b[0], a[1]], [b[0], b[1]], [a[0], b[1]]]; }
  function addRegion(next) {
    setSelectedRegion(regions.length);
    setRegions((current) => [...current, { classId, points: next, clicks: [], clickLabels: [] }]); setPoints([]); setPreview(null);
  }
  function pointerDown(event) {
    if (busy || !loaded) return;
    if (shape === "positive" || shape === "negative") {
      if (!regions[selectedRegion]) { setError("Draw and select an object region first."); return; }
      const click = point(event);
      setRegions((current) => current.map((r, i) => i === selectedRegion ? { ...r, clicks: [...(r.clicks || []), click], clickLabels: [...(r.clickLabels || []), shape === "positive" ? 1 : 0] } : r));
      setPreview(null); return;
    }
    if (shape === "polygon") { setPoints((current) => [...current, point(event)]); setPreview(null); return; }
    start.current = point(event); event.currentTarget.setPointerCapture(event.pointerId);
  }
  function pointerUp(event) {
    if (shape !== "rectangle" || !start.current) return;
    const end = point(event), origin = start.current; start.current = null;
    if (Math.abs(end[0] - origin[0]) > 0.003 && Math.abs(end[1] - origin[1]) > 0.003) addRegion(rectangle(origin, end));
    else setPoints([]);
  }
  async function generate() {
    setBusy(true); setError("");
    try {
      const result = await datasetRequest(`/datasets/${dataset.id}/images/${item.id}/preview`, { method: "POST", body: JSON.stringify({ revision: dataset.revision, regions, model, method }) });
      setPreview(result); setTab("preview");
    } catch (error) { setError(error.message); }
    finally { setBusy(false); }
  }
  async function reprocess() {
    setBusy(true); setError("");
    try { const result = await datasetRequest(`/datasets/${dataset.id}/images/${item.id}/reprocess`, { method: "POST", body: JSON.stringify({ revision: dataset.revision, model, confidence: .25 }) }); setPreview(result); setTab("preview"); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function save() {
    setBusy(true); setError("");
    try {
      await datasetRequest(`/datasets/${dataset.id}/images/${item.id}/commit`, { method: "POST", body: JSON.stringify({ revision: dataset.revision, previewId: preview.previewId }) });
      await onSaved();
    } catch (error) { setError(error.message); }
    finally { setBusy(false); }
  }
  const polygon = (values) => values.map(([x, y]) => `${x * 1000},${y * 1000}`).join(" ");
  return <div role="dialog" aria-modal="true" aria-label="Edit annotation" className="fixed inset-0 z-[100] bg-black/75 p-3 sm:p-6 flex items-center justify-center">
    <div className="surface rounded-xl w-full max-w-6xl max-h-[95vh] flex flex-col overflow-hidden shadow-2xl">
      <div className="flex items-center gap-3 p-4 border-b border-[var(--border-color)]"><div className="flex-1 min-w-0"><h2 className="font-semibold truncate">Edit: {item.filename}</h2><p className="text-xs text-[var(--text-secondary)]">{dataset.mode} · One ROI per object · Existing class IDs are preserved</p></div><button disabled={busy} onClick={onClose} aria-label="Close editor"><X size={20} /></button></div>
      <div className="p-4 overflow-auto flex-1">
        <p className="text-xs mb-3 text-amber-400">Save replaces this image’s annotations. Include every object to keep.</p>
        <div className="flex flex-wrap gap-3 items-center mb-3 text-sm"><label>Model <select aria-label="Semi-annotation model" value={model} disabled={busy || dataset.annotationModel === "sam2"} onChange={(e) => { setModel(e.target.value); setPreview(null); }} className="rounded-lg p-2 bg-[var(--bg-hover)]"><option value="sam2">SAM2</option><option value="sam3">SAM3</option></select></label><label>Correction <select aria-label="Correction method" disabled={busy} value={method} onChange={(e) => { setMethod(e.target.value); setPreview(null); }} className="rounded-lg p-2 bg-[var(--bg-hover)]"><option value="model">Model assisted</option><option value="manual">Exact manual ROI</option></select></label><button disabled={busy} onClick={reprocess} className="rounded-lg border border-[var(--accent-500)] px-3 py-2 text-[var(--accent-500)]">Reprocess whole image</button></div>
        <div className="flex flex-wrap gap-2 mb-3 text-sm">
          <button disabled={busy} onClick={() => setTab("raw")} className={`px-3 py-2 rounded-lg ${tab === "raw" ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)]"}`}>Raw image / draw ROI</button>
          <button disabled={busy} onClick={() => setTab("original")} className={`px-3 py-2 rounded-lg ${tab === "original" ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)]"}`}>Current annotation</button>
          <button disabled={busy || !preview} onClick={() => setTab("preview")} className={`px-3 py-2 rounded-lg disabled:opacity-40 ${tab === "preview" ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)]"}`}>Correction preview</button>
        </div>
        {tab === "raw" && <div className="flex flex-wrap gap-3 items-center mb-3 text-sm">
          <label>Class <select disabled={busy} aria-label="Object class" value={classId} onChange={(event) => setClassId(Number(event.target.value))} className="bg-[var(--bg-hover)] p-2 rounded-lg max-w-72 ml-2">{dataset.classes.map((name, index) => <option key={index} value={index}>{index}: {name}</option>)}</select></label>
          <label>Tool <select disabled={busy} aria-label="ROI shape" value={shape} onChange={(event) => { setShape(event.target.value); setPoints([]); start.current = null; }} className="bg-[var(--bg-hover)] p-2 rounded-lg ml-2"><option value="rectangle">Rectangle (drag)</option><option value="polygon">Polygon (click points)</option><option value="positive">Foreground click (+)</option><option value="negative">Background click (−)</option></select></label>
          {shape === "polygon" && <button disabled={busy || points.length < 3} onClick={() => addRegion(points)} className="underline disabled:opacity-40">Finish polygon</button>}
          <button disabled={busy} onClick={() => { setPoints([]); setRegions([]); setPreview(null); }} className="text-[var(--text-secondary)]">Clear regions</button>
        </div>}
        <div className="bg-black/50 rounded-lg p-2 text-center">
          {tab === "raw" ? <div className="relative inline-block max-w-full leading-none">
            <img src={assetUrl(item.rawUrl)} alt="Clean raw image for ROI correction" draggable={false} onLoad={() => setLoaded(true)} onError={() => { setLoaded(false); setError("Could not load the raw image."); }} className="max-h-[48vh] max-w-full w-auto block" />
            <svg ref={svg} viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-label="Draw object ROI" className="absolute inset-0 w-full h-full cursor-crosshair touch-none" onPointerDown={pointerDown} onPointerMove={(event) => { if (start.current && !busy) setPoints(rectangle(start.current, point(event))); }} onPointerUp={pointerUp} onPointerCancel={() => { start.current = null; setPoints([]); }}>
              {regions.map((region, index) => <polygon key={index} points={polygon(region.points)} fill="rgba(99,102,241,0.2)" stroke="#818cf8" strokeWidth="2" vectorEffect="non-scaling-stroke" />)}
              {regions.flatMap((r, i) => (r.clicks || []).map(([x, y], j) => <circle key={`${i}-${j}`} cx={x*1000} cy={y*1000} r="6" fill={r.clickLabels[j] ? "#34d399" : "#fb7185"} stroke="white" strokeWidth="1" />))}
              {points.length > 0 && <polyline points={polygon(points)} fill="rgba(16,185,129,0.15)" stroke="#34d399" strokeWidth="2" vectorEffect="non-scaling-stroke" />}
            </svg>
          </div> : <img src={assetUrl(tab === "preview" ? preview?.annotatedUrl : item.annotatedUrl)} alt={tab === "preview" ? "Proposed correction" : "Current annotation"} className="max-h-[48vh] max-w-full mx-auto object-contain" />}
        </div>
        <div className="flex flex-wrap gap-2 mt-3">{regions.map((region, index) => <span key={index} className={`inline-flex items-center gap-2 rounded-lg bg-[var(--bg-hover)] px-3 py-1.5 text-xs border ${selectedRegion === index ? "border-[var(--accent-500)]" : "border-transparent"}`}><button disabled={busy} onClick={() => setSelectedRegion(index)}>{index + 1}. {dataset.classes[region.classId]} · {region.clicks?.length || 0} clicks</button><button disabled={busy} aria-label={`Remove region ${index + 1}`} onClick={() => { setRegions(regions.filter((_, i) => i !== index)); setSelectedRegion(0); setPreview(null); setTab("raw"); }}><Trash2 size={13} /></button></span>)}</div>
        {error && <p role="alert" className="text-red-400 mt-3 text-sm">{error}</p>}
      </div>
      <div className="p-4 border-t border-[var(--border-color)] flex flex-wrap gap-3 justify-end">
        <button disabled={busy} onClick={onClose} className="px-3 py-2">Cancel</button>
        <button disabled={busy || !regions.length || points.length > 0} onClick={generate} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-[var(--border-color)] disabled:opacity-40"><WandSparkles size={16} />{busy ? "Working…" : method === "manual" ? "Preview manual ROI" : `Preview with ${model.toUpperCase()}`}</button>
        <button disabled={busy || !preview} onClick={save} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[var(--accent-500)] text-white disabled:opacity-40"><Save size={16} />Save correction</button>
      </div>
    </div>
  </div>;
}
