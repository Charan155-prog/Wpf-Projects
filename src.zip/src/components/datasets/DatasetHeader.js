"use client";

import { Database } from "lucide-react";

export default function DatasetHeader({ stats }) {
  return (
    <div className="app-page-header flex-shrink-0 flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 surface rounded-xl shadow-sm">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)] flex items-center justify-center flex-shrink-0 border border-[var(--accent-500)]/20">
          <Database size={24} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)] leading-tight">Datasets</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">View datasets loaded for each project and their train/val/test splits.</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {[
          { label: "Total",    value: stats.total,                              color: "text-[var(--text-primary)]" },
          { label: "Ready",    value: stats.ready,                              color: "text-emerald-500" },
          { label: "Images",   value: stats.totalImages.toLocaleString(),       color: "text-[var(--accent-500)]" },
        ].map((s) => (
          <div key={s.label} className="flex flex-col items-center px-4 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] min-w-[80px]">
            <span className={`text-xl font-bold leading-none ${s.color}`}>{s.value}</span>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)] mt-1">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
