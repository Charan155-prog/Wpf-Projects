"use client";

import { motion } from "framer-motion";

export default function Placeholder({ title, description }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col items-center justify-center h-full text-center"
    >
      <div className="w-24 h-24 mb-6 rounded-full flex items-center justify-center surface" style={{ color: "var(--accent-500)" }}>
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
        </svg>
      </div>
      <h1 className="text-3xl font-bold mb-4" style={{ color: "var(--text-primary)" }}>{title}</h1>
      <p className="text-lg max-w-md" style={{ color: "var(--text-secondary)" }}>
        {description}
      </p>
      <div className="mt-8 px-6 py-2 rounded-full font-semibold text-sm surface" style={{ color: "var(--accent-500)" }}>
        Work in Progress
      </div>
    </motion.div>
  );
}
