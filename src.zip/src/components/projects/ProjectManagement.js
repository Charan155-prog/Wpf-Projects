"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft, Check, Edit3, FolderKanban, Image as ImageIcon,
  LayoutGrid, List, Plus, Search, Tags, Trash2, X,
} from "lucide-react";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Modal from "@/components/ui/Modal";
import Pagination from "@/components/ui/Pagination";
import SuccessDialog from "@/components/ui/SuccessDialog";
import { useActiveProject } from "@/context/ProjectContext";

// ─── animation variants ──────────────────────────────────────────────────────

const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.96 },
  show:   { opacity: 1, y: 0,  scale: 1,    transition: { type: "spring", stiffness: 280, damping: 22 } },
  exit:   { opacity: 0, scale: 0.94,         transition: { duration: 0.15 } },
};

const gridVariants = {
  hidden: {},
  show:   { transition: { staggerChildren: 0.07 } },
};

const rowVariants = {
  hidden: { opacity: 0, x: -14 },
  show:   (i) => ({ opacity: 1, x: 0, transition: { delay: i * 0.045, duration: 0.22, ease: "easeOut" } }),
  exit:   { opacity: 0, x: 12,  transition: { duration: 0.14 } },
};

// ─── helpers ────────────────────────────────────────────────────────────────

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

const STATUS_OPTIONS = ["Active", "Inactive"];
const MODE_OPTIONS = ["Detection", "Segmentation"];

const statusCfg = {
  Active:   { badge: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20", dot: "bg-emerald-500", pill: "border-emerald-500 bg-emerald-500/10 text-emerald-500" },
  Inactive: { badge: "bg-slate-500/10 text-slate-400 border-slate-400/20",       dot: "bg-slate-400",   pill: "border-slate-400 bg-slate-500/10 text-slate-400"      },
};

function StatusBadge({ status }) {
  const cfg = statusCfg[status] ?? statusCfg.Inactive;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide border ${cfg.badge}`}>
      {status}
    </span>
  );
}

const emptyProjectForm = { name: "", productName: "", productCode: "", productImage: "", release: "R1.0", status: "Active", mode: "Detection", description: "" };
const emptyClassForm   = { name: "", alias: "", color: "#6366f1" };

function Field({ label, children, error, className = "" }) {
  return (
    <label className={`flex flex-col gap-1.5 ${className}`}>
      <span className="text-xs font-semibold uppercase tracking-wide text-[var(--text-secondary)]">{label}</span>
      {children}
      {error && <span className="text-xs text-red-500">{error}</span>}
    </label>
  );
}

const inputCls = (err) =>
  `w-full px-3.5 py-2.5 rounded-lg bg-[var(--bg-hover)] border text-sm text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all ${err ? "border-red-500" : "border-[var(--border-color)]"}`;

// ─── ProjectCard ──────────────────────────────────────────────────────────────

function ProjectCard({ project, onManage, onEdit, onDelete }) {
  const cfg = statusCfg[project.status] ?? statusCfg.Inactive;
  return (
    <motion.div
      variants={cardVariants}
      whileHover={{ y: -2, transition: { duration: 0.18 } }}
      onClick={() => onManage(project)}
      className="bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-xl p-4 flex flex-col gap-3 cursor-pointer hover:shadow-md hover:border-[var(--border-hover)] transition-all duration-200 group"
    >
      <div className="flex items-start gap-3">
        <div className="w-14 h-14 rounded-xl overflow-hidden border border-[var(--border-color)] bg-[var(--bg-main)] flex items-center justify-center flex-shrink-0">
          {project.productImage ? (
            <img src={project.productImage} alt={project.productName} className="w-full h-full object-cover" />
          ) : (
            <ImageIcon size={20} className="text-[var(--text-tertiary)]" strokeWidth={1.5} />
          )}
        </div>
        <div className="flex-1 min-w-0 flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-sm font-bold text-[var(--text-primary)] leading-snug group-hover:text-[var(--accent-500)] transition-colors">{project.name}</p>
            <p className="text-xs text-[var(--text-tertiary)] mt-0.5 truncate">{project.productName}</p>
          </div>
          <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 mt-1 ${cfg.dot}`} />
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {[project.productCode, project.release, `${project.classes.length} classes`].map((tag) => (
          <span key={tag} className="px-2 py-0.5 rounded-md bg-[var(--bg-main)] border border-[var(--border-color)] text-[10px] font-semibold text-[var(--text-tertiary)]">
            {tag}
          </span>
        ))}
      </div>

      <div className="flex items-center gap-1.5 pt-1 border-t border-[var(--border-color)]" onClick={(e) => e.stopPropagation()}>
        <button onClick={() => onManage(project)} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold text-[var(--accent-500)] hover:bg-[var(--accent-500)]/10 transition-colors">
          <Tags size={12} />
          Manage Classes
        </button>
        <button onClick={() => onEdit(project)} className="p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--accent-500)] hover:bg-[var(--accent-500)]/10 transition-all" title="Edit">
          <Edit3 size={13} />
        </button>
        <button onClick={() => onDelete(project)} className="p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-red-500 hover:bg-red-500/10 transition-all" title="Delete">
          <Trash2 size={13} />
        </button>
      </div>
    </motion.div>
  );
}

// ─── ProjectTable ─────────────────────────────────────────────────────────────

function ProjectTable({ projects, onManage, onEdit, onDelete }) {
  if (projects.length === 0) return null;
  return (
    <table className="w-full text-left min-w-[600px]">
      <thead className="sticky top-0 z-10 bg-[var(--bg-main)]">
        <tr className="border-b border-[var(--border-color)]">
          {["Project", "Product", "Code", "Release", "Status", "Classes", ""].map((h) => (
            <th key={h} className={`px-4 py-3 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest ${h === "" ? "text-right" : ""}`}>{h}</th>
          ))}
        </tr>
      </thead>
      <tbody className="divide-y divide-[var(--border-color)]/50">
        <AnimatePresence initial={false}>
          {projects.map((p, i) => {
            const cfg = statusCfg[p.status] ?? statusCfg.Inactive;
            return (
              <motion.tr key={p.id} custom={i} variants={rowVariants} initial="hidden" animate="show" exit="exit" onClick={() => onManage(p)} className="hover:bg-[var(--bg-hover)] cursor-pointer transition-colors group">
                <td className="px-4 py-3"><span className="text-sm font-semibold text-[var(--text-primary)] group-hover:text-[var(--accent-500)] transition-colors">{p.name}</span></td>
                <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">{p.productName}</td>
                <td className="px-4 py-3 text-xs font-mono text-[var(--text-tertiary)]">{p.productCode}</td>
                <td className="px-4 py-3 text-xs text-[var(--text-secondary)]">{p.release}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                    <span className="text-xs text-[var(--text-secondary)]">{p.status}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">{p.classes.length}</td>
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <div className="flex justify-end gap-1">
                    <button onClick={() => onManage(p)} className="p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--accent-500)] hover:bg-[var(--accent-500)]/10 transition-all" title="Manage Classes"><Tags size={14} /></button>
                    <button onClick={() => onEdit(p)} className="p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--accent-500)] hover:bg-[var(--accent-500)]/10 transition-all" title="Edit"><Edit3 size={14} /></button>
                    <button onClick={() => onDelete(p)} className="p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-red-500 hover:bg-red-500/10 transition-all" title="Delete"><Trash2 size={14} /></button>
                  </div>
                </td>
              </motion.tr>
            );
          })}
        </AnimatePresence>
      </tbody>
    </table>
  );
}

// ─── ClassTable with inline add / edit rows ───────────────────────────────────

function EditableRow({ form, errors, onChange, onSave, onCancel }) {
  return (
    <tr className="bg-[var(--accent-500)]/5 border-b border-[var(--accent-500)]/20">
      <td className="px-4 py-2.5">
        <div className="flex items-center gap-2">
          <input
            type="color"
            value={form.color}
            onChange={(e) => onChange("color", e.target.value)}
            className="w-7 h-7 rounded-md border border-[var(--border-color)] bg-transparent cursor-pointer p-0.5 flex-shrink-0"
          />
          <div className="flex-1">
            <input
              value={form.name}
              onChange={(e) => onChange("name", e.target.value)}
              placeholder="Class name"
              autoFocus
              className={`w-full px-2.5 py-1.5 rounded-lg text-sm bg-[var(--bg-surface)] border text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all ${errors.name ? "border-red-500" : "border-[var(--border-color)]"}`}
            />
            {errors.name && <p className="text-[10px] text-red-500 mt-0.5 px-0.5">{errors.name}</p>}
          </div>
        </div>
      </td>
      <td className="px-4 py-2.5">
        <div>
          <input
            value={form.alias}
            onChange={(e) => onChange("alias", e.target.value)}
            placeholder="Alias"
            className={`w-full px-2.5 py-1.5 rounded-lg text-sm bg-[var(--bg-surface)] border text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all ${errors.alias ? "border-red-500" : "border-[var(--border-color)]"}`}
          />
          {errors.alias && <p className="text-[10px] text-red-500 mt-0.5 px-0.5">{errors.alias}</p>}
        </div>
      </td>
      <td className="px-4 py-2.5">
        <div className="flex justify-end gap-1.5">
          <button
            onClick={onSave}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-xs font-semibold transition-colors"
          >
            <Check size={12} />
            Save
          </button>
          <button
            onClick={onCancel}
            className="p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-all"
          >
            <X size={14} />
          </button>
        </div>
      </td>
    </tr>
  );
}

function ClassTable({ classes, editingClassId, isAdding, form, errors, onChange, onSave, onCancel, onStartEdit, onDelete }) {
  const isEmpty = classes.length === 0 && !isAdding;

  return (
    <div className="flex-1 min-h-0 overflow-auto">
      {isEmpty ? (
        <div className="h-full min-h-[160px] flex items-center justify-center text-center p-10">
          <div>
            <Tags size={32} className="text-[var(--text-tertiary)] mx-auto mb-2.5" strokeWidth={1.5} />
            <p className="text-sm font-medium text-[var(--text-secondary)]">No classes yet</p>
            <p className="text-xs text-[var(--text-tertiary)] mt-1">Click "Add Class" to get started.</p>
          </div>
        </div>
      ) : (
        <table className="w-full text-left min-w-[360px]">
          <thead className="sticky top-0 z-10 bg-[var(--bg-main)]">
            <tr className="border-b border-[var(--border-color)]">
              <th className="px-4 py-3 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Class Name</th>
              <th className="px-4 py-3 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Alias</th>
              <th className="px-4 py-3 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--border-color)]/50">
            <AnimatePresence initial={false}>
              {classes.map((cls, i) =>
                cls.id === editingClassId ? (
                  <EditableRow key={cls.id} form={form} errors={errors} onChange={onChange} onSave={onSave} onCancel={onCancel} />
                ) : (
                  <motion.tr
                    key={cls.id}
                    custom={i}
                    variants={rowVariants}
                    initial="hidden"
                    animate="show"
                    exit="exit"
                    className="hover:bg-[var(--bg-hover)] transition-colors"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: cls.color }} />
                        <span className="text-sm font-semibold text-[var(--text-primary)]">{cls.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">{cls.alias}</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => onStartEdit(cls)} className="p-2 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--accent-500)] hover:bg-[var(--accent-500)]/10 transition-all" title="Edit">
                          <Edit3 size={14} />
                        </button>
                        <button onClick={() => onDelete(cls)} className="p-2 rounded-lg text-[var(--text-tertiary)] hover:text-red-500 hover:bg-red-500/10 transition-all" title="Delete">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                )
              )}
            </AnimatePresence>

            {/* New class row appended at bottom */}
            {isAdding && (
              <EditableRow form={form} errors={errors} onChange={onChange} onSave={onSave} onCancel={onCancel} />
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}

// ─── Main ────────────────────────────────────────────────────────────────────

export default function ProjectManagement() {
  const { projects, updateProjects, setActiveProject, deleteProject } = useActiveProject();
  const [searchTerm, setSearchTerm]           = useState("");
  const [viewMode, setViewMode]               = useState("grid");
  const [managingProject, setManagingProject] = useState(null);

  const [projectModal, setProjectModal]   = useState({ open: false, editing: null });
  const [projectForm, setProjectForm]     = useState(emptyProjectForm);
  const [projectErrors, setProjectErrors] = useState({});

  const [classForm, setClassForm]           = useState(emptyClassForm);
  const [classErrors, setClassErrors]       = useState({});
  const [editingClassId, setEditingClassId] = useState(null);

  const [page, setPage]         = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [success, setSuccess]           = useState(null);

  const stats = {
    total:   projects.length,
    active:  projects.filter((p) => p.status === "Active").length,
    classes: projects.reduce((s, p) => s + p.classes.length, 0),
  };

  const filteredProjects = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return term
      ? projects.filter((p) => [p.name, p.productName, p.productCode, p.release, p.status].join(" ").toLowerCase().includes(term))
      : projects;
  }, [projects, searchTerm]);

  useEffect(() => { setPage(1); }, [searchTerm]);

  const paginatedProjects = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredProjects.slice(start, start + pageSize);
  }, [filteredProjects, page, pageSize]);

  const activeProject = managingProject ? projects.find((p) => p.id === managingProject.id) ?? null : null;

  function showSuccess(title, msg) { setSuccess({ title, message: msg }); }

  // ── project CRUD ──────────────────────────────────────────────
  function openAddProject() {
    setProjectForm(emptyProjectForm); setProjectErrors({});
    setProjectModal({ open: true, editing: null });
  }

  function openEditProject(project) {
    setProjectForm({ name: project.name, productName: project.productName, productCode: project.productCode, productImage: project.productImage || "", release: project.release, status: project.status, mode: project.mode || "Detection", description: project.description });
    setProjectErrors({});
    setProjectModal({ open: true, editing: project });
  }

  function setProjField(field, value) {
    setProjectForm((p) => ({ ...p, [field]: value }));
    setProjectErrors((p) => ({ ...p, [field]: "" }));
  }

  function handleImageChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { const r = reader.result?.toString() ?? ""; setProjField("productImage", r); };
    reader.readAsDataURL(file);
  }

  function handleProjectSubmit(e) {
    e.preventDefault();
    const errors = {};
    if (!projectForm.name.trim())        errors.name        = "Required.";
    if (!projectForm.productName.trim()) errors.productName = "Required.";
    if (!projectForm.productCode.trim()) errors.productCode = "Required.";
    if (Object.keys(errors).length) { setProjectErrors(errors); return; }

    const now = new Date().toISOString();
    const payload = { ...projectForm, name: projectForm.name.trim(), productName: projectForm.productName.trim(), productCode: projectForm.productCode.trim(), description: projectForm.description.trim(), updatedAt: now };

    if (projectModal.editing) {
      updateProjects((prev) => prev.map((p) => p.id === projectModal.editing.id ? { ...p, ...payload } : p));
      setActiveProject({ ...projectModal.editing, ...payload });
      showSuccess("Project Updated", `${payload.name} has been updated.`);
    } else {
      const np = { id: `proj_${Date.now()}`, ...payload, createdAt: now, classes: [] };
      updateProjects((prev) => [np, ...prev]);
      setActiveProject(np);
      showSuccess("Project Created", `${payload.name} has been created.`);
    }
    setProjectModal({ open: false, editing: null });
  }

  // ── class CRUD (inline) ───────────────────────────────────────
  function startEditClass(cls) {
    setEditingClassId(cls.id);
    setClassForm({ name: cls.name, alias: cls.alias, color: cls.color });
    setClassErrors({});
  }

  function cancelClassEdit() {
    setEditingClassId(null);
    setClassForm(emptyClassForm);
    setClassErrors({});
  }

  function setClsField(field, value) {
    setClassForm((p) => ({ ...p, [field]: value }));
    setClassErrors((p) => ({ ...p, [field]: "" }));
  }

  function handleClassSave() {
    const errors = {};
    if (!classForm.name.trim())  errors.name  = "Required.";
    if (!classForm.alias.trim()) errors.alias = "Required.";
    if (Object.keys(errors).length) { setClassErrors(errors); return; }

    const name = classForm.name.trim(); const alias = classForm.alias.trim();
    updateProjects((prev) => prev.map((p) => {
      if (p.id !== activeProject.id) return p;
      const updatedAt = new Date().toISOString();
      if (editingClassId) return { ...p, updatedAt, classes: p.classes.map((c) => c.id === editingClassId ? { ...c, name, alias, color: classForm.color } : c) };
      return { ...p, updatedAt, classes: [...p.classes, { id: `cls_${Date.now()}`, name, alias, color: classForm.color }] };
    }));
    showSuccess(editingClassId ? "Class Updated" : "Class Added", `${alias} saved.`);
    cancelClassEdit();
  }

  // ── delete ────────────────────────────────────────────────────
  async function confirmDelete() {
    if (!deleteTarget) return;
    if (deleteTarget.type === "project") {
      try { await deleteProject(deleteTarget.item.id); }
      catch (error) { window.alert(error.message); return; }
      if (activeProject?.id === deleteTarget.item.id) setActiveProject(null);
      if (managingProject?.id === deleteTarget.item.id) setManagingProject(null);
      showSuccess("Project Deleted", `${deleteTarget.item.name} deleted.`);
    }
    if (deleteTarget.type === "class") {
      updateProjects((prev) => prev.map((p) => p.id !== activeProject.id ? p : { ...p, updatedAt: new Date().toISOString(), classes: p.classes.filter((c) => c.id !== deleteTarget.item.id) }));
      showSuccess("Class Deleted", `${deleteTarget.item.alias} deleted.`);
    }
    setDeleteTarget(null);
  }

  // ── render ────────────────────────────────────────────────────
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="w-full md:h-full flex flex-col gap-2"
    >
      {/* Page header */}
      <div className="app-page-header flex-shrink-0 flex flex-row items-center justify-between gap-3 surface rounded-xl shadow-sm">
        <h1 className="text-lg font-bold text-[var(--text-primary)]">Projects</h1>
        <div className="flex items-center gap-3">
          {[
            { label: "Total",   value: stats.total,   color: "text-[var(--text-primary)]" },
            { label: "Active",  value: stats.active,  color: "text-emerald-500" },
            { label: "Classes", value: stats.classes, color: "text-[var(--accent-500)]" },
          ].map((s) => (
            <div key={s.label} className="flex flex-col items-center px-4 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] min-w-[72px]">
              <span className={`text-xl font-bold leading-none ${s.color}`}>{s.value}</span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)] mt-1">{s.label}</span>
            </div>
          ))}
          <motion.button
            onClick={openAddProject}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold transition-colors shadow-sm"
          >
            <Plus size={16} />
            New Project
          </motion.button>
        </div>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {activeProject ? (

          /* ── Class manager ── */
          <motion.div
            key="class-manager"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="md:flex-1 md:min-h-0 flex flex-col surface rounded-xl [overflow:clip]"
          >
            {/* Header */}
            <div className="flex-shrink-0 flex items-center gap-3 px-5 py-4 bg-[var(--bg-main)] border-b border-[var(--border-color)] min-w-0">
              <button
                onClick={() => { setManagingProject(null); cancelClassEdit(); }}
                className="flex items-center gap-1.5 text-sm font-semibold text-[var(--text-tertiary)] hover:text-[var(--text-primary)] transition-colors flex-shrink-0"
              >
                <ArrowLeft size={16} />
                Projects
              </button>
              <span className="text-[var(--border-color)]">/</span>
              <p className="text-sm font-bold text-[var(--text-primary)] truncate">{activeProject.name}</p>
              <StatusBadge status={activeProject.status} />
            </div>

            {/* Info strip + add form */}
            <div className="flex-shrink-0 flex flex-wrap items-end gap-x-4 gap-y-2 px-5 py-3 border-b border-[var(--border-color)]">
              {/* Meta info */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 self-center">
                {[
                  { label: "Product", value: activeProject.productName },
                  { label: "Code",    value: activeProject.productCode },
                  { label: "Release", value: activeProject.release },
                  { label: "Mode", value: activeProject.mode || "Detection" },
                  { label: "Classes", value: activeProject.classes.length },
                ].map((item) => (
                  <span key={item.label} className="text-xs">
                    <span className="text-[var(--text-tertiary)]">{item.label}: </span>
                    <span className="font-semibold text-[var(--text-primary)]">{item.value}</span>
                  </span>
                ))}
                <span className="text-[var(--border-color)] hidden sm:inline">·</span>
                <span className="text-xs text-[var(--text-tertiary)]">Updated {formatDate(activeProject.updatedAt)}</span>
              </div>

              {/* Add class fields */}
              <div className="flex items-center gap-4 ml-auto flex-wrap">
                <span className="flex items-center gap-2 text-sm">
                  <span className="text-[var(--text-tertiary)] font-medium">Colour:</span>
                  <input
                    type="color"
                    value={classForm.color}
                    onChange={(e) => setClsField("color", e.target.value)}
                    className="w-8 h-8 rounded-lg border border-[var(--border-color)] bg-transparent cursor-pointer p-0.5"
                  />
                </span>
                <span className="flex items-center gap-2 text-sm">
                  <span className="text-[var(--text-tertiary)] font-medium whitespace-nowrap">Class Name:</span>
                  <input
                    value={classForm.name}
                    onChange={(e) => setClsField("name", e.target.value)}
                    placeholder="e.g. cap_crack"
                    className={`w-40 px-3 py-2 rounded-lg text-sm bg-[var(--bg-hover)] border text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all ${classErrors.name ? "border-red-500" : "border-[var(--border-color)]"}`}
                  />
                </span>
                <span className="flex items-center gap-2 text-sm">
                  <span className="text-[var(--text-tertiary)] font-medium">Alias:</span>
                  <input
                    value={classForm.alias}
                    onChange={(e) => setClsField("alias", e.target.value)}
                    placeholder="e.g. Crack"
                    className={`w-32 px-3 py-2 rounded-lg text-sm bg-[var(--bg-hover)] border text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all ${classErrors.alias ? "border-red-500" : "border-[var(--border-color)]"}`}
                  />
                </span>
                <button
                  onClick={handleClassSave}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold transition-colors shadow-sm"
                >
                  <Plus size={14} />
                  Add
                </button>
              </div>
            </div>

            {/* Class table with inline editing */}
            <ClassTable
              classes={activeProject.classes}
              editingClassId={editingClassId}
              isAdding={false}
              form={classForm}
              errors={classErrors}
              onChange={setClsField}
              onSave={handleClassSave}
              onCancel={cancelClassEdit}
              onStartEdit={startEditClass}
              onDelete={(cls) => setDeleteTarget({ type: "class", item: cls })}
            />
          </motion.div>

        ) : (

          /* ── Project grid / list ── */
          <motion.div
            key="project-grid"
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="md:flex-1 md:min-h-0 flex flex-col surface rounded-xl [overflow:clip]"
          >
            <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3 bg-[var(--bg-main)] border-b border-[var(--border-color)]">
              <div className="relative flex-1">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)] pointer-events-none" />
                <input
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search projects…"
                  className="w-full pl-9 pr-4 py-2 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] text-sm text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all"
                />
              </div>
              <div className="flex items-center bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-lg p-0.5">
                {[{ mode: "grid", Icon: LayoutGrid }, { mode: "list", Icon: List }].map(({ mode, Icon }) => (
                  <button
                    key={mode}
                    onClick={() => setViewMode(mode)}
                    className={`p-2 rounded-md transition-all ${viewMode === mode ? "bg-[var(--accent-500)] text-white shadow-sm" : "text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"}`}
                    title={mode === "grid" ? "Card view" : "List view"}
                  >
                    <Icon size={15} />
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 min-h-0 overflow-auto">
              {filteredProjects.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="h-full min-h-[200px] flex items-center justify-center text-center p-8"
                >
                  <div>
                    <FolderKanban size={40} className="text-[var(--text-tertiary)] mx-auto mb-3" strokeWidth={1.5} />
                    <p className="text-sm font-medium text-[var(--text-secondary)]">No projects found</p>
                    <p className="text-xs text-[var(--text-tertiary)] mt-1">Try a different search or create a new project.</p>
                  </div>
                </motion.div>
              ) : (
                <AnimatePresence mode="wait">
                  {viewMode === "grid" ? (
                    <motion.div
                      key="grid"
                      variants={gridVariants}
                      initial="hidden"
                      animate="show"
                      exit={{ opacity: 0, transition: { duration: 0.12 } }}
                      className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-3 p-4"
                    >
                      {paginatedProjects.map((project) => (
                        <ProjectCard key={project.id} project={project} onManage={(p) => { setManagingProject(p); setActiveProject(p); }} onEdit={openEditProject} onDelete={(p) => setDeleteTarget({ type: "project", item: p })} />
                      ))}
                    </motion.div>
                  ) : (
                    <motion.div
                      key="list"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0, transition: { duration: 0.12 } }}
                    >
                      <ProjectTable projects={paginatedProjects} onManage={(p) => { setManagingProject(p); setActiveProject(p); }} onEdit={openEditProject} onDelete={(p) => setDeleteTarget({ type: "project", item: p })} />
                    </motion.div>
                  )}
                </AnimatePresence>
              )}
            </div>

            {/* Pagination footer */}
            {filteredProjects.length > 0 && (
              <div className="flex-shrink-0 px-4 py-3 bg-[var(--bg-main)] border-t border-[var(--border-color)]">
                <Pagination
                  page={page}
                  pageSize={pageSize}
                  totalItems={filteredProjects.length}
                  onPageChange={setPage}
                  onPageSizeChange={(s) => { setPageSize(s); setPage(1); }}
                />
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Project Modal */}
      <Modal open={projectModal.open} onClose={() => setProjectModal({ open: false, editing: null })} title={projectModal.editing ? "Edit Project" : "New Project"} size="md">
        <form onSubmit={handleProjectSubmit} className="flex flex-col gap-4">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)]">
            <div className="w-14 h-14 rounded-xl overflow-hidden border border-[var(--border-color)] bg-[var(--bg-main)] flex items-center justify-center flex-shrink-0">
              {projectForm.productImage ? (
                <img src={projectForm.productImage} alt="preview" className="w-full h-full object-cover" />
              ) : (
                <ImageIcon size={18} className="text-[var(--text-tertiary)]" strokeWidth={1.5} />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-[var(--text-secondary)]">Product Image</p>
              <p className="text-[11px] text-[var(--text-tertiary)] mt-0.5">{projectForm.productImage ? "Image selected" : "Optional — shown as thumbnail on card"}</p>
            </div>
            <label className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-color)] text-xs font-semibold text-[var(--text-secondary)] hover:text-[var(--accent-500)] hover:border-[var(--accent-500)]/40 cursor-pointer transition-all">
              {projectForm.productImage ? "Change" : "Upload"}
              <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
            </label>
            {projectForm.productImage && (
              <button type="button" onClick={() => setProjField("productImage", "")} className="flex-shrink-0 text-xs font-semibold text-red-500 hover:text-red-600 transition-colors">Remove</button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Project Name *" error={projectErrors.name} className="sm:col-span-2">
              <input value={projectForm.name} onChange={(e) => setProjField("name", e.target.value)} placeholder="e.g. Bottle Cap Inspection" className={inputCls(projectErrors.name)} autoFocus />
            </Field>
            <Field label="Product Name *" error={projectErrors.productName}>
              <input value={projectForm.productName} onChange={(e) => setProjField("productName", e.target.value)} placeholder="e.g. HDPE Bottle Cap" className={inputCls(projectErrors.productName)} />
            </Field>
            <Field label="Product Code *" error={projectErrors.productCode}>
              <input value={projectForm.productCode} onChange={(e) => setProjField("productCode", e.target.value)} placeholder="e.g. BC-204" className={inputCls(projectErrors.productCode)} />
            </Field>
            <Field label="Release">
              <input value={projectForm.release} onChange={(e) => setProjField("release", e.target.value)} placeholder="e.g. R1.0" className={inputCls()} />
            </Field>
            <Field label="Status">
              <div className="flex gap-2">
                {STATUS_OPTIONS.map((s) => (
                  <button key={s} type="button" onClick={() => setProjField("status", s)}
                    className={`flex-1 py-2.5 rounded-lg text-xs font-bold border-2 transition-all ${projectForm.status === s ? statusCfg[s]?.pill : "border-[var(--border-color)] text-[var(--text-tertiary)] hover:border-[var(--border-hover)] bg-transparent"}`}>
                    {s}
                  </button>
                ))}
              </div>
            </Field>
            <Field label="Annotation Mode">
              <div className="flex gap-2">
                {MODE_OPTIONS.map((mode) => (
                  <button key={mode} type="button" onClick={() => setProjField("mode", mode)}
                    className={`flex-1 py-2.5 rounded-lg text-xs font-bold border-2 transition-all ${projectForm.mode === mode ? "border-[var(--accent-500)] bg-[var(--accent-500)]/10 text-[var(--accent-500)]" : "border-[var(--border-color)] text-[var(--text-tertiary)] hover:border-[var(--border-hover)] bg-transparent"}`}>
                    {mode}
                  </button>
                ))}
              </div>
            </Field>
            <Field label="Description" className="sm:col-span-2">
              <textarea value={projectForm.description} onChange={(e) => setProjField("description", e.target.value)} placeholder="Brief project purpose" rows={3} className={`${inputCls()} resize-none`} />
            </Field>
          </div>
          <div className="flex justify-end gap-3 pt-2 border-t border-[var(--border-color)]">
            <button type="button" onClick={() => setProjectModal({ open: false, editing: null })} className="px-4 py-2.5 text-sm font-semibold text-[var(--text-secondary)] hover:bg-[var(--bg-hover)] rounded-lg transition-colors">Cancel</button>
            <button type="submit" className="px-5 py-2.5 bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm">
              {projectModal.editing ? "Save Changes" : "Create Project"}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        variant="danger"
        title={deleteTarget?.type === "project" ? "Delete Project" : "Delete Class"}
        message={deleteTarget?.type === "project"
          ? `Permanently delete "${deleteTarget?.item.name}", its classes, annotations, validated datasets, training runs, models and inference outputs from the backend PC? Original input files and shared ML checkpoints are kept. This cannot be undone.`
          : `Delete class "${deleteTarget?.item.alias}"?`}
        confirmLabel="Delete"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <SuccessDialog open={!!success} title={success?.title} message={success?.message} onClose={() => setSuccess(null)} />
    </motion.div>
  );
}
