"use client";

import Toggle from "@/components/ui/Toggle";

export default function SecuritySettingCard({
  icon: Icon,
  title,
  description,
  enabled,
  onToggle,
  value,
  onValueChange,
  valueLabel,
  valueMin,
  valueMax,
  infoText,
}) {
  return (
    <div className="surface rounded-xl p-6 flex flex-col gap-5">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)] flex items-center justify-center flex-shrink-0 border border-[var(--accent-500)]/20">
            <Icon size={18} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[var(--text-primary)]">{title}</h3>
            <p className="text-xs text-[var(--text-tertiary)] mt-1 leading-relaxed max-w-md">
              {description}
            </p>
          </div>
        </div>
        <Toggle checked={enabled} onChange={onToggle} size="md" />
      </div>

      {enabled && (
        <div className="flex items-center gap-3 pl-14">
          <label className="text-sm text-[var(--text-secondary)] whitespace-nowrap">
            {valueLabel}
          </label>
          <input
            type="number"
            value={value}
            min={valueMin}
            max={valueMax}
            onChange={(e) => {
              const n = parseInt(e.target.value, 10);
              if (!isNaN(n)) onValueChange(Math.min(valueMax, Math.max(valueMin, n)));
            }}
            className="w-24 px-3 py-2 bg-[var(--bg-sidebar)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] text-sm text-center focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] focus:border-transparent transition-all"
          />
          <span className="text-sm text-[var(--text-tertiary)]">
            (min {valueMin} — max {valueMax})
          </span>
        </div>
      )}

      {infoText && (
        <p className="text-xs text-[var(--text-tertiary)] pl-14 leading-relaxed">{infoText}</p>
      )}
    </div>
  );
}
