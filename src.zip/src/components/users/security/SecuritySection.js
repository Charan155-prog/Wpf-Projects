"use client";

import { motion } from "framer-motion";
import { Shield, KeyRound, Save } from "lucide-react";
import SecuritySettingCard from "./SecuritySettingCard";

export default function SecuritySection({ settings, updateSetting, saveSettings, hasChanges }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col gap-4 max-w-3xl"
    >
      <SecuritySettingCard
        icon={Shield}
        title="Auto Logout"
        description="Automatically log out inactive users after a period of inactivity to protect against unauthorised access."
        enabled={settings.autoLogoutEnabled}
        onToggle={(val) => updateSetting("autoLogoutEnabled", val)}
        value={settings.autoLogoutMinutes}
        onValueChange={(val) => updateSetting("autoLogoutMinutes", val)}
        valueLabel="Inactive timeout:"
        valueMin={5}
        valueMax={480}
        infoText="Users will be redirected to the login page after the specified minutes of inactivity. Sessions with active operations are not interrupted."
      />

      <SecuritySettingCard
        icon={KeyRound}
        title="Password Expiration"
        description="Require users to reset their password after a set number of days to maintain security hygiene."
        enabled={settings.passwordExpirationEnabled}
        onToggle={(val) => updateSetting("passwordExpirationEnabled", val)}
        value={settings.passwordExpirationDays}
        onValueChange={(val) => updateSetting("passwordExpirationDays", val)}
        valueLabel="Expires after:"
        valueMin={7}
        valueMax={365}
        infoText="Users will receive a notification 7 days before their password expires and will be prompted to update it on next login after expiration."
      />

      {hasChanges && (
        <div className="flex justify-end pt-2">
          <button
            onClick={saveSettings}
            className="flex items-center gap-2 px-5 py-2.5 bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm"
          >
            <Save size={15} />
            Save Security Settings
          </button>
        </div>
      )}
    </motion.div>
  );
}
