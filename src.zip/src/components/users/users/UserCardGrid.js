"use client";

import { motion } from "framer-motion";
import UserCard from "./UserCard";

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const cardVariants = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
};

export default function UserCardGrid({ users, onEdit, onDelete }) {
  return (
    <div className="md:flex-1 md:min-h-0 overflow-y-auto">
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 pb-2"
      >
        {users.map((user) => (
          <UserCard
            key={user.id}
            user={user}
            onEdit={onEdit}
            onDelete={onDelete}
            variants={cardVariants}
          />
        ))}
      </motion.div>
    </div>
  );
}
