"use client";

import { useState } from "react";
import { ShieldCheck, Settings2, Wrench } from "lucide-react";
import Modal from "@/components/ui/Modal";
import ConfirmDialog from "@/components/ui/ConfirmDialog";

const ROLES = [
  {
    key: "Admin",
    label: "Admin",
    desc: "Full system access",
    Icon: ShieldCheck,
    avatar: "bg-indigo-500/20 text-indigo-500",
    active: "border-indigo-500 bg-indigo-500/10",
    icon: "text-indigo-500",
  },
  {
    key: "Operator",
    label: "Operator",
    desc: "Standard operations",
    Icon: Settings2,
    avatar: "bg-blue-500/20 text-blue-500",
    active: "border-blue-500 bg-blue-500/10",
    icon: "text-blue-500",
  },
  {
    key: "Technician",
    label: "Technician",
    desc: "Technical access",
    Icon: Wrench,
    avatar: "bg-emerald-500/20 text-emerald-500",
    active: "border-emerald-500 bg-emerald-500/10",
    icon: "text-emerald-500",
  },
];

const defaultForm = { name: "", role: "Operator" };

function getInitials(name) {
  const parts = name.trim().split(" ").filter(Boolean);
  return parts.length === 0 ? "?" : parts.map((p) => p[0]).join("").toUpperCase().slice(0, 2);
}

function getAvatarCls(role) {
  return ROLES.find((r) => r.key === role)?.avatar ?? "bg-gray-500/20 text-gray-500";
}

export default function AddUserModal({ open, onClose, onAddUser }) {
  const [form, setForm] = useState(defaultForm);
  const [errors, setErrors] = useState({});
  const [confirmOpen, setConfirmOpen] = useState(false);

  function set(field, value) {
    setForm((p) => ({ ...p, [field]: value }));
    setErrors((p) => ({ ...p, [field]: "" }));
  }

  function validate() {
    const errs = {};
    if (!form.name.trim()) errs.name = "Full name is required.";
    return errs;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setConfirmOpen(true);
  }

  function handleConfirmAdd() {
    onAddUser({ name: form.name.trim(), role: form.role, status: "Active" });
    setForm(defaultForm);
    setErrors({});
    setConfirmOpen(false);
    onClose();
  }

  function handleClose() {
    setForm(defaultForm);
    setErrors({});
    setConfirmOpen(false);
    onClose();
  }

  const inputCls = (field) =>
    `w-full px-3.5 py-2.5 bg-[var(--bg-hover)] border rounded-lg text-[var(--text-primary)] text-sm placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] focus:border-transparent transition-all ${
      errors[field] ? "border-red-500" : "border-[var(--border-color)]"
    }`;

  const labelCls = "text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wide";

  return (
    <>
    <Modal open={open} onClose={handleClose} title="Add New User" size="sm">
      <form onSubmit={handleSubmit} className="flex flex-col gap-5">

        {/* Live avatar preview */}
        <div className="flex justify-center">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center text-xl font-bold transition-colors duration-300 ${getAvatarCls(form.role)}`}>
            {getInitials(form.name)}
          </div>
        </div>

        {/* Full name */}
        <div className="flex flex-col gap-1.5">
          <label className={labelCls}>Full Name</label>
          <input
            type="text"
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
            placeholder="e.g. Jane Doe"
            className={inputCls("name")}
            autoFocus
          />
          {errors.name && <p className="text-xs text-red-500">{errors.name}</p>}
        </div>

        {/* Role selector cards */}
        <div className="flex flex-col gap-2">
          <label className={labelCls}>Role</label>
          <div className="grid grid-cols-3 gap-2">
            {ROLES.map((role) => {
              const isActive = form.role === role.key;
              return (
                <button
                  key={role.key}
                  type="button"
                  onClick={() => set("role", role.key)}
                  className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all ${
                    isActive
                      ? role.active
                      : "border-[var(--border-color)] hover:border-[var(--border-hover)] bg-transparent"
                  }`}
                >
                  <role.Icon size={18} className={isActive ? role.icon : "text-[var(--text-tertiary)]"} />
                  <span className={`text-xs font-semibold ${isActive ? role.icon : "text-[var(--text-secondary)]"}`}>
                    {role.label}
                  </span>
                  <span className="text-[10px] text-[var(--text-tertiary)] text-center leading-tight">
                    {role.desc}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-[var(--border-color)]">
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-2.5 text-sm font-semibold text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-5 py-2.5 bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm"
          >
            Add User
          </button>
        </div>
      </form>
    </Modal>

    <ConfirmDialog
      open={confirmOpen}
      variant="info"
      title="Add New User"
      message={`Add "${form.name.trim()}" as ${form.role}?`}
      confirmLabel="Add User"
      cancelLabel="Go Back"
      onConfirm={handleConfirmAdd}
      onCancel={() => setConfirmOpen(false)}
    />
    </>
  );
}
