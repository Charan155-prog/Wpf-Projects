"use client";

import { motion } from "framer-motion";
import { Pencil, Trash2 } from "lucide-react";

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.04 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 8 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
};

const roleBadgeCls = {
  Admin:      "bg-indigo-500/10 text-indigo-500 border-indigo-500/20",
  Operator:   "bg-blue-500/10 text-blue-500 border-blue-500/20",
  Technician: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
};

const statusBadgeCls = {
  Active:    "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  Inactive:  "bg-zinc-500/10 text-zinc-400 border-zinc-500/20",
  Suspended: "bg-red-500/10 text-red-500 border-red-500/20",
};

const avatarCls = {
  Admin:      "bg-indigo-500/10 text-indigo-500",
  Operator:   "bg-blue-500/10 text-blue-500",
  Technician: "bg-emerald-500/10 text-emerald-500",
};

function getInitials(name) {
  return name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
}

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });
}

export default function UserTable({ users, onEdit, onDelete }) {
  return (
    <table className="w-full text-left min-w-[720px]">

      <thead className="sticky top-0 z-10 bg-[var(--bg-sidebar)]">
        <tr className="border-b border-[var(--border-color)]">
          <th className="px-5 py-3.5 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">User</th>
          <th className="px-5 py-3.5 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Role</th>
          <th className="px-5 py-3.5 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Status</th>
          <th className="px-5 py-3.5 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Created</th>
          <th className="px-5 py-3.5 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Last Login</th>
          <th className="px-5 py-3.5 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest text-right">Actions</th>
        </tr>
      </thead>

      <motion.tbody
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="divide-y divide-[var(--border-color)]/50"
      >
        {users.map((user) => (
          <motion.tr
            key={user.id}
            variants={itemVariants}
            className="hover:bg-[var(--bg-hover)] transition-colors duration-150"
          >
            <td className="px-5 py-3.5 whitespace-nowrap">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${avatarCls[user.role] ?? "bg-gray-500/10 text-gray-500"}`}>
                  {getInitials(user.name)}
                </div>
                <span className="text-sm font-semibold text-[var(--text-primary)]">{user.name}</span>
              </div>
            </td>

            <td className="px-5 py-3.5 whitespace-nowrap">
              <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${roleBadgeCls[user.role] ?? "bg-gray-500/10 text-gray-500 border-gray-500/20"}`}>
                {user.role}
              </span>
            </td>

            <td className="px-5 py-3.5 whitespace-nowrap">
              <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${statusBadgeCls[user.status] ?? "bg-gray-500/10 text-gray-400 border-gray-500/20"}`}>
                {user.status}
              </span>
            </td>

            <td className="px-5 py-3.5 whitespace-nowrap text-sm text-[var(--text-secondary)]">
              {formatDate(user.createdAt)}
            </td>

            <td className="px-5 py-3.5 whitespace-nowrap text-sm text-[var(--text-secondary)]">
              {formatDateTime(user.lastLogin)}
            </td>

            <td className="px-5 py-3.5 whitespace-nowrap">
              <div className="flex items-center justify-end gap-1">
                <button
                  onClick={() => onEdit(user)}
                  className="p-2 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--accent-500)] hover:bg-[var(--accent-500)]/10 transition-all"
                  title="Edit"
                >
                  <Pencil size={14} />
                </button>
                <button
                  onClick={() => onDelete(user.id)}
                  className="p-2 rounded-lg text-[var(--text-tertiary)] hover:text-red-500 hover:bg-red-500/10 transition-all"
                  title="Delete"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </td>
          </motion.tr>
        ))}
      </motion.tbody>
    </table>
  );
}
