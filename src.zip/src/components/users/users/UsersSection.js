"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import UserListCard from "./UserListCard";
import AddUserModal from "./AddUserModal";
import EditUserModal from "./EditUserModal";
import SuccessDialog from "@/components/ui/SuccessDialog";

export default function UsersSection({
  filteredUsers,
  stats,
  searchTerm,
  setSearchTerm,
  viewMode,
  setViewMode,
  addUser,
  deleteUser,
  updateUser,
}) {
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [success, setSuccess] = useState(null);

  function showSuccess(title, message) {
    setSuccess({ title, message });
  }

  function handleAddUser(userData) {
    addUser(userData);
    showSuccess("User Added", `${userData.name} has been added successfully.`);
  }

  function handleUpdateUser(userId, updates) {
    updateUser(userId, updates);
    showSuccess("User Updated", `${updates.name} has been updated successfully.`);
  }

  function handleDeleteUser(userId) {
    const user = filteredUsers.find((u) => u.id === userId);
    deleteUser(userId);
    showSuccess("User Deleted", `${user?.name ?? "User"} has been deleted successfully.`);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col md:flex-1 md:min-h-0"
    >
      <UserListCard
        users={filteredUsers}
        stats={stats}
        viewMode={viewMode}
        setViewMode={setViewMode}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        onAddUser={() => setAddModalOpen(true)}
        onEdit={setEditingUser}
        onDelete={handleDeleteUser}
      />

      <AddUserModal
        open={addModalOpen}
        onClose={() => setAddModalOpen(false)}
        onAddUser={handleAddUser}
      />

      <EditUserModal
        open={!!editingUser}
        user={editingUser}
        onClose={() => setEditingUser(null)}
        onUpdateUser={handleUpdateUser}
      />

      <SuccessDialog
        open={!!success}
        title={success?.title}
        message={success?.message}
        onClose={() => setSuccess(null)}
      />
    </motion.div>
  );
}
