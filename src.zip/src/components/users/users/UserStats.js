"use client";

function StatBox({ label, value, valueColor }) {
  return (
    <div className="flex flex-col justify-center px-5 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-sidebar)] min-w-[110px]">
      <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)] mb-1">
        {label}
      </span>
      <span className={`text-2xl font-bold leading-none ${valueColor}`}>{value}</span>
    </div>
  );
}

export default function UserStats({ stats }) {
  return (
    <div className="flex items-center gap-3 overflow-x-auto pb-1">
      <StatBox label="Total Users" value={stats.total} valueColor="text-[var(--text-primary)]" />
      <StatBox label="Active" value={stats.active} valueColor="text-emerald-500" />
      <StatBox label="Admins" value={stats.admins} valueColor="text-[var(--accent-500)]" />
      <StatBox label="Operators" value={stats.operators} valueColor="text-blue-500" />
    </div>
  );
}
