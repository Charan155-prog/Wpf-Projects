"use client";

import { useState, useEffect, useMemo } from "react";
import { Search, LayoutGrid, List, UserPlus } from "lucide-react";
import { motion } from "framer-motion";
import Pagination from "@/components/ui/Pagination";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import UserTable from "./UserTable";
import UserCard from "./UserCard";

function Stat({ label, value, color }) {
  return (
    <span className="flex items-baseline gap-1 text-xs">
      <span className={`font-bold tabular-nums ${color}`}>{value}</span>
      <span className="text-[var(--text-tertiary)]">{label}</span>
    </span>
  );
}

function Dot() {
  return <span className="text-[var(--border-hover)] select-none">·</span>;
}

const cardVariants = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
};

const gridVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.05 } },
};

export default function UserListCard({
  users,
  stats,
  viewMode,
  setViewMode,
  searchTerm,
  setSearchTerm,
  onAddUser,
  onEdit,
  onDelete,
}) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const [pendingDelete, setPendingDelete] = useState(null);

  useEffect(() => { setPage(1); }, [users]);

  function handleDeleteRequest(userId) {
    const user = users.find((u) => u.id === userId);
    if (user) setPendingDelete(user);
  }

  function handleDeleteConfirm() {
    onDelete(pendingDelete.id);
    setPendingDelete(null);
  }

  const paginatedUsers = useMemo(() => {
    const start = (page - 1) * pageSize;
    return users.slice(start, start + pageSize);
  }, [users, page, pageSize]);

  return (
    <div className="flex-1 min-h-0 flex flex-col surface rounded-xl overflow-hidden">

      {/* ── Toolbar ── */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 px-4 py-3 border-b border-[var(--border-color)] flex-shrink-0 bg-[var(--bg-sidebar)]">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)] pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by name or role…"
            className="w-full pl-9 pr-4 py-2 bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] text-sm placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] focus:border-transparent transition-all"
          />
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          {/* View toggle */}
          <div className="flex items-center bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-lg p-1">
            <button
              onClick={() => setViewMode("card")}
              title="Card view"
              className={`p-1.5 rounded-md transition-all ${
                viewMode === "card"
                  ? "bg-[var(--accent-500)] text-white shadow-sm"
                  : "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]"
              }`}
            >
              <LayoutGrid size={15} />
            </button>
            <button
              onClick={() => setViewMode("table")}
              title="Table view"
              className={`p-1.5 rounded-md transition-all ${
                viewMode === "table"
                  ? "bg-[var(--accent-500)] text-white shadow-sm"
                  : "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]"
              }`}
            >
              <List size={15} />
            </button>
          </div>

          <button
            onClick={onAddUser}
            className="flex items-center gap-2 px-4 py-2 bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm whitespace-nowrap"
          >
            <UserPlus size={15} />
            Add User
          </button>
        </div>
      </div>

      {/* ── Stats bar ── */}
      {stats && (
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 px-4 py-2.5 border-b border-[var(--border-color)] flex-shrink-0 bg-[var(--bg-sidebar)]">
          <Stat label="Total"       value={stats.total}       color="text-[var(--text-primary)]" />
          <Dot />
          <Stat label="Active"      value={stats.active}      color="text-emerald-500" />
          <Dot />
          <Stat label="Admin"       value={stats.admins}      color="text-indigo-500" />
          <Dot />
          <Stat label="Operator"    value={stats.operators}   color="text-blue-500" />
          <Dot />
          <Stat label="Technician"  value={stats.technicians} color="text-emerald-600" />
        </div>
      )}

      {/* ── Content ── */}
      <div className="flex-1 min-h-0 overflow-auto bg-[var(--bg-sidebar)]/60">
        {users.length === 0 ? (
          <div className="h-full min-h-[200px] flex flex-col items-center justify-center text-center p-8">
            <p className="text-sm font-medium text-[var(--text-secondary)]">No users found</p>
            <p className="text-xs text-[var(--text-tertiary)] mt-1">
              Try a different search term or add a new user.
            </p>
          </div>
        ) : viewMode === "table" ? (
          <UserTable users={paginatedUsers} onEdit={onEdit} onDelete={handleDeleteRequest} />
        ) : (
          <motion.div
            key={page}
            variants={gridVariants}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 p-4"
          >
            {paginatedUsers.map((user) => (
              <UserCard
                key={user.id}
                user={user}
                onEdit={onEdit}
                onDelete={handleDeleteRequest}
                variants={cardVariants}
              />
            ))}
          </motion.div>
        )}
      </div>

      <ConfirmDialog
        open={!!pendingDelete}
        variant="danger"
        title="Delete User"
        message={`Are you sure you want to delete "${pendingDelete?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
        onConfirm={handleDeleteConfirm}
        onCancel={() => setPendingDelete(null)}
      />

      {/* ── Pagination footer ── */}
      {users.length > 0 && (
        <div className="flex-shrink-0 px-4 py-3 border-t border-[var(--border-color)] bg-[var(--bg-sidebar)]">
          <Pagination
            page={page}
            pageSize={pageSize}
            totalItems={users.length}
            onPageChange={setPage}
            onPageSizeChange={(size) => { setPageSize(size); setPage(1); }}
          />
        </div>
      )}
    </div>
  );
}
