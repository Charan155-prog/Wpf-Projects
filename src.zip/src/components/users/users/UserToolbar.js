"use client";

import { Search, LayoutGrid, List, UserPlus } from "lucide-react";

export default function UserToolbar({
  searchTerm,
  setSearchTerm,
  viewMode,
  setViewMode,
  onAddUser,
}) {
  return (
    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
      <div className="relative flex-1">
        <Search
          size={15}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)] pointer-events-none"
        />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by name or role…"
          className="w-full pl-9 pr-4 py-2.5 bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] text-sm placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] focus:border-transparent transition-all"
        />
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        <div className="flex items-center bg-[var(--bg-sidebar)] border border-[var(--border-color)] rounded-lg p-1">
          <button
            onClick={() => setViewMode("card")}
            className={`p-1.5 rounded-md transition-all ${
              viewMode === "card"
                ? "bg-[var(--accent-500)] text-white shadow-sm"
                : "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]"
            }`}
            title="Card view"
          >
            <LayoutGrid size={15} />
          </button>
          <button
            onClick={() => setViewMode("table")}
            className={`p-1.5 rounded-md transition-all ${
              viewMode === "table"
                ? "bg-[var(--accent-500)] text-white shadow-sm"
                : "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]"
            }`}
            title="Table view"
          >
            <List size={15} />
          </button>
        </div>

        <button
          onClick={onAddUser}
          className="flex items-center gap-2 px-4 py-2.5 bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm whitespace-nowrap"
        >
          <UserPlus size={15} />
          Add User
        </button>
      </div>
    </div>
  );
}
