"use client";

import { motion } from "framer-motion";
import { Pencil, Trash2 } from "lucide-react";

function getInitials(name) {
  return name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
}

function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, {
    month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false,
  });
}

const avatarCls = {
  Admin:      "bg-indigo-500/10 text-indigo-500",
  Operator:   "bg-blue-500/10 text-blue-500",
  Technician: "bg-emerald-500/10 text-emerald-500",
};

const statusDot = {
  Active:    "bg-emerald-500",
  Inactive:  "bg-zinc-400",
  Suspended: "bg-red-500",
};

export default function UserCard({ user, onEdit, onDelete, variants }) {
  return (
    <motion.div
      variants={variants}
      className="bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-xl p-4 flex flex-col gap-4 hover:shadow-md hover:border-[var(--border-hover)] transition-all duration-200"
    >
      {/* Avatar + name + role */}
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${avatarCls[user.role] ?? "bg-gray-500/10 text-gray-500"}`}>
          {getInitials(user.name)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-[var(--text-primary)] truncate leading-tight">
            {user.name}
          </p>
          <p className="text-xs text-[var(--text-tertiary)] mt-0.5">{user.role}</p>
        </div>
        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${statusDot[user.status] ?? "bg-gray-400"}`} title={user.status} />
      </div>

      {/* Last seen */}
      <p className="text-xs text-[var(--text-tertiary)]">
        Last seen {formatDateTime(user.lastLogin)}
      </p>

      {/* Actions */}
      <div className="flex items-center justify-end gap-1 pt-3 border-t border-[var(--border-color)]">
        <button
          onClick={() => onEdit(user)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--accent-500)] hover:bg-[var(--accent-500)]/10 transition-all"
        >
          <Pencil size={12} />
          Edit
        </button>
        <button
          onClick={() => onDelete(user.id)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[var(--text-secondary)] hover:text-red-500 hover:bg-red-500/10 transition-all"
        >
          <Trash2 size={12} />
          Delete
        </button>
      </div>
    </motion.div>
  );
}
