"use client";

import PermissionToggle from "./PermissionToggle";

export default function PermissionGroup({ title, description, permissions, role, groupKey, onToggle }) {
  const isAdmin = role === "Admin";

  return (
    <div className="surface rounded-xl p-5 flex flex-col gap-1">
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-[var(--text-primary)]">{title}</h3>
        <p className="text-xs text-[var(--text-tertiary)] mt-0.5">{description}</p>
      </div>

      <div>
        {Object.entries(permissions).map(([key, value]) => (
          <PermissionToggle
            key={key}
            label={key}
            checked={value}
            isAdmin={isAdmin}
            onChange={(val) => onToggle(role, groupKey, key, val)}
          />
        ))}
      </div>
    </div>
  );
}
