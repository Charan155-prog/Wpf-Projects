"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Lock, Save, Info } from "lucide-react";
import ConfirmDialog from "@/components/ui/ConfirmDialog";

const GROUPS = [
  {
    key: "pages",
    title: "Page Access",
    description: "Which pages each role can navigate to.",
  },
  {
    key: "actions",
    title: "Data Actions",
    description: "What data operations each role can perform.",
  },
  {
    key: "configurations",
    title: "Configuration",
    description: "System configuration access per role.",
  },
];

// Pill style when active, per role
const ROLE_PILLS = [
  {
    role: "Technician",
    label: "Tech",
    activeCls: "bg-emerald-500/15 text-emerald-500",
    inactiveCls: "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]",
  },
  {
    role: "Operator",
    label: "Oper",
    activeCls: "bg-blue-500/15 text-blue-500",
    inactiveCls: "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]",
  },
];

const PILL_BASE = "px-2.5 py-1 rounded-md text-[10px] font-bold transition-all";

export default function PermissionsSection({
  permissions,
  togglePermission,
  savePermissions,
  hasChanges,
}) {
  const [saveConfirmOpen, setSaveConfirmOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col gap-4"
    >
      {/* Cascade info */}
      <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-[var(--accent-500)]/10 border border-[var(--accent-500)]/20">
        <Info size={14} className="text-[var(--accent-500)] flex-shrink-0 mt-0.5" />
        <p className="text-sm text-[var(--accent-500)] leading-relaxed">
          <strong>Admin</strong> always has full access.&nbsp;
          Enabling <strong>Technician</strong> automatically grants <strong>Operator</strong>.&nbsp;
          Disabling <strong>Operator</strong> also removes from <strong>Technician</strong>.
        </p>
      </div>

      {/* Three cards side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {GROUPS.map((group) => {
          const keys = Object.keys(permissions.Admin[group.key] ?? {});

          return (
            <div key={group.key} className="surface rounded-xl overflow-hidden flex flex-col">

              {/* Card header */}
              <div className="px-4 py-3.5 bg-[var(--bg-sidebar)] border-b border-[var(--border-color)] flex-shrink-0">
                <p className="text-sm font-semibold text-[var(--text-primary)]">{group.title}</p>
                <p className="text-xs text-[var(--text-tertiary)] mt-0.5">{group.description}</p>
              </div>

              {/* Permission rows */}
              <div className="flex flex-col divide-y divide-[var(--border-color)]/50">
                {keys.map((permKey) => (
                  <div
                    key={permKey}
                    className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-[var(--bg-hover)] transition-colors"
                  >
                    {/* Permission name */}
                    <span className="text-sm text-[var(--text-primary)] truncate flex-1 min-w-0">
                      {permKey}
                    </span>

                    {/* Role pill group — same container style as Audit Trail level pills */}
                    <div className="flex items-center bg-[var(--bg-sidebar)] p-0.5 rounded-lg border border-[var(--border-color)] flex-shrink-0">
                      {/* Admin first — always active, locked */}
                      <div className={`${PILL_BASE} bg-indigo-500/15 text-indigo-500 flex items-center gap-0.5 opacity-70 cursor-not-allowed`}>
                        <Lock size={8} />
                        Adm
                      </div>

                      {ROLE_PILLS.map((pill) => {
                        const checked = !!permissions[pill.role][group.key][permKey];
                        return (
                          <button
                            key={pill.role}
                            type="button"
                            onClick={() => togglePermission(pill.role, group.key, permKey)}
                            className={`${PILL_BASE} ${checked ? pill.activeCls : pill.inactiveCls}`}
                          >
                            {pill.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

            </div>
          );
        })}
      </div>

      {/* Save */}
      {hasChanges && (
        <div className="flex justify-end">
          <button
            onClick={() => setSaveConfirmOpen(true)}
            className="flex items-center gap-2 px-5 py-2.5 bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm"
          >
            <Save size={15} />
            Save Changes
          </button>
        </div>
      )}

      <ConfirmDialog
        open={saveConfirmOpen}
        variant="warning"
        title="Apply Permission Changes"
        message="These changes will affect all Operator and Technician users immediately."
        confirmLabel="Apply Changes"
        onConfirm={() => { savePermissions(); setSaveConfirmOpen(false); }}
        onCancel={() => setSaveConfirmOpen(false)}
      />
    </motion.div>
  );
}
