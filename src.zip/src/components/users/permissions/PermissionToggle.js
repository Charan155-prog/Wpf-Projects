"use client";

import { Lock } from "lucide-react";
import Toggle from "@/components/ui/Toggle";

export default function PermissionToggle({ label, checked, onChange, isAdmin }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-[var(--border-color)]/60 last:border-0">
      <span className="text-sm text-[var(--text-primary)]">{label}</span>
      {isAdmin ? (
        <div className="flex items-center gap-2 text-[var(--text-tertiary)]">
          <Lock size={13} />
          <span className="text-xs font-medium">Always on</span>
        </div>
      ) : (
        <Toggle checked={checked} onChange={onChange} size="sm" />
      )}
    </div>
  );
}
