"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Users } from "lucide-react";
import UsersSection from "./users/UsersSection";
import PermissionsSection from "./permissions/PermissionsSection";
import SecuritySection from "./security/SecuritySection";

const TABS = [
  { key: "users", label: "Users" },
  { key: "permissions", label: "Permissions" },
  { key: "security", label: "Security Settings" },
];

export default function UserManagementLayout({
  activeTab,
  setActiveTab,
  filteredUsers,
  stats,
  searchTerm,
  setSearchTerm,
  viewMode,
  setViewMode,
  addUser,
  deleteUser,
  updateUser,
  permissions,
  selectedRole,
  setSelectedRole,
  togglePermission,
  savePermissions,
  permissionsHasChanges,
  settings,
  updateSetting,
  saveSettings,
  securityHasChanges,
}) {
  return (
    <div className="flex flex-col md:h-full w-full gap-4">
      <div className="app-page-header flex-shrink-0 flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 surface rounded-xl shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)] flex items-center justify-center flex-shrink-0 border border-[var(--accent-500)]/20">
            <Users size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] mb-1 leading-tight">
              User Management
            </h1>
            <p className="text-sm text-[var(--text-secondary)]">
              Manage system users, role permissions, and security policies.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 bg-[var(--bg-sidebar)] border border-[var(--border-color)] rounded-xl p-1">
          {TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === tab.key
                  ? "bg-[var(--accent-500)] text-white shadow-sm"
                  : "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.22 }}
          className="md:flex-1 md:min-h-0 flex flex-col"
        >
          {activeTab === "users" && (
            <UsersSection
              filteredUsers={filteredUsers}
              stats={stats}
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              viewMode={viewMode}
              setViewMode={setViewMode}
              addUser={addUser}
              deleteUser={deleteUser}
              updateUser={updateUser}
            />
          )}

          {activeTab === "permissions" && (
            <PermissionsSection
              permissions={permissions}
              togglePermission={togglePermission}
              savePermissions={savePermissions}
              hasChanges={permissionsHasChanges}
            />
          )}

          {activeTab === "security" && (
            <SecuritySection
              settings={settings}
              updateSetting={updateSetting}
              saveSettings={saveSettings}
              hasChanges={securityHasChanges}
            />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
