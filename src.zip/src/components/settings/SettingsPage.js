"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Settings, HardDrive, Palette, SlidersHorizontal,
  Plug, Bell, Check, Loader2, RotateCcw, Save,
  ChevronRight, FolderOpen,
} from "lucide-react";

// ─── Left nav sections ────────────────────────────────────────────────────────

const SECTIONS = [
  { id: "storage", label: "Storage & Paths", icon: HardDrive, available: true },
  { id: "appearance",  label: "Appearance",       icon: Palette,           available: false },
  { id: "pipeline",    label: "Pipeline Defaults", icon: SlidersHorizontal, available: false },
  { id: "integrations",label: "Integrations",      icon: Plug,              available: false },
  { id: "notifications",label: "Notifications",    icon: Bell,              available: false },
];

// ─── Default paths ────────────────────────────────────────────────────────────

const DEFAULTS = {
  datasetRoot: "", validatedRoot: "", modelsDir: "", exportDir: "",
  inferenceDir: "", annotationCache: "",
  sam2Checkpoint: "", groundingDinoModel: "",
};
const API_URL = process.env.NEXT_PUBLIC_SAIL_API_URL || "http://127.0.0.1:8000";

const PATH_FIELDS = [
  { key: "sam2Checkpoint", label: "SAM2 checkpoint", description: "Full path to sam2.1_b.pt", kind: "file" },
  { key: "groundingDinoModel", label: "SAM2 text grounding", description: "Grounding DINO model ID or local model folder", kind: "folder" },
  {
    key: "validatedRoot",
    label: "Legacy Validated Datasets",
    description: "Discovery location for older outputs only. New datasets use Project Output Root.",
  },
  {
    key: "datasetRoot",
    label: "Project Output Root",
    description: "All new outputs: Project / Mode / Source / Annotation, Validated Datasets, Trained Models, Inference Outputs.",
    icon: "dataset",
  },
  {
    key: "modelsDir",
    label: "Legacy Models / Pretrained Cache",
    description: "Older models and pretrained weights. New trained models use Project Output Root.",
    icon: "model",
  },
  {
    key: "exportDir",
    label: "Export Output Directory",
    description: "Destination for exported model formats (ONNX, TensorRT, CoreML, TFLite).",
    icon: "export",
  },
  {
    key: "inferenceDir",
    label: "Legacy Inference Results",
    description: "Discovery location for older runs only. New inference outputs use Project Output Root.",
    icon: "inference",
  },
  {
    key: "annotationCache",
    label: "Annotation Cache Directory",
    description: "Temporary storage for smart annotation model outputs and predictions.",
    icon: "cache",
  },
];


// ─── Path row ─────────────────────────────────────────────────────────────────

function PathRow({ field, value, onChange, isLast, onError }) {
  const [selecting, setSelecting] = useState(false);
  async function browse() {
    setSelecting(true);
    try {
      const response = await fetch(`${API_URL}/settings/select-folder?kind=${field.kind || "folder"}`, { method: "POST" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.detail || "Unable to open the folder chooser.");
      if (payload.path) onChange(field.key, payload.path);
    } catch (error) {
      onError(error.message || "Unable to select folder");
    } finally {
      setSelecting(false);
    }
  }

  return (
    <div className={`flex flex-col sm:flex-row sm:items-center gap-4 px-4 py-3 ${!isLast ? "border-b border-[var(--border-color)]" : ""}`}>
      <span className="w-48 flex-shrink-0 text-xs font-semibold text-[var(--text-primary)]">
        {field.label}
      </span>
      <div className="flex-1 min-w-0 w-full flex items-center gap-2">
        <input
          value={value}
          aria-label={field.label}
          title={field.description}
          placeholder="Use backend default"
          onChange={(e) => onChange(field.key, e.target.value)}
          spellCheck={false}
          className="flex-1 px-3 py-1.5 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] text-xs font-mono text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all"
        />
        <button
          onClick={browse} disabled={selecting}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[var(--border-color)] text-xs font-semibold text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors flex-shrink-0"
        >
          <FolderOpen size={12} /> {selecting ? "Opening…" : "Browse"}
        </button>
      </div>
    </div>
  );
}

// ─── Storage & Paths section ──────────────────────────────────────────────────

function StoragePaths() {
  const [defaults, setDefaults] = useState(DEFAULTS);
  const [error, setError] = useState("");
  const [paths, setPaths]           = useState(DEFAULTS);
  const [saveState, setSaveState]   = useState("idle"); // idle | saving | saved
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    fetch(`${API_URL}/settings`).then((response) => response.ok ? response.json() : null).then((data) => {
      if (data) { setDefaults({ ...DEFAULTS, ...data.defaults }); setPaths({ ...DEFAULTS, ...data.defaults, ...data.settings }); }
      else setError("Cannot load storage settings. Check the backend connection.");
    }).catch(() => setError("Cannot load storage settings. Check the backend connection."));
  }, []);

  function handleChange(key, value) {
    setPaths((p) => ({ ...p, [key]: value }));
    setHasChanges(true);
    setSaveState("idle");
  }

  async function handleSave() {
    setError("");
    setSaveState("saving");
    try {
      const response = await fetch(`${API_URL}/settings`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(paths) });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.detail || "Unable to save settings.");
      setPaths((current) => ({ ...current, ...payload.settings }));
      setSaveState("saved");
      setHasChanges(false);
      setTimeout(() => setSaveState("idle"), 2500);
    } catch (error) {
      setError(error.message);
      setSaveState("idle");
    }
  }

  function handleReset() {
    setPaths(defaults);
    setHasChanges(true);
    setSaveState("idle");
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Section header */}
      <div>
        <h2 className="text-base font-bold text-[var(--text-primary)]">Storage & Paths</h2>
        <p className="text-xs text-[var(--text-tertiary)] mt-0.5">
          Paths refer to the backend machine. Browse opens its folder picker; remote users can enter an absolute path. New storage settings apply to future runs; existing datasets stay at their recorded locations.
        </p>
      </div>

      {/* Path fields */}
      {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
      <div className="rounded-xl border border-[var(--border-color)] overflow-hidden">
        {PATH_FIELDS.map((field, i) => (
          <PathRow
            key={field.key}
            field={field}
            value={paths[field.key]}
            onChange={handleChange}
            isLast={i === PATH_FIELDS.length - 1}
            onError={setError}
          />
        ))}
      </div>

      {/* Save bar */}
      <div className="flex items-center justify-between pt-4 border-t border-[var(--border-color)]">
        <button onClick={handleReset}
          className="flex items-center gap-1.5 text-xs font-semibold text-[var(--text-tertiary)] hover:text-[var(--text-secondary)] transition-colors">
          <RotateCcw size={12} /> Reset to defaults
        </button>

        <div className="flex items-center gap-3">
          <AnimatePresence>
            {saveState === "saved" && (
              <motion.span
                initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
                className="flex items-center gap-1 text-xs font-semibold text-emerald-400">
                <Check size={12} /> Saved
              </motion.span>
            )}
          </AnimatePresence>

          <button
            onClick={handleSave}
            disabled={!hasChanges || saveState === "saving"}
            className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-bold transition-all ${
              hasChanges && saveState !== "saving"
                ? "bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white shadow-sm"
                : "bg-[var(--bg-hover)] text-[var(--text-tertiary)] border border-[var(--border-color)] cursor-not-allowed"
            }`}
          >
            {saveState === "saving" ? (
              <>
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}>
                  <Loader2 size={14} />
                </motion.div>
                Saving…
              </>
            ) : (
              <><Save size={14} /> Save Changes</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function SettingsPage() {
  const [activeSection, setActiveSection] = useState("storage");

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="w-full md:h-full flex flex-col gap-4"
    >
      {/* Header */}
      <div className="app-page-header flex-shrink-0 flex items-center gap-4 p-5 surface rounded-xl shadow-sm">
        <div className="w-12 h-12 rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)] flex items-center justify-center flex-shrink-0 border border-[var(--accent-500)]/20">
          <Settings size={22} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)] leading-tight">Settings</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">Configure your workspace and system preferences</p>
        </div>
      </div>

      {/* Body */}
      <div className="md:flex-1 md:min-h-0 flex gap-4">

        {/* Left nav */}
        <div className="flex-shrink-0 w-52 flex flex-col gap-1 surface rounded-xl p-2 self-start">
          {SECTIONS.map((s) => {
            const Icon = s.icon;
            const active = activeSection === s.id;
            return (
              <button
                key={s.id}
                onClick={() => s.available && setActiveSection(s.id)}
                disabled={!s.available}
                className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-left
                  ${active
                    ? "bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
                    : s.available
                      ? "text-[var(--text-secondary)] hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)]"
                      : "text-[var(--text-tertiary)] cursor-not-allowed opacity-50"
                  }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon size={15} />
                  <span>{s.label}</span>
                </div>
                {active
                  ? <ChevronRight size={13} />
                  : !s.available && (
                    <span className="text-[8px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[var(--bg-hover)] text-[var(--text-tertiary)]">
                      Soon
                    </span>
                  )
                }
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 surface rounded-xl p-6">
          <AnimatePresence mode="wait">
            {activeSection === "storage" && (
              <motion.div key="storage"
                initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}>
                <StoragePaths />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}
