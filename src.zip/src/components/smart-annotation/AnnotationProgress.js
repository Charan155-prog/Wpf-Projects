"use client";

import { motion } from "framer-motion";
import TrainingTerminal from "@/components/training/TrainingTerminal";

function formatTime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

function StatPill({ label, value, color }) {
  return (
    <div className="flex flex-col items-center px-4 py-2 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] min-w-[100px]">
      <span className={`text-sm font-bold leading-none tabular-nums ${color}`}>{value}</span>
      <span className="text-[10px] font-semibold uppercase tracking-widest text-[var(--text-tertiary)] mt-1">{label}</span>
    </div>
  );
}

export default function AnnotationProgress({ phase, processed, total, logs, elapsed }) {
  const pct   = total > 0 ? (processed / total) * 100 : 0;
  const speed = elapsed > 0 ? ((processed / elapsed) * 1000).toFixed(1) : "0.0";

  return (
    <div className="flex flex-col h-full">
      {/* Progress strip */}
      <div className="flex-shrink-0 px-5 py-4 border-b border-[var(--border-color)] bg-[var(--bg-main)] flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-[var(--text-primary)]">
              <span className="text-[var(--accent-500)]">{processed.toLocaleString()}</span>
              {" / "}{total.toLocaleString()} images
            </span>
            {phase === "running" && (
              <span className="flex items-center gap-1.5 text-xs font-semibold text-[var(--accent-500)]">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-500)] animate-pulse" />
                Annotating
              </span>
            )}
            {phase === "stopped" && (
              <span className="text-xs font-semibold text-amber-500">Stopped</span>
            )}
          </div>
          <div className="flex items-center gap-3 text-xs text-[var(--text-tertiary)] font-mono">
            <span>{speed} img/s</span>
            <span>{formatTime(elapsed)}</span>
            <span>{pct.toFixed(1)}%</span>
          </div>
        </div>

        <div className="h-2 rounded-full bg-[var(--bg-hover)] overflow-hidden border border-[var(--border-color)]">
          <motion.div
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-[var(--accent-500)] to-[var(--accent-600)]"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <StatPill label="Processed"  value={processed.toLocaleString()} color="text-[var(--accent-500)]" />
          <StatPill label="Remaining"  value={(total - processed).toLocaleString()} color="text-[var(--text-secondary)]" />
          <StatPill label="Speed"      value={`${speed}/s`} color="text-emerald-500" />
          <StatPill label="Elapsed"    value={formatTime(elapsed)} color="text-[var(--text-primary)]" />
        </div>
      </div>

      {/* Terminal */}
      <div className="flex-1 min-h-0 p-4">
        <TrainingTerminal logs={logs} />
      </div>
    </div>
  );
}
