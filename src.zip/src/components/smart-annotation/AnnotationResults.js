"use client";

import { motion } from "framer-motion";
import { CheckCircle2, RotateCcw } from "lucide-react";

function formatTime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}h ${m % 60}m ${s % 60}s`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

function ResultCard({ label, value, color }) {
  return (
    <div className="flex flex-col gap-1.5 p-4 rounded-xl bg-[var(--bg-hover)] border border-[var(--border-color)] flex-1 min-w-[120px]">
      <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">{label}</span>
      <span className={`text-2xl font-bold leading-none ${color ?? "text-[var(--text-primary)]"}`}>{value}</span>
    </div>
  );
}

export default function AnnotationResults({ results, onReset }) {
  if (!results) return null;

  const { imagesProcessed, totalAnnotations, avgConfidence, classDist, duration } = results;
  const maxCount = Math.max(...classDist.map((c) => c.count), 1);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col h-full"
    >
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-4 bg-[var(--bg-main)] border-b border-[var(--border-color)]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
            <CheckCircle2 size={18} className="text-emerald-500" />
          </div>
          <div>
            <p className="text-sm font-bold text-[var(--text-primary)]">Annotation Complete</p>
            <p className="text-xs text-[var(--text-tertiary)]">Finished in {formatTime(duration)}</p>
          </div>
        </div>
        <button
          onClick={onReset}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[var(--border-color)] text-sm font-semibold text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
        >
          <RotateCcw size={14} />
          Run Again
        </button>
      </div>

      {/* Scrollable body */}
      <div className="flex-1 min-h-0 overflow-auto p-5 flex flex-col gap-6">

        {/* Summary cards */}
        <section className="flex flex-col gap-3">
          <h2 className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Summary</h2>
          <div className="flex flex-wrap gap-3">
            <ResultCard label="Images Processed"    value={imagesProcessed.toLocaleString()} color="text-[var(--accent-500)]" />
            <ResultCard label="Annotations Created" value={totalAnnotations.toLocaleString()} color="text-emerald-500" />
            <ResultCard label="Avg Confidence"      value={avgConfidence.toFixed(3)}          color="text-amber-500" />
            <ResultCard label="Duration"            value={formatTime(duration)} />
          </div>
        </section>

        {/* Class distribution */}
        <section className="flex flex-col gap-3">
          <h2 className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Annotations by Class</h2>
          <div className="flex flex-col gap-2.5">
            {classDist.map((cls) => {
              const pct = (cls.count / maxCount) * 100;
              return (
                <div key={cls.name} className="flex items-center gap-3">
                  <div className="flex items-center gap-2 w-28 flex-shrink-0">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: cls.color }} />
                    <span className="text-xs font-semibold text-[var(--text-primary)] truncate">{cls.alias}</span>
                  </div>
                  <div className="flex-1 h-2 rounded-full bg-[var(--bg-hover)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: cls.color }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-[var(--text-secondary)] w-12 text-right flex-shrink-0 tabular-nums">
                    {cls.count.toLocaleString()}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

      </div>
    </motion.div>
  );
}
