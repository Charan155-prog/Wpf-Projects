"use client";
import { useCallback, useEffect, useState } from "react";
import { X, Pencil, RefreshCw } from "lucide-react";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";
import ValidationEditor from "@/components/datasets/ValidationEditor";

export default function ReprocessingQueue({ project, model, onClose }) {
  const [datasets, setDatasets] = useState([]), [datasetId, setDatasetId] = useState("");
  const [data, setData] = useState(null), [page, setPage] = useState(1), [filter, setFilter] = useState("Fail");
  const [error, setError] = useState(""), [editing, setEditing] = useState(null);
  const [sam, setSam] = useState(model);
  useEffect(() => {
    const controller = new AbortController();
    datasetRequest("/datasets", { signal: controller.signal }).then((r) => setDatasets(r.datasets.filter((d) => [project.name, project.name.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._]+|[._]+$/g, "")].includes(d.projectName)))).catch((e) => { if (!controller.signal.aborted) setError(e.message); });
    return () => controller.abort();
  }, [project.name]);
  const id = datasetId || datasets[0]?.id;
  const refresh = useCallback(async () => {
    if (!id) return;
    try { const r = await datasetRequest(`/datasets/${id}?status=${filter}&page=${page}&page_size=48`); setData(r); setError(""); }
    catch (e) { setError(e.message); }
  }, [id, filter, page]);
  useEffect(() => { const timer = setTimeout(refresh, 0); return () => clearTimeout(timer); }, [refresh]);
  // SAM3 Smart Annotation intentionally allows Semi-Annotation to choose SAM2
  // or SAM3. Only a SAM2 Smart Annotation selection locks the sub-flow to SAM2.
  const forced = model === "sam2";
  return <div role="dialog" aria-modal="true" aria-label="Semi-annotation reprocessing" className="fixed inset-0 z-[90] bg-black/70 p-3 sm:p-6 flex items-center justify-center"><section className="surface w-full max-w-7xl h-[94vh] flex flex-col rounded-2xl overflow-hidden shadow-2xl">
    <header className="p-4 flex gap-3 items-center border-b border-[var(--border-color)]"><div className="flex-1"><h2 className="font-bold">Semi-Annotation · Reprocess</h2><p className="text-xs text-[var(--accent-500)]">{project.name}</p></div><label className="text-xs">Model <select aria-label="Reprocessing model" disabled={forced} value={forced ? "sam2" : sam} onChange={(e) => setSam(e.target.value)} className="p-2 bg-[var(--bg-hover)] rounded-lg"><option value="sam2">SAM2</option><option value="sam3">SAM3</option></select></label><button onClick={onClose} aria-label="Close reprocessing"><X size={20} /></button></header>
    <div className="flex flex-wrap p-4 gap-3 border-b border-[var(--border-color)]"><select aria-label="Source output folder" value={id || ""} onChange={(e) => { setDatasetId(e.target.value); setPage(1); setData(null); }} className="flex-1 p-2 rounded-lg bg-[var(--bg-hover)]"><option value="" disabled>Select output folder</option>{datasets.map((d) => <option key={d.id} value={d.id}>{d.name} · {d.mode} · Run {d.runNumber}</option>)}</select>{["Fail", "Pass", "all"].map((f) => <button key={f} onClick={() => { setFilter(f); setPage(1); }} className={`px-3 py-2 rounded-lg text-sm ${filter === f ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)]"}`}>{f === "Fail" ? "Needs attention" : f === "Pass" ? "Annotated" : "All images"}</button>)}<button onClick={refresh} aria-label="Refresh reprocessing"><RefreshCw size={18} /></button></div>
    {data && <div className="flex flex-wrap gap-5 px-4 py-3 text-sm"><span>Total <strong>{data.dataset.totalImages}</strong></span><span>Annotated <strong className="text-emerald-400">{data.dataset.passCount}</strong></span><span>Needs attention <strong className="text-amber-400">{data.dataset.failCount}</strong></span><span className="capitalize">{data.dataset.state}</span></div>}
    <div className="flex-1 overflow-auto p-4">{error && <p role="alert" className="text-red-400">{error}</p>}{!datasets.length && <p>No output folders yet. Run annotation first.</p>}{data && !data.items.length && <p>No images in this filter.</p>}<div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3">{data?.items.map((item) => <button key={item.id} disabled={data.dataset.state === "running"} onClick={() => setEditing(item)} className="text-left rounded-xl border border-[var(--border-color)] overflow-hidden bg-[var(--bg-hover)] hover:border-[var(--accent-500)]"><div className="relative"><img loading="lazy" src={assetUrl(item.annotatedUrl)} alt={item.filename} className="aspect-[4/3] w-full object-contain bg-black/30" /><Pencil size={18} className="absolute top-2 right-2 bg-black/60 rounded p-0.5 text-white" /></div><p className="text-xs truncate p-2">{item.filename}</p>{item.error && <p className="px-2 pb-2 text-[10px] text-red-400 line-clamp-2" title={item.error}>{item.error}</p>}</button>)}</div></div>
    <footer className="p-3 border-t border-[var(--border-color)] flex justify-center items-center gap-5 text-sm"><button disabled={page === 1} onClick={() => setPage(page-1)}>Previous</button><span>{page} / {Math.max(1, Math.ceil((data?.total || 0)/48))} · {data?.total || 0} images</span><button disabled={page*48 >= (data?.total || 0)} onClick={() => setPage(page+1)}>Next</button></footer>
    {editing && data && <ValidationEditor key={editing.id} dataset={{...data.dataset, annotationModel: forced ? "sam2" : data.dataset.annotationModel}} item={editing} initialModel={forced ? "sam2" : sam} onClose={() => setEditing(null)} onSaved={async () => { setEditing(null); await refresh(); }} />}
  </section></div>;
}
