"use client";

import { motion } from "framer-motion";
import { Wand2 } from "lucide-react";
import { useActiveProject } from "@/context/ProjectContext";
import SailAnnotationWorkspace from "./SailAnnotationWorkspace";

function NoProjectState() {
  return <div className="flex-1 flex flex-col items-center justify-center gap-4 surface rounded-xl p-12 text-center"><div className="w-14 h-14 rounded-2xl bg-[var(--bg-hover)] border border-dashed border-[var(--border-color)] flex items-center justify-center"><Wand2 size={26} className="text-[var(--text-tertiary)]" /></div><div><p className="text-sm font-semibold text-[var(--text-secondary)]">No project selected</p><p className="text-xs text-[var(--text-tertiary)] mt-1">Select a project from the sidebar to use Smart Annotation.</p></div></div>;
}

export default function SmartAnnotationPage() {
  const { activeProject } = useActiveProject();
  return <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }} className="h-full w-full">{activeProject ? <div className="flex h-full min-h-0 flex-col overflow-hidden rounded-2xl border border-[var(--border-color)] bg-[var(--bg-surface)] shadow-sm"><SailAnnotationWorkspace key={activeProject.id} project={activeProject} /></div> : <NoProjectState />}</motion.div>;
}
