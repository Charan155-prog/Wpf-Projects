"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check, CheckCheck, ChevronLeft, ChevronRight,
  Eraser, MousePointer2, Spline, Square, Trash2,
} from "lucide-react";

// ─── Mock data ────────────────────────────────────────────────────────────────

const SEEDS = ["ax1","bx2","cx3","dx4","ex5","fx6","gx7","hx8","ix9","jx10","kx11","lx12"];
const rnd = (a, b) => +(a + Math.random() * (b - a)).toFixed(3);

function genPredictions(classes) {
  return Array.from({ length: Math.floor(Math.random() * 3) + 1 }, (_, i) => {
    const cls = classes[i % classes.length];
    return {
      id: `p${i}_${Math.random().toString(36).slice(2, 6)}`,
      type: "rect",
      alias: cls.alias, color: cls.color, classIdx: i % classes.length,
      confidence: +(0.62 + Math.random() * 0.34).toFixed(2),
      x: rnd(0.05, 0.5), y: rnd(0.05, 0.4),
      w: rnd(0.18, 0.38), h: rnd(0.18, 0.38),
    };
  });
}

export function initWorkspaceImages(dataset) {
  return SEEDS.map((seed, i) => ({
    id: `img_${i}`,
    filename: `img_${String(i + 1).padStart(4, "0")}.jpg`,
    url: `https://picsum.photos/seed/${dataset.id}_${seed}/800/600`,
    predictions: genPredictions(dataset.classes),
    annotations: [],
  }));
}

// ─── Geometry helpers ─────────────────────────────────────────────────────────

function isInsideRect(b, p) {
  return p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h;
}

function isInsidePoly(pts, p) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i].x, yi = pts[i].y, xj = pts[j].x, yj = pts[j].y;
    if ((yi > p.y) !== (yj > p.y) && p.x < ((xj - xi) * (p.y - yi)) / (yj - yi) + xi)
      inside = !inside;
  }
  return inside;
}

function hitTest(box, pos) {
  if (box.type === "polygon") return isInsidePoly(box.points, pos);
  return isInsideRect(box, pos);
}

// Normalized → pixel
const nx = (v, w) => v * w;
const ny = (v, h) => v * h;

// ─── Annotation SVG Layer ─────────────────────────────────────────────────────

function AnnotationLayer({ boxes, dashed, selectedId, onSelect, onDelete, tool, size }) {
  const { w, h } = size;

  return (
    <>
      {/* Single SVG for all shapes — viewBox in pixels */}
      <svg
        viewBox={`0 0 ${w} ${h}`}
        className="absolute inset-0 w-full h-full pointer-events-none"
        preserveAspectRatio="none"
      >
        {boxes.map((b) => {
          const sel = b.id === selectedId;
          const fill   = b.color + (sel ? "30" : "15");
          const stroke = b.color;
          const sw     = sel ? 2.5 : 2;
          const dash   = dashed ? "8 5" : undefined;

          if (b.type === "polygon") {
            const pts = b.points.map((p) => `${nx(p.x, w)},${ny(p.y, h)}`).join(" ");
            return (
              <g key={b.id}>
                <polygon points={pts} fill={fill} stroke={stroke} strokeWidth={sw}
                  strokeDasharray={dash} style={{ vectorEffect: "non-scaling-stroke" }} />
                {/* Vertex dots when selected */}
                {sel && b.points.map((p, i) => (
                  <circle key={i} cx={nx(p.x, w)} cy={ny(p.y, h)} r="5"
                    fill="white" stroke={stroke} strokeWidth="2"
                    style={{ vectorEffect: "non-scaling-stroke" }} />
                ))}
              </g>
            );
          }

          // Rect
          return (
            <g key={b.id}>
              <rect
                x={nx(b.x, w)} y={ny(b.y, h)}
                width={nx(b.w, w)} height={ny(b.h, h)}
                fill={fill} stroke={stroke} strokeWidth={sw}
                strokeDasharray={dash} rx="3"
                style={{ vectorEffect: "non-scaling-stroke" }}
              />
              {/* Corner handles */}
              {sel && [[b.x, b.y], [b.x + b.w, b.y], [b.x, b.y + b.h], [b.x + b.w, b.y + b.h]].map(([cx, cy], i) => (
                <rect key={i}
                  x={nx(cx, w) - 4} y={ny(cy, h) - 4}
                  width="8" height="8" rx="2"
                  fill="white" stroke={stroke} strokeWidth="2"
                  style={{ vectorEffect: "non-scaling-stroke" }}
                />
              ))}
            </g>
          );
        })}
      </svg>

      {/* HTML labels */}
      {boxes.map((b) => {
        const sel = b.id === selectedId;
        const labelPos = b.type === "polygon"
          ? { left: `${b.points[0]?.x * 100 ?? 0}%`, top: `${b.points[0]?.y * 100 ?? 0}%` }
          : { left: `${b.x * 100}%`, top: `${b.y * 100}%` };

        return (
          <div key={`lbl_${b.id}`}
            className="absolute flex items-center gap-1 -translate-y-full pointer-events-auto z-10"
            style={labelPos}
          >
            <button
              onClick={(e) => { e.stopPropagation(); onSelect?.(b.id); }}
              className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold text-white leading-none shadow-md"
              style={{ backgroundColor: b.color }}
            >
              {b.alias}
              {b.confidence && <span className="opacity-70 font-normal">{b.confidence}</span>}
            </button>
            {(sel || tool === "erase") && onDelete && (
              <button
                onClick={(e) => { e.stopPropagation(); onDelete(b.id); }}
                className="w-5 h-5 rounded bg-red-500 hover:bg-red-600 flex items-center justify-center text-white shadow-md transition-colors"
                title="Delete"
              >
                <Trash2 size={10} />
              </button>
            )}
          </div>
        );
      })}
    </>
  );
}

// ─── In-progress polygon preview ──────────────────────────────────────────────

function PolyPreview({ points, mousePos, color, size }) {
  if (points.length === 0) return null;
  const { w, h } = size;
  const preview  = mousePos ? [...points, mousePos] : points;
  const pts      = preview.map((p) => `${nx(p.x, w)},${ny(p.y, h)}`).join(" ");
  const first    = points[0];

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
      {/* Preview path */}
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2"
        strokeDasharray="6 4" style={{ vectorEffect: "non-scaling-stroke" }} />

      {/* Placed point dots */}
      {points.map((p, i) => (
        <circle key={i} cx={nx(p.x, w)} cy={ny(p.y, h)} r={i === 0 ? 6 : 4}
          fill={i === 0 ? color : "white"} stroke={color} strokeWidth="2"
          style={{ vectorEffect: "non-scaling-stroke" }} />
      ))}

      {/* Close-hint ring on first point */}
      {points.length >= 3 && (
        <circle cx={nx(first.x, w)} cy={ny(first.y, h)} r="12"
          fill="none" stroke={color} strokeWidth="1.5" strokeDasharray="4 3" strokeOpacity="0.5"
          style={{ vectorEffect: "non-scaling-stroke" }} />
      )}
    </svg>
  );
}

// ─── In-progress rect preview ─────────────────────────────────────────────────

function RectPreview({ start, current, color, size }) {
  if (!start || !current) return null;
  const { w, h } = size;
  const x = Math.min(start.x, current.x);
  const y = Math.min(start.y, current.y);
  const rw = Math.abs(current.x - start.x);
  const rh = Math.abs(current.y - start.y);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
      <rect x={nx(x, w)} y={ny(y, h)} width={nx(rw, w)} height={ny(rh, h)}
        fill={color + "28"} stroke={color} strokeWidth="2" strokeDasharray="6 3" rx="3"
        style={{ vectorEffect: "non-scaling-stroke" }} />
    </svg>
  );
}

// ─── Manual Annotation Canvas ─────────────────────────────────────────────────

function ManualCanvas({ image, classes, selectedClassIdx, tool, onUpdateAnnotations }) {
  const containerRef = useRef(null);
  const [size, setSize]           = useState({ w: 1, h: 1 });
  const [drawStart, setDrawStart] = useState(null);
  const [drawCurrent, setDrawCurrent] = useState(null);
  const [polyPoints, setPolyPoints]   = useState([]);
  const [mousePos, setMousePos]       = useState(null);
  const [selectedId, setSelectedId]   = useState(null);
  const dblClickRef = useRef(false);

  const selectedClass = classes[selectedClassIdx] ?? classes[0];

  // Track container size for pixel-accurate SVG
  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(([e]) => {
      setSize({ w: e.contentRect.width || 1, h: e.contentRect.height || 1 });
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  // Reset poly when switching away from polygon tool
  useEffect(() => {
    if (tool !== "polygon") {
      setPolyPoints([]);
      setMousePos(null);
    }
  }, [tool]);

  function getPos(e) {
    const rect = containerRef.current.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)),
      y: Math.max(0, Math.min(1, (e.clientY - rect.top)  / rect.height)),
    };
  }

  // ── Mouse handlers ──
  function onMouseDown(e) {
    if (tool === "rect") {
      e.preventDefault();
      setSelectedId(null);
      const p = getPos(e);
      setDrawStart(p);
      setDrawCurrent(p);
    }
  }

  function onMouseMove(e) {
    const pos = getPos(e);
    if (tool === "rect" && drawStart) setDrawCurrent(pos);
    if (tool === "polygon")           setMousePos(pos);
  }

  function onMouseUp() {
    if (tool !== "rect" || !drawStart || !drawCurrent) return;
    const x = Math.min(drawStart.x, drawCurrent.x);
    const y = Math.min(drawStart.y, drawCurrent.y);
    const w = Math.abs(drawCurrent.x - drawStart.x);
    const h = Math.abs(drawCurrent.y - drawStart.y);
    if (w > 0.02 && h > 0.02) {
      const box = { id: `a_${Date.now()}`, type: "rect", classIdx: selectedClassIdx, alias: selectedClass.alias, color: selectedClass.color, x: +x.toFixed(4), y: +y.toFixed(4), w: +w.toFixed(4), h: +h.toFixed(4) };
      onUpdateAnnotations([...image.annotations, box]);
    }
    setDrawStart(null); setDrawCurrent(null);
  }

  function onClick(e) {
    const pos = getPos(e);

    if (tool === "select") {
      const hit = [...image.annotations].reverse().find((b) => hitTest(b, pos));
      setSelectedId(hit?.id ?? null);
      return;
    }

    if (tool === "erase") {
      const hit = [...image.annotations].reverse().find((b) => hitTest(b, pos));
      if (hit) { onUpdateAnnotations(image.annotations.filter((a) => a.id !== hit.id)); }
      return;
    }

    if (tool === "polygon") {
      if (dblClickRef.current) { dblClickRef.current = false; return; } // ignore 2nd click of dblclick

      // Close if clicking near the first point (≥ 3 points)
      if (polyPoints.length >= 3) {
        const first = polyPoints[0];
        const dist  = Math.hypot(pos.x - first.x, pos.y - first.y);
        if (dist < 0.03) { finishPolygon(); return; }
      }
      setPolyPoints((prev) => [...prev, pos]);
    }
  }

  function onDoubleClick() {
    if (tool !== "polygon" || polyPoints.length < 3) return;
    dblClickRef.current = true;
    finishPolygon();
  }

  function finishPolygon() {
    if (polyPoints.length < 3) return;
    const poly = { id: `a_${Date.now()}`, type: "polygon", classIdx: selectedClassIdx, alias: selectedClass.alias, color: selectedClass.color, points: [...polyPoints] };
    onUpdateAnnotations([...image.annotations, poly]);
    setPolyPoints([]);
    setMousePos(null);
  }

  function deleteAnnotation(id) {
    onUpdateAnnotations(image.annotations.filter((a) => a.id !== id));
    if (selectedId === id) setSelectedId(null);
  }

  const cursors = { select: "default", rect: "crosshair", erase: "cell", polygon: "crosshair" };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden select-none"
      style={{ cursor: cursors[tool] ?? "default" }}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onClick={onClick}
      onDoubleClick={onDoubleClick}
      onMouseLeave={() => { setDrawStart(null); setDrawCurrent(null); setMousePos(null); }}
    >
      <img src={image.url} alt={image.filename} className="w-full h-full object-cover" draggable={false} />

      <AnnotationLayer
        boxes={image.annotations}
        selectedId={selectedId}
        onSelect={setSelectedId}
        onDelete={deleteAnnotation}
        tool={tool}
        size={size}
      />

      {/* Rect preview while drawing */}
      <RectPreview start={drawStart} current={drawCurrent} color={selectedClass.color} size={size} />

      {/* Polygon in-progress preview */}
      <PolyPreview points={polyPoints} mousePos={mousePos} color={selectedClass.color} size={size} />

      {/* Polygon hint */}
      {tool === "polygon" && polyPoints.length > 0 && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-lg bg-black/60 text-white text-[10px] font-semibold backdrop-blur-sm pointer-events-none">
          {polyPoints.length < 3
            ? `${polyPoints.length} point${polyPoints.length > 1 ? "s" : ""} — add at least ${3 - polyPoints.length} more`
            : "Double-click or click first point to close polygon"}
        </div>
      )}
    </div>
  );
}

// ─── Prediction Panel ─────────────────────────────────────────────────────────

function PredictionPanel({ image, onAcceptOne }) {
  const containerRef = useRef(null);
  const [size, setSize] = useState({ w: 1, h: 1 });

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(([e]) => setSize({ w: e.contentRect.width || 1, h: e.contentRect.height || 1 }));
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden select-none">
      <img src={image.url} alt={image.filename} className="w-full h-full object-cover" draggable={false} />
      <AnnotationLayer boxes={image.predictions} dashed tool="select" size={size} />
      {image.predictions.map((p) => (
        <button
          key={`acc_${p.id}`}
          onClick={() => onAcceptOne(p)}
          className="absolute flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold text-white shadow-md hover:brightness-110 transition-all pointer-events-auto"
          style={{ left: `${(p.x + p.w) * 100}%`, top: `${p.y * 100}%`, backgroundColor: p.color, transform: "translateX(-100%)" }}
        >
          <Check size={9} /> Accept
        </button>
      ))}
    </div>
  );
}

// ─── Filmstrip ────────────────────────────────────────────────────────────────

function Filmstrip({ images, currentIdx, onSelect }) {
  return (
    <div className="flex-shrink-0 flex items-center gap-2 px-4 py-2.5 bg-[var(--bg-main)] border-t border-[var(--border-color)] overflow-x-auto">
      {images.map((img, i) => (
        <button key={img.id} onClick={() => onSelect(i)}
          className={`relative flex-shrink-0 w-16 h-11 rounded-lg overflow-hidden border-2 transition-all ${
            i === currentIdx
              ? "border-[var(--accent-500)] shadow-md scale-105"
              : "border-[var(--border-color)] opacity-60 hover:opacity-90 hover:border-[var(--border-hover)]"
          }`}
        >
          <img src={img.url} alt={img.filename} className="w-full h-full object-cover" />
          {img.annotations.length > 0 && (
            <span className="absolute bottom-0.5 right-0.5 bg-[var(--accent-500)] text-white text-[8px] font-bold rounded px-0.5 leading-tight">
              {img.annotations.length}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

// ─── Workspace ────────────────────────────────────────────────────────────────

export default function AnnotationWorkspace({ dataset }) {
  const [images, setImages]           = useState(() => initWorkspaceImages(dataset));
  const [currentIdx, setCurrentIdx]   = useState(0);
  const [selectedTool, setSelectedTool]       = useState("rect");
  const [selectedClassIdx, setSelectedClassIdx] = useState(0);

  const image   = images[currentIdx];
  const classes = dataset.classes;

  function updateAnnotations(idx, annotations) {
    setImages((prev) => prev.map((img, i) => i === idx ? { ...img, annotations } : img));
  }

  function acceptOne(prediction) {
    const box = { ...prediction, id: `a_${Date.now()}` };
    delete box.confidence;
    updateAnnotations(currentIdx, [...image.annotations, box]);
  }

  function acceptAll() {
    const boxes = image.predictions.map((p, i) => ({ ...p, id: `a_${Date.now()}_${i}`, confidence: undefined }));
    updateAnnotations(currentIdx, [...image.annotations, ...boxes]);
  }

  function goTo(idx) { if (idx >= 0 && idx < images.length) setCurrentIdx(idx); }

  const tools = [
    { id: "select",  Icon: MousePointer2, title: "Select & delete" },
    { id: "rect",    Icon: Square,        title: "Draw bounding box" },
    { id: "polygon", Icon: Spline,        title: "Draw polygon" },
    { id: "erase",   Icon: Eraser,        title: "Erase on click" },
  ];

  return (
    <div className="flex flex-col h-full">

      {/* Toolbar */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-2.5 bg-[var(--bg-main)] border-b border-[var(--border-color)] flex-wrap">
        {/* Navigation */}
        <div className="flex items-center gap-1.5">
          <button onClick={() => goTo(currentIdx - 1)} disabled={currentIdx === 0}
            className="p-1.5 rounded-lg hover:bg-[var(--bg-hover)] text-[var(--text-tertiary)] hover:text-[var(--text-primary)] disabled:opacity-30 transition-all">
            <ChevronLeft size={16} />
          </button>
          <span className="text-xs font-semibold text-[var(--text-secondary)] tabular-nums px-1">
            {currentIdx + 1} / {images.length}
          </span>
          <button onClick={() => goTo(currentIdx + 1)} disabled={currentIdx === images.length - 1}
            className="p-1.5 rounded-lg hover:bg-[var(--bg-hover)] text-[var(--text-tertiary)] hover:text-[var(--text-primary)] disabled:opacity-30 transition-all">
            <ChevronRight size={16} />
          </button>
        </div>

        <div className="w-px h-5 bg-[var(--border-color)]" />

        {/* Tools */}
        <div className="flex items-center bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-lg p-0.5 gap-0.5">
          {tools.map(({ id, Icon, title }) => (
            <button key={id} onClick={() => setSelectedTool(id)} title={title}
              className={`p-2 rounded-md transition-all ${selectedTool === id ? "bg-[var(--accent-500)] text-white shadow-sm" : "text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"}`}>
              <Icon size={14} />
            </button>
          ))}
        </div>

        {/* Tool hint */}
        <span className="text-[10px] text-[var(--text-tertiary)]">
          {selectedTool === "select"  && "Click a shape to select — delete button appears"}
          {selectedTool === "rect"    && "Click and drag to draw a bounding box"}
          {selectedTool === "polygon" && "Click to add points — double-click or click first point to close"}
          {selectedTool === "erase"   && "Click any shape to delete it instantly"}
        </span>

        <div className="w-px h-5 bg-[var(--border-color)]" />

        {/* Class selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-[var(--text-tertiary)] font-medium">Class:</span>
          <div className="flex items-center gap-1">
            {classes.map((cls, i) => (
              <button key={cls.name} onClick={() => setSelectedClassIdx(i)} title={cls.alias}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                  selectedClassIdx === i ? "text-white shadow-sm border-transparent" : "border-[var(--border-color)] text-[var(--text-tertiary)] hover:border-[var(--border-hover)]"
                }`}
                style={selectedClassIdx === i ? { backgroundColor: cls.color, borderColor: cls.color } : {}}>
                <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: cls.color }} />
                {cls.alias}
              </button>
            ))}
          </div>
        </div>

        {/* Accept all */}
        <button onClick={acceptAll}
          className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold transition-colors shadow-sm">
          <CheckCheck size={13} />
          Accept All
        </button>

        <span className="text-xs text-[var(--text-tertiary)]">
          {image.annotations.length} annotation{image.annotations.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Two panels */}
      <div className="flex-1 min-h-0 grid grid-cols-2 divide-x divide-[var(--border-color)]">

        {/* Left — Manual */}
        <div className="flex flex-col [overflow:clip]">
          <div className="flex-shrink-0 flex items-center gap-2 px-4 py-2 bg-[var(--bg-main)] border-b border-[var(--border-color)]">
            <span className="w-2 h-2 rounded-full bg-[var(--accent-500)]" />
            <span className="text-xs font-bold text-[var(--text-secondary)]">Manual Annotation</span>
            <span className="ml-auto text-[10px] text-[var(--text-tertiary)]">Draw boxes or polygons on the image</span>
          </div>
          <div className="flex-1 min-h-0 bg-[#0f0f0f]">
            <ManualCanvas
              image={image}
              classes={classes}
              selectedClassIdx={selectedClassIdx}
              tool={selectedTool}
              onUpdateAnnotations={(a) => updateAnnotations(currentIdx, a)}
            />
          </div>
        </div>

        {/* Right — Predictions */}
        <div className="flex flex-col [overflow:clip]">
          <div className="flex-shrink-0 flex items-center gap-2 px-4 py-2 bg-[var(--bg-main)] border-b border-[var(--border-color)]">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="text-xs font-bold text-[var(--text-secondary)]">Model Predictions</span>
            <span className="ml-auto text-[10px] text-[var(--text-tertiary)]">
              {image.predictions.length} prediction{image.predictions.length !== 1 ? "s" : ""}
            </span>
          </div>
          <div className="flex-1 min-h-0 bg-[#0f0f0f]">
            <PredictionPanel image={image} onAcceptOne={acceptOne} />
          </div>
        </div>
      </div>

      {/* Filmstrip */}
      <Filmstrip images={images} currentIdx={currentIdx} onSelect={setCurrentIdx} />
    </div>
  );
}
