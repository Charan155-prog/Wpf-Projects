"use client";

import { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  Camera,
  Check,
  ChevronLeft,
  ChevronRight,
  FolderOpen,
  Maximize2,
  Minimize2,
  Play,
  RefreshCw,
  Settings2,
  Sparkles,
  Trash2,
  Video,
  X,
} from "lucide-react";
import { useAnnotationWorkspace } from "@/context/AnnotationWorkspaceContext";
import ReprocessingQueue from "./ReprocessingQueue";

const API_URL = (
  process.env.NEXT_PUBLIC_SAIL_API_URL || "http://127.0.0.1:8000"
).replace(/\/+$/, "");

const blank = {
  images: [],
  index: 0,
  roi: [],
  aoi: [],
  promptMode: "manual",
  prompts: [],
  results: {},
  status: "",
  sourceKind: "",
  sourcePath: "",
  confidenceThreshold: 0.5,
};

const wsUrl = (path) => `${API_URL.replace(/^http/, "ws")}${path}`;

function Dialog({ title, children, onClose }) {
  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-xl overflow-hidden rounded-2xl border border-[var(--border-color)] bg-[var(--bg-surface)] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[var(--border-color)] px-5 py-4">
          <h3 className="font-bold">{title}</h3>

          <button
            onClick={onClose}
            className="rounded-lg p-1.5 hover:bg-[var(--bg-hover)]"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {children}
      </div>
    </div>
  );
}

/*
 * Shared image pane.
 *
 * Important:
 * - Header height is identical for both panels.
 * - Image stage is flex:1 so both panels always align.
 * - Footer height is identical.
 * - Expand button belongs to the annotated panel.
 */
function ImagePane({
  title,
  image,
  result,
  onExpand,
  expanded = false,
  mode,
  onPrevious,
  onNext,
  previousDisabled = false,
  nextDisabled = false,
  sampleSelected = false,
  onToggleSample,
  children,
}) {
  const [zoom, setZoom] = useState(1);
  const [zoomOrigin, setZoomOrigin] = useState("50% 50%");

  return (
    <section className="annotation-pane flex min-h-0 min-w-0 flex-col overflow-hidden rounded-2xl border border-[var(--border-color)] bg-[var(--bg-surface)] shadow-sm">
      {/* IDENTICAL HEADER HEIGHT */}
      <header className="annotation-pane-header flex h-[68px] shrink-0 items-center justify-between border-b border-[var(--border-color)] px-4">
        <div className="min-w-0">
          <h2 className="text-sm font-bold leading-5">{title}</h2>

          {result && (
            <p className="mt-0.5 text-[11px] font-medium text-[var(--text-secondary)]">
              {result.detections || 0} object
              {result.detections === 1 ? "" : "s"} detected
            </p>
          )}
        </div>

        {/* EXPAND / COLLAPSE BUTTON */}
        <div className="flex items-center gap-1">
          {onToggleSample && (
            <button
              onClick={onToggleSample}
              type="button"
              className={`flex h-9 w-9 items-center justify-center rounded-lg border transition ${sampleSelected ? "border-emerald-500 bg-emerald-500/10 text-emerald-500" : "border-transparent text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"}`}
              title={sampleSelected ? "Remove from pre-annotation sample" : "Select for pre-annotation sample"}
              aria-label={sampleSelected ? "Remove from pre-annotation sample" : "Select for pre-annotation sample"}
            >
              {sampleSelected ? <Check size={17} /> : <span className="text-lg leading-none">＋</span>}
            </button>
          )}
          {onPrevious && (
            <>
              <button
                onClick={onPrevious}
                disabled={previousDisabled}
                type="button"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--text-secondary)] transition hover:bg-[var(--bg-hover)] disabled:cursor-not-allowed disabled:opacity-25"
                title={`Previous ${title.toLowerCase()}`}
                aria-label={`Previous ${title.toLowerCase()}`}
              >
                <ChevronLeft size={18} />
              </button>
              <button
                onClick={onNext}
                disabled={nextDisabled}
                type="button"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--text-secondary)] transition hover:bg-[var(--bg-hover)] disabled:cursor-not-allowed disabled:opacity-25"
                title={`Next ${title.toLowerCase()}`}
                aria-label={`Next ${title.toLowerCase()}`}
              >
                <ChevronRight size={18} />
              </button>
            </>
          )}

          {onExpand && (
            <button
              onClick={onExpand}
              type="button"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-transparent text-[var(--text-secondary)] transition hover:border-[var(--border-color)] hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)]"
              title={expanded ? "Return to split view" : `Expand ${title.toLowerCase()}`}
              aria-label={expanded ? "Return to split view" : `Expand ${title.toLowerCase()}`}
            >
              {expanded ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>
          )}
        </div>
      </header>

      {/* IMAGE STAGE */}
      <div className="annotation-image-stage relative min-h-0 flex-1 overflow-hidden bg-[var(--image-stage)]">
        <div
          className="h-full w-full transition-transform duration-150"
          onWheel={(event) => {
            event.preventDefault();
            const bounds = event.currentTarget.getBoundingClientRect();
            setZoomOrigin(`${((event.clientX - bounds.left) / bounds.width) * 100}% ${((event.clientY - bounds.top) / bounds.height) * 100}%`);
            setZoom((value) => Math.min(5, Math.max(1, Number((value + (event.deltaY < 0 ? 0.2 : -0.2)).toFixed(2)))));
          }}
          onDoubleClick={() => { setZoom(1); setZoomOrigin("50% 50%"); }}
          style={{ transform: `scale(${zoom})`, transformOrigin: zoomOrigin }}
        >
          {children ||
            (image ? (
              <img
                src={image}
                alt={title}
                className="h-full w-full object-fill"
              />
            ) : (
              <div className="grid h-full place-items-center text-sm text-[var(--text-tertiary)]">
                No image selected
              </div>
            ))}
        </div>
      </div>

      {/* IDENTICAL FOOTER HEIGHT */}
      <footer className="flex h-10 shrink-0 items-center justify-between border-t border-[var(--border-color)] px-4 text-xs text-[var(--text-secondary)]">
        {result?.labelUrl ? (
          <a
            href={`${API_URL}${result.labelUrl}`}
            target="_blank"
            rel="noreferrer"
            className="font-semibold text-[var(--accent-500)] hover:underline"
          >
            Open {mode.toLowerCase()} labels
          </a>
        ) : (
          <span>Source preview</span>
        )}

        <span className="max-w-[60%] truncate text-[var(--text-tertiary)]">
          {image?.name || ""}
        </span>
      </footer>
    </section>
  );
}

export default function SailAnnotationWorkspace({ project }) {
  const imageRef = useRef(null);
  const drawingRef = useRef(false);
  const roiStartRef = useRef(null);
  const socketRef = useRef(null);
  const liveDisplayRef = useRef({ generation: 0, seen: new Set(), queue: [], pumping: false });
  const previewTimerRef = useRef(null);
  const previewAbortRef = useRef(null);
  const previewBusyRef = useRef(false);
  const runKindRef = useRef("annotation");

  const { workspaces, saveWorkspace } =
    useAnnotationWorkspace();

  const stored = workspaces[project.id] || blank;
  const activeJobRef = useRef(stored.job?.id || null);
  const cancellingRef = useRef(false);
  const pendingCompletionRef = useRef(null);
  const completionActionRef = useRef(null);
  const restoredDisplayRef = useRef(false);
  if (!restoredDisplayRef.current) {
    restoredDisplayRef.current = true;
    liveDisplayRef.current.seen = new Set(Object.keys(stored.results || {}));
    runKindRef.current = stored.runKind || "annotation";
  }

  const [images, setImages] = useState(stored.images);
  const [index, setIndex] = useState(stored.index);
  const [roi, setRoi] = useState(stored.roi);
  const [roiSourceIndex, setRoiSourceIndex] = useState(stored.roiSourceIndex ?? -1);
  const [aoi, setAoi] = useState(stored.aoi || []);

  const [drawing, setDrawing] = useState(false);
  const [drawingAoi, setDrawingAoi] = useState(false);
  const [roiShape, setRoiShape] = useState("freehand");

  const [promptMode, setPromptMode] = useState(
    stored.promptMode
  );

  const [promptText, setPromptText] = useState("");
  const [editingPromptIndex, setEditingPromptIndex] = useState(null);
  const [prompts, setPrompts] = useState(stored.prompts);
  const [savedPrompts, setSavedPrompts] = useState([]);

  const [results, setResults] = useState(stored.results);
  const [status, setStatus] = useState(stored.status);
  const [job, setJob] = useState(stored.job || null);

  const [running, setRunning] = useState(Boolean(stored.job));
  const [runKind, setRunKind] = useState(stored.runKind || "annotation");
  const [calibrationReady, setCalibrationReady] = useState(false);
  const [semiAnnotationEnabled, setSemiAnnotationEnabled] = useState(false);
  // Normal Smart Annotation always uses the established SAM3 pipeline.
  // SAM2 is reserved for explicit Semi-Annotation recovery.
  const annotationModel = "sam3";
  const [semiModel, setSemiModel] = useState(stored.semiModel || "sam3");
  const [reprocessing, setReprocessing] = useState(false);
  const [calibrationPreview, setCalibrationPreview] = useState(null);
  const [previewBusy, setPreviewBusy] = useState(false);
  const [confidenceThreshold, setConfidenceThreshold] = useState(Math.max(0.5, stored.confidenceThreshold ?? 0.5));
  const [imageThresholds, setImageThresholds] = useState({});
  const [selectedSampleIndices, setSelectedSampleIndices] = useState(stored.selectedSampleIndices || []);
  const [toast, setToast] = useState("");

  const [sourceMenu, setSourceMenu] = useState(false);
  const [dialog, setDialog] = useState(null);
  const [sourcePath, setSourcePath] = useState(stored.sourcePath || "");
  const [sourceKind, setSourceKind] = useState(stored.sourceKind || "");

  const [sourceToken, setSourceToken] = useState(
    stored.sourceToken || ""
  );

  /*
   * false = normal split view
   * true  = annotated image occupies complete workspace
   */
  const [expandedPane, setExpandedPane] = useState(null);
  const [pageInput, setPageInput] = useState(null);

  const current = images[index];
  const selectedThreshold = imageThresholds[current?.name] ?? 0.5;
  // Load low-confidence candidates once; the slider filters them locally.
  // Going below this floor requests additional candidates for this image only.
  const candidateThreshold = Math.min(0.05, selectedThreshold);
  const [previewError, setPreviewError] = useState("");
  const previewKey = JSON.stringify([sourceToken, current?.sourceIndex ?? index, prompts, semiModel, roi, roiSourceIndex, aoi]);
  const previewEligible = !running && semiAnnotationEnabled && selectedSampleIndices.includes(current?.sourceIndex ?? index) && !!prompts.length && sourceKind !== "video-direct";
  useEffect(() => {
    if (!previewEligible || running) return;
    let obsolete = false;
    const timer = setTimeout(async () => {
      while (previewBusyRef.current && !obsolete) await new Promise((resolve) => setTimeout(resolve, 100));
      if (obsolete) return;
      previewBusyRef.current = true; setPreviewBusy(true);
      setPreviewError("");
      try {
        const form = new FormData();
        Object.entries({project_name: project.name, mode: (project.mode || "Detection").toLowerCase(), source_token: sourceToken,
          source_index: current?.sourceIndex ?? index, roi_source_index: roiSourceIndex, annotation_model: semiModel,
          confidence_threshold: candidateThreshold, prompts: JSON.stringify(prompts), roi: JSON.stringify(roi), aoi: JSON.stringify(aoi)
        }).forEach(([key, value]) => form.append(key, String(value)));
        const response = await fetch(`${API_URL}/annotate/preview`, {method: "POST", body: form});
        const payload = await response.json();
        if (!response.ok || payload.error) throw new Error(payload.error || payload.detail || "Preview failed.");
        if (!obsolete) setCalibrationPreview({...payload, filename: current.name, promptKey: JSON.stringify(prompts), previewKey});
      } catch (error) { if (!obsolete) { setPreviewError(error.message); setToast(error.message); } }
      finally { previewBusyRef.current = false; setPreviewBusy(false); }
    }, 180);
    return () => { obsolete = true; clearTimeout(timer); };
  }, [previewKey, candidateThreshold, previewEligible, running]);
  const mode = project.mode || "Detection";

  const currentResult =
    current &&
    results[current.name];
  const activeCalibrationPreview = previewEligible && calibrationPreview?.filename === current?.name &&
    calibrationPreview?.previewKey === previewKey
    ? calibrationPreview
    : null;
  const visibleResult = semiAnnotationEnabled && activeCalibrationPreview
    ? {
        ...activeCalibrationPreview,
        overlays: (activeCalibrationPreview.overlays || []).filter(
          (overlay) => overlay.confidence == null || overlay.confidence >= selectedThreshold
        ),
        detections: (activeCalibrationPreview.overlays || []).filter(
          (overlay) => overlay.confidence == null || overlay.confidence >= selectedThreshold
        ).length,
      }
    : previewEligible ? {detections: 0, overlays: []} : currentResult;

  function goToPage(value = pageInput ?? String(index + 1)) {
    const page = Number.parseInt(value, 10);

    if (!Number.isFinite(page) || page < 1 || page > images.length) {
      setPageInput(null);
      return;
    }

    setIndex(page - 1);
    setPageInput(null);
  }

  const previousImage = () => setIndex((value) => Math.max(0, value - 1));
  const nextImage = () => setIndex((value) => Math.min(images.length - 1, value + 1));

  function toggleSample(sampleIndex) {
    setCalibrationReady(false);
    setSelectedSampleIndices((current) => {
      if (current.includes(sampleIndex)) return current.filter((value) => value !== sampleIndex);
      if (current.length >= 10) {
        setToast("A maximum of 10 pre-annotation samples can be selected.");
        return current;
      }
      return [...current, sampleIndex];
    });
  }

  useEffect(() => {
    fetch(`${API_URL}/prompts`)
      .then((response) =>
        response.ok ? response.json() : { prompts: [] }
      )
      .then((data) =>
        setSavedPrompts(data.prompts || [])
      )
      .catch(() => {});
  }, []);

  useEffect(() => {
    saveWorkspace(project.id, {
      images,
      index,
      roi,
      roiSourceIndex,
      aoi,
      promptMode,
      prompts,
      results,
      status,
      job,
      runKind,
      semiModel,
      sourceToken,
      sourceKind,
      sourcePath,
      confidenceThreshold,
      selectedSampleIndices,
    });
  }, [
    roiSourceIndex,
    images,
    index,
    job,
    runKind,
    semiModel,
    project.id,
    promptMode,
    prompts,
    results,
    roi,
    aoi,
    saveWorkspace,
    sourceToken,
    sourceKind,
    sourcePath,
    confidenceThreshold,
    selectedSampleIndices,
    status,
  ]);

  useEffect(() => {
    if (!toast) return undefined;

    const id = setTimeout(
      () => setToast(""),
      4500
    );

    return () => clearTimeout(id);
  }, [toast]);

  useEffect(() => {
    return () => {
      socketRef.current?.close();
      liveDisplayRef.current.generation += 1;
      liveDisplayRef.current.queue = [];
      clearTimeout(previewTimerRef.current);
      previewAbortRef.current?.abort();
    };
  }, []);

  // A browser WebSocket can be interrupted by navigation, sleep or a proxy.
  // The backend job keeps running, so poll its durable status until it reaches
  // a server-confirmed terminal state instead of falsely clearing it.
  useEffect(() => {
    if (!job?.id) return undefined;
    let active = true;
    const poll = async () => {
      try {
        const response = await fetch(`${API_URL}/annotate/${job.id}`);
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.detail || "Could not read annotation status.");
        if (active) applyProgress(payload);
      } catch (error) {
        if (active) setStatus("Live updates paused; reconnecting to the backend job…");
      }
    };
    poll();
    const timer = setInterval(poll, 1000);
    return () => { active = false; clearInterval(timer); };
    // applyProgress intentionally reads the current component state; a job ID
    // is the durable subscription boundary.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [job?.id]);

  async function linkSource(kind, pathValue = sourcePath) {
    if (activeJobRef.current) return setToast("Cancel the current annotation before changing its source.");
    liveDisplayRef.current.generation += 1;
    liveDisplayRef.current.queue = [];
    socketRef.current?.close();
    socketRef.current = null;
    const path = pathValue.trim();

    if (!path) {
      return setToast(
        `Enter the full ${
          kind.startsWith("video") ? "video" : "folder"
        } path on the backend PC.`
      );
    }

    setStatus(
      kind === "video"
        ? "Extracting video frames on the backend…"
        : "Reading backend image folder…"
    );

    try {
      const form = new FormData();

      form.append("path", path);

      const response = await fetch(
        `${API_URL}/sources/${kind}`,
        {
          method: "POST",
          body: form,
        }
      );

      const payload = await response.json();

      if (!response.ok) {
        throw new Error(
          payload.detail ||
            "Could not prepare this source."
        );
      }

      setSourceToken(payload.token);
      setSourceKind(kind);
      setSourcePath(path);

      setImages(payload.sourceType === "direct-video"
        ? [{ name: payload.name, url: `${API_URL}${payload.videoUrl}`, isVideo: true }]
        : payload.files.map((file) => ({
            name: file.name,
            sourceIndex: file.index,
            url: `${API_URL}/sources/${payload.token}/image/${file.index}`,
          }))
      );

      setIndex(0);
      setResults({});
      setSelectedSampleIndices([]);
      setCalibrationReady(false);
      setRoi([]);
      setAoi([]);
      setDialog(null);
      setSourceMenu(false);

      setStatus(
        kind === "video"
          ? `${payload.count.toLocaleString()} video frames ready.`
          : kind === "video-direct"
            ? `Direct video linked (${payload.count.toLocaleString()} frames). It will be returned as one annotated video.`
          : `${payload.count.toLocaleString()} image(s) linked from the backend folder.`
      );
    } catch (error) {
      setStatus(
        error.message ||
          "Could not prepare this source."
      );
    }
  }

  async function refreshImageFolder() {
    if (activeJobRef.current) {
      try {
        const response = await fetch(`${API_URL}/annotate/${activeJobRef.current}`);
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.detail || "Refresh failed.");
        applyProgress(payload);
        setToast("Annotation status refreshed.");
      } catch (error) { setToast(error.message); }
      return;
    }
    liveDisplayRef.current.generation += 1;
    liveDisplayRef.current.queue = [];
    setCalibrationPreview(null);
    setSemiAnnotationEnabled(false);
    setCalibrationReady(false);
    setImageThresholds({});
    setJob(null);
    setRunning(false);
    if (sourceKind !== "folder" || !sourcePath.trim()) {
      setDialog("folder");
      return;
    }

    await linkSource("folder", sourcePath);
  }

  function point(event) {
    const rect =
      imageRef.current?.getBoundingClientRect();

    if (
      !rect ||
      event.clientX < rect.left ||
      event.clientX > rect.right ||
      event.clientY < rect.top ||
      event.clientY > rect.bottom
    ) {
      return null;
    }

    return {
      x: Number(
        (
          (event.clientX - rect.left) /
          rect.width
        ).toFixed(5)
      ),
      y: Number(
        (
          (event.clientY - rect.top) /
          rect.height
        ).toFixed(5)
      ),
    };
  }

  function shapedRoi(start, end) {
    const clamp = (value) =>
      Math.min(1, Math.max(0, value));

    const x1 = Math.min(start.x, end.x);
    const y1 = Math.min(start.y, end.y);

    let x2 = Math.max(start.x, end.x);
    let y2 = Math.max(start.y, end.y);

    if (roiShape === "square") {
      const side = Math.max(
        Math.abs(end.x - start.x),
        Math.abs(end.y - start.y)
      );

      x2 = clamp(
        start.x +
          (end.x >= start.x ? side : -side)
      );

      y2 = clamp(
        start.y +
          (end.y >= start.y ? side : -side)
      );

      const left = Math.min(start.x, x2);
      const top = Math.min(start.y, y2);

      return [
        { x: left, y: top },
        {
          x: Math.max(start.x, x2),
          y: top,
        },
        {
          x: Math.max(start.x, x2),
          y: Math.max(start.y, y2),
        },
        {
          x: left,
          y: Math.max(start.y, y2),
        },
      ];
    }

    if (roiShape === "triangle") {
      return [
        {
          x: (x1 + x2) / 2,
          y: y1,
        },
        {
          x: x2,
          y: y2,
        },
        {
          x: x1,
          y: y2,
        },
      ];
    }

    if (roiShape === "circle") {
      const cx = (x1 + x2) / 2;
      const cy = (y1 + y2) / 2;

      const rx = (x2 - x1) / 2;
      const ry = (y2 - y1) / 2;

      return Array.from(
        { length: 28 },
        (_, index) => {
          const angle =
            (Math.PI * 2 * index) / 28;

          return {
            x: cx + rx * Math.cos(angle),
            y: cy + ry * Math.sin(angle),
          };
        }
      );
    }

    return [start, end];
  }

  function beginRoi(event) {
    if (
      !drawing && !drawingAoi
    ) {
      return;
    }

    const next = point(event);

    if (!next) return;

    event.currentTarget.setPointerCapture(
      event.pointerId
    );

    drawingRef.current = true;
    roiStartRef.current = next;

    if (drawingAoi) setAoi([next]);
    else {
      setRoiSourceIndex(current?.sourceIndex ?? index);
      setCalibrationReady(false);
      setRoi([next]);
    }
  }

  function extendRoi(event) {
    if (!drawingRef.current) return;

    const next = point(event);

    if (!next) return;

    if (drawingAoi) {
      setAoi((value) => [...value, next]);
    } else if (roiShape === "freehand") {
      setRoi((value) => [
        ...value,
        next,
      ]);
    } else {
      setRoi(
        shapedRoi(
          roiStartRef.current,
          next
        )
      );
    }
  }

  function finishRoi() {
    drawingRef.current = false;
    roiStartRef.current = null;
  }

  async function addPrompt(value = promptText) {
    const clean = value.trim();

    if (
      !clean ||
      (editingPromptIndex === null && prompts.includes(clean))
    ) {
      return;
    }

    setPrompts((value) => editingPromptIndex === null
      ? [...value, clean]
      : value.map((prompt, index) => index === editingPromptIndex ? clean : prompt)
    );

    setPromptText("");
    setEditingPromptIndex(null);

    try {
      const form = new FormData();

      form.append("prompt", clean);

      const response = await fetch(
        `${API_URL}/prompts`,
        {
          method: "POST",
          body: form,
        }
      );

      if (response.ok) {
        setSavedPrompts(
          (
            await response.json()
          ).prompts || []
        );
      }
    } catch {
      setToast(
        "Prompt added for this session but could not be saved to the library."
      );
    }
  }

  async function deleteSavedPrompt(prompt) {
    const form = new FormData();
    form.append("prompt", prompt);
    try {
      const response = await fetch(`${API_URL}/prompts`, { method: "DELETE", body: form });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.detail || "Could not remove this prompt.");
      setSavedPrompts(payload.prompts || []);
    } catch (error) {
      setToast(error.message || "Could not remove this prompt.");
    }
  }

  async function generateAutoPrompt() {
    if (!current) {
      return setToast(
        "Link an image folder or video before generating a prompt."
      );
    }

    setRunning(true);

    setStatus(
      roi.length >= 3
        ? "Generating a VLM prompt from the drawn ROI…"
        : "Generating a VLM prompt from the current image…"
    );

    try {
      const form = new FormData();

      form.append(
        "roi",
        JSON.stringify(roi)
      );

      if (!sourceToken) {
        throw new Error(
          "Use a backend image folder or video source for VLM prompting."
        );
      }

      form.append(
        "source_token",
        sourceToken
      );

      form.append(
        "source_index",
        String(current.sourceIndex)
      );

      const response = await fetch(
        `${API_URL}/auto-prompt/source`,
        {
          method: "POST",
          body: form,
        }
      );

      const payload =
        await response.json();

      if (!response.ok) {
        throw new Error(
          payload.detail ||
            "Auto-prompt generation failed."
        );
      }

      setPrompts((value) =>
        value.includes(payload.prompt)
          ? value
          : [...value, payload.prompt]
      );

      setSavedPrompts(
        payload.prompts || []
      );

      setDrawing(false);
      setRoi([]);

      setStatus(
        `Added VLM prompt: ${payload.prompt}`
      );
    } catch (error) {
      setStatus(
        error.message ||
          "Auto-prompt generation failed."
      );
    } finally {
      setRunning(false);
    }
  }

  function showLiveResults(items) {
    const display = liveDisplayRef.current;
    for (const [sequence, item] of items.entries()) {
      if (!display.seen.has(item.filename)) {
        display.seen.add(item.filename);
        display.queue.push({ ...item, displaySequence: sequence + 1 });
      }
    }
    if (display.pumping) return;
    display.pumping = true;
    const generation = display.generation;
    const preload = (url) => new Promise((resolve) => {
      const image = new window.Image();
      image.onload = image.onerror = resolve;
      image.src = url;
    });
    (async () => {
      try {
        while (display.queue.length && generation === display.generation) {
          const item = document.hidden ? display.queue.splice(0).at(-1) : display.queue.shift();
          const imageIndex = images.findIndex((image) => image.name === item.filename);
          if (imageIndex < 0) continue;
          if (item.annotatedUrl && !document.hidden) await Promise.all([
            preload(images[imageIndex].url), preload(`${API_URL}${item.annotatedUrl}`),
          ]);
          if (generation !== display.generation) break;
          setIndex(imageIndex);
          // Yield for rendering without getting stuck in a hidden tab.
          if (!document.hidden) await new Promise((resolve) => {
            const fallback = setTimeout(resolve, 100);
            requestAnimationFrame(() => requestAnimationFrame(() => { clearTimeout(fallback); resolve(); }));
          });
          if (generation !== display.generation) break;
          if (socketRef.current?.readyState === WebSocket.OPEN) {
            socketRef.current.send(`displayed:${item.displaySequence}`);
          }
        }
      } finally {
        display.pumping = false;
        if (generation === display.generation && pendingCompletionRef.current) {
          const completed = pendingCompletionRef.current;
          pendingCompletionRef.current = null;
          completionActionRef.current?.(completed);
        }
      }
    })();
  }

  function applyProgress(payload) {
    if (payload.jobId !== activeJobRef.current) return;
    {
      setResults((value) => ({
        ...value,
        ...Object.fromEntries(payload.results.map((result) => [result.filename, result])),
      }));
    }

    if (payload.completed > 0 && !cancellingRef.current && payload.results.some((item) => !liveDisplayRef.current.seen.has(item.filename))) showLiveResults(payload.results);

    if (payload.state === "complete") {
      if (!cancellingRef.current && (liveDisplayRef.current.pumping || liveDisplayRef.current.queue.length)) {
        pendingCompletionRef.current = payload;
        setStatus("Displaying the final annotated images…");
        return;
      }
      const count =
        payload.results.reduce(
          (sum, item) =>
            sum + (item.detections || 0),
          0
        );

      if (runKindRef.current === "pre-annotation") {
        const covered = payload.results.filter((item) => (item.detections || 0) > 0).length;
        const successful = payload.results.length > 0 && payload.results.every((item) => !item.error);
        setCalibrationReady(successful);
        setSemiAnnotationEnabled(!successful);
        setStatus(`Recovery preview complete · detections in ${covered}/${payload.completed} samples · ${count.toLocaleString()} accepted objects`);
      } else {
        const errors = payload.results.filter((item) => item.error).length;
        const empty = payload.results.filter((item) => !item.error && !item.detections).length;
        setStatus(`Complete · ${payload.completed}/${payload.total || images.length} processed · ${count.toLocaleString()} objects · ${empty} no match · ${errors} errors`);
      }

      activeJobRef.current = null;
      socketRef.current?.close();
      setRunning(false);
      setJob(null);
    } else if (
      payload.state === "failed"
    ) {
      activeJobRef.current = null;
      socketRef.current?.close();
      setStatus(
        payload.error ||
          "Annotation job failed."
      );

      setRunning(false);
      setJob(null);
    } else if (
      payload.state === "cancelled"
    ) {
      activeJobRef.current = null;
      socketRef.current?.close();
      liveDisplayRef.current.generation += 1;
      liveDisplayRef.current.queue = [];
      setStatus(
        `Cancelled after ${payload.completed.toLocaleString()} images.`
      );

      setRunning(false);
      setJob(null);
    } else {
      setStatus(cancellingRef.current ? "Cancelling current image…" : `Streaming ${payload.completed.toLocaleString()} / ${(payload.total || images.length).toLocaleString()} images`);
    }
  }

  completionActionRef.current = applyProgress;
  async function startAnnotation({ preAnnotation = false, confidenceOverride = null, modelOverride = null } = {}) {
    if (previewBusyRef.current) return setToast("Wait for the selected image preview to finish.");
    if (running) return;

    if (
      !images.length ||
      !prompts.length ||
      !sourceToken
    ) {
      return setToast(
        "Link a source folder or video and add one or more prompts first."
      );
    }

    const form = new FormData();

    form.append(
      "project_name",
      project.name
    );

    form.append(
      "mode",
      mode.toLowerCase()
    );

    form.append("roi", JSON.stringify(roi));
    const selectedModel = modelOverride || (preAnnotation ? semiModel : "sam3");
    form.append("annotation_model", selectedModel);
    // The ROI describes the object on the frame where it was drawn. It must
    // not become a fixed search window at the same coordinates in every image.
    if (roi.length >= 3 && roiSourceIndex < 0) {
      return setToast("Redraw the object ROI once to identify its reference image.");
    }
    form.append("roi_source_index", String(roiSourceIndex));
    form.append("aoi", JSON.stringify(aoi));
    form.append("confidence_threshold", String(confidenceOverride ?? (preAnnotation || calibrationReady ? confidenceThreshold : 0.15)));
    form.append("image_thresholds", JSON.stringify(preAnnotation
      ? Object.fromEntries(selectedSampleIndices.map((sample) => [images[sample]?.name, imageThresholds[images[sample]?.name] ?? 0.5]))
      : calibrationReady ? imageThresholds : {}));
    form.append("sample_limit", preAnnotation ? "10" : "0");
    form.append("pre_annotation", preAnnotation ? "true" : "false");
    form.append("sample_indices", JSON.stringify(
      preAnnotation ? selectedSampleIndices : []
    ));
    form.append("preview_index", "-1");
    form.append("live_sync", "false");

    form.append(
      "prompts",
      JSON.stringify(prompts)
    );

    form.append(
      "source_token",
      sourceToken
    );

    setRunning(true);
    pendingCompletionRef.current = null;
    setSemiAnnotationEnabled(false);
    setCalibrationPreview(null);
    liveDisplayRef.current.generation += 1;
    liveDisplayRef.current = { generation: liveDisplayRef.current.generation, seen: new Set(), queue: [], pumping: false };
    const nextRunKind = preAnnotation ? "pre-annotation" : "annotation";
    runKindRef.current = nextRunKind;
    setRunKind(nextRunKind);
    if (!preAnnotation) {
      setResults({});
      setIndex(0);
    }

    setStatus(
      preAnnotation
        ? `Running ${selectedModel.toUpperCase()} on ${selectedSampleIndices.length} samples…`
        : `Starting ${selectedModel.toUpperCase()} for ${images.length.toLocaleString()} images…`
    );

    try {
      const response = await fetch(
        `${API_URL}${sourceKind === "video-direct" ? "/annotate/source-video" : "/annotate/source-folder"}`,
        {
          method: "POST",
          body: form,
        }
      );

      const payload =
        await response.json();

      if (!response.ok) {
        throw new Error(
          payload.detail ||
            "Annotation failed."
        );
      }

      setJob({
        id: payload.jobId,
      });
      activeJobRef.current = payload.jobId;
      cancellingRef.current = false;

      const socket = new WebSocket(
        wsUrl(
          `/annotate/${payload.jobId}/stream`
        )
      );

      socketRef.current = socket;

      socket.onmessage = (event) => {
        applyProgress(
          JSON.parse(event.data)
        );
      };

      socket.onerror = () => {
        setStatus(
          "Live updates paused; reconnecting to the backend job…"
        );
      };
    } catch (error) {
      setStatus(
        error.message ||
          "Annotation failed."
      );

      setRunning(false);
    }
  }

  async function cancelAnnotation() {
    clearTimeout(previewTimerRef.current);
    liveDisplayRef.current.generation += 1;
    liveDisplayRef.current.queue = [];
    cancellingRef.current = true;
    pendingCompletionRef.current = null;
    if (!job?.id) {
      setRunning(false);
      return;
    }

    const cancelledJobId = job.id;

    socketRef.current?.send(
      "cancel"
    );
    socketRef.current?.close();
    socketRef.current = null;
    setStatus("Cancelling current image…");

    try {
    const response = await fetch(
      `${API_URL}/annotate/${cancelledJobId}/cancel`,
      {
        method: "POST",
      }
    );
    if (!response.ok) throw new Error("Could not cancel this job.");
    } catch (error) { cancellingRef.current = false; setToast(error.message); }
  }

  const promptContent = (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto px-3 py-3">
      <div className="rounded-xl bg-[var(--bg-main)] p-1">
        <button
          onClick={() => {
            setPromptMode("manual");
            setDrawing(false);
            setRoi([]);
          }}
          className={`w-1/2 rounded-lg px-3 py-2.5 text-xs font-bold ${
            promptMode === "manual"
              ? "bg-[var(--bg-surface)] text-[var(--accent-500)] shadow-sm"
              : "text-[var(--text-tertiary)]"
          }`}
        >
          Manual prompts
        </button>

        <button
          onClick={() =>
            setPromptMode("auto")
          }
          className={`w-1/2 rounded-lg px-3 py-2.5 text-xs font-bold ${
            promptMode === "auto"
              ? "bg-[var(--bg-surface)] text-[var(--accent-500)] shadow-sm"
              : "text-[var(--text-tertiary)]"
          }`}
        >
          Auto-prompt (VLM)
        </button>
      </div>

      {promptMode === "manual" ? (
        <div className="mt-3 space-y-3">
          <div>
            <p className="text-sm font-bold">
              Add an object prompt
            </p>

            <p className="mt-1 text-xs leading-5 text-[var(--text-tertiary)]">
              Object to annotate
            </p>
          </div>

          <div className="flex gap-2">
            <input
              value={promptText}
              onChange={(event) =>
                setPromptText(
                  event.target.value
                )
              }
              onKeyDown={(event) =>
                event.key === "Enter" &&
                addPrompt()
              }
              placeholder="e.g. white light-blue rectangular box"
              className="min-w-0 flex-1 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] px-3 py-2.5 text-sm outline-none focus:border-[var(--accent-500)]"
            />

            <button
              onClick={() =>
                addPrompt()
              }
              className="rounded-xl bg-[var(--accent-500)] px-4 text-sm font-bold text-white"
            >
              Add
            </button>
          </div>

          <details className="group overflow-hidden rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)]">
            <summary className="cursor-pointer list-none px-3 py-2.5 text-sm text-[var(--text-secondary)]">
              Choose from saved prompts ({savedPrompts.length})
            </summary>

            <div className="max-h-52 overflow-y-auto border-t border-[var(--border-color)] p-1.5">
              {savedPrompts.length ? savedPrompts.map((prompt) => (
                <div key={prompt} className="flex items-center gap-1 rounded-lg hover:bg-[var(--bg-hover)]">
                  <button
                    type="button"
                    onClick={() => addPrompt(prompt)}
                    className="min-w-0 flex-1 truncate px-2.5 py-2 text-left text-xs text-[var(--text-secondary)]"
                    title={`Use prompt: ${prompt}`}
                  >
                    {prompt}
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteSavedPrompt(prompt)}
                    className="mr-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[var(--text-tertiary)] hover:bg-red-500/10 hover:text-red-500"
                    title="Remove saved prompt"
                    aria-label={`Remove saved prompt ${prompt}`}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )) : (
                <p className="px-2.5 py-3 text-xs text-[var(--text-tertiary)]">No saved prompts yet.</p>
              )}
            </div>
          </details>

          <div className="border-t border-[var(--border-color)] pt-4">
            <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
              Optional manual ROI
            </p>
            <p className="mt-1 text-xs leading-5 text-[var(--text-tertiary)]">
              Mark the target object on this reference image. Other images are searched globally, so the object may move.
            </p>

            <div className="mt-3 grid grid-cols-2 gap-2">
              {[["freehand", "Freehand"], ["square", "Square"], ["circle", "Circle"], ["triangle", "Triangle"]].map(([value, label]) => (
                <button
                  key={value}
                  onClick={() => setRoiShape(value)}
                  className={`rounded-xl border px-3 py-2 text-xs font-bold ${
                    roiShape === value
                      ? "border-[var(--accent-500)] bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
                      : "border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="mt-3 flex gap-2">
              <button
                onClick={() => { setDrawing((value) => !value); setDrawingAoi(false); }}
                className={`flex-1 rounded-xl px-3 py-2.5 text-sm font-bold ${
                  drawing
                    ? "bg-amber-400 text-slate-950"
                    : "border border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
                }`}
              >
                {drawing ? `Draw ${roiShape} on raw image` : `Draw ${roiShape} ROI (optional)`}
              </button>
              <button
                onClick={() => { setDrawing(false); setRoi([]); }}
                disabled={!roi.length}
                className="rounded-xl border border-red-300 px-3 text-red-600 disabled:opacity-30"
                title="Clear ROI"
              >
                <Trash2 size={17} />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-5 space-y-4">
          <div className="rounded-2xl border border-[var(--border-color)] bg-[var(--bg-main)] p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)]">
                <Sparkles size={17} />
              </div>

              <div>
                <p className="text-sm font-bold">
                  Build prompts with VLM
                </p>

                <p className="mt-1 text-xs leading-5 text-[var(--text-tertiary)]">
                  Draw an ROI around one object, generate its prompt, then repeat for another object.
                </p>
              </div>
            </div>
          </div>

          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
              ROI shape
            </p>

            <div className="grid grid-cols-2 gap-2">
              {[
                ["freehand", "Freehand"],
                ["square", "Square"],
                ["circle", "Circle"],
                ["triangle", "Triangle"],
              ].map(
                ([value, label]) => (
                  <button
                    key={value}
                    onClick={() =>
                      setRoiShape(value)
                    }
                    className={`rounded-xl border px-3 py-2.5 text-xs font-bold ${
                      roiShape === value
                        ? "border-[var(--accent-500)] bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
                        : "border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
                    }`}
                  >
                    {label}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => {
                setDrawing((value) => !value);
                setDrawingAoi(false);
              }}
              className={`flex-1 rounded-xl px-3 py-2.5 text-sm font-bold ${
                drawing
                  ? "bg-amber-400 text-slate-950"
                  : "border border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
              }`}
            >
              {drawing
                ? `Draw ${roiShape} on raw image`
                : `Draw ${roiShape} ROI`}
            </button>

            <button
              onClick={() => {
                setDrawing(false);
                setRoi([]);
              }}
              disabled={!roi.length}
              className="rounded-xl border border-red-300 px-3 text-red-600 disabled:opacity-30"
              title="Clear ROI"
            >
              <Trash2 size={17} />
            </button>
          </div>

          <button
            onClick={generateAutoPrompt}
            disabled={running}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-[var(--accent-500)] px-3 py-3 text-sm font-bold text-white shadow-sm disabled:opacity-50"
          >
            <Sparkles size={17} />
            Generate prompt with VLM
          </button>
        </div>
      )}

      <div className="mt-3 border-t border-[var(--border-color)] pt-3">
        <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
          AOI — Area of Interest
        </p>
        <p className="mt-1 text-xs leading-5 text-[var(--text-tertiary)]">
          Draw a freehand boundary. Objects outside this area are excluded from annotation.
        </p>
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={() => {
              setDrawingAoi((value) => !value);
              setDrawing(false);
            }}
            className={`flex-1 rounded-xl px-3 py-2.5 text-sm font-bold ${
              drawingAoi
                ? "bg-cyan-400 text-slate-950"
                : "border border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
            }`}
          >
            {drawingAoi ? "Draw freehand AOI on raw image" : aoi.length ? "Redraw freehand AOI" : "Draw freehand AOI"}
          </button>
          <button
            type="button"
            onClick={() => { setDrawingAoi(false); setAoi([]); }}
            disabled={!aoi.length}
            className="rounded-xl border border-red-300 px-3 text-red-600 disabled:opacity-30"
            title="Clear AOI"
          >
            <Trash2 size={17} />
          </button>
        </div>
      </div>

      <button
        type="button"
        onClick={() => {
          if (calibrationReady) {
            setCalibrationReady(false);
            setSemiAnnotationEnabled(true);
          } else {
            setSemiAnnotationEnabled((value) => !value);
          }
        }}
        className="mt-5 flex w-full items-center justify-between rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface)] px-3 py-2.5 text-left text-xs font-bold hover:border-[var(--accent-500)]"
        aria-expanded={semiAnnotationEnabled}
      >
        <span>Semi-Annotation</span>
        <span className={`rounded-full px-2 py-0.5 text-[10px] ${calibrationReady ? "bg-emerald-500/10 text-emerald-500" : "bg-[var(--bg-hover)] text-[var(--text-tertiary)]"}`}>
          {calibrationReady ? "COMPLETED" : semiAnnotationEnabled ? "ON" : "OFF"}
        </span>
      </button>

      {semiAnnotationEnabled && !calibrationReady && (
      <div className="mt-2 rounded-xl border border-[var(--accent-500)]/25 bg-[var(--accent-500)]/5 p-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm font-bold">Semi-Annotation</p>
          </div>
          {calibrationReady && (
            <span className="shrink-0 rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-bold text-emerald-500">READY</span>
          )}
        </div>

          <div className="mt-3">
          <label className="mb-3 flex items-center justify-between gap-2 text-xs font-bold">Recovery model <select aria-label="Semi-annotation model" value={semiModel} disabled={running} onChange={(e) => { setSemiModel(e.target.value); setCalibrationReady(false); setCalibrationPreview(null); }} className="rounded-lg bg-[var(--bg-surface)] p-2 text-xs font-semibold"><option value="sam2">SAM2</option><option value="sam3">SAM3</option></select></label>
          <div className="mb-2 flex items-center justify-between text-xs font-bold">
            <label htmlFor="sam3-confidence">Confidence threshold</label>
            <span className="rounded-lg border border-[var(--border-color)] bg-[var(--bg-surface)] px-2 py-1 tabular-nums">
              {selectedThreshold.toFixed(2)}
            </span>
          </div>
          <input
            id="sam3-confidence"
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={selectedThreshold}
            disabled={running || !previewEligible}
            onChange={(event) => {
              const nextThreshold = Number(event.target.value);
              setImageThresholds((values) => ({ ...values, [current.name]: nextThreshold }));
              setCalibrationReady(false);
              clearTimeout(previewTimerRef.current);
            }}
            className="w-full accent-[var(--accent-500)]"
          />
          <div className="mt-1 flex justify-between text-[10px] text-[var(--text-tertiary)]"><span>More candidates</span><span>Stricter match</span></div>
          <p role="status" className="mt-2 text-xs">{!previewEligible ? "Select this image with + to preview." : previewBusy ? "Loading this image’s candidates…" : previewError || (activeCalibrationPreview ? `${visibleResult.detections} matches at ${selectedThreshold.toFixed(2)} · this image only` : "Waiting for preview…")}</p>
        </div>

        <button
          type="button"
          onClick={() => startAnnotation({ preAnnotation: true })}
          disabled={running || previewBusy || !selectedSampleIndices.length || !prompts.length || sourceKind === "video-direct"}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[var(--accent-500)] bg-[var(--bg-surface)] px-3 py-2.5 text-xs font-bold text-[var(--accent-500)] transition hover:bg-[var(--accent-500)]/10 disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Play size={14} /> Run sample annotation ({selectedSampleIndices.length}/10)
        </button>
        {sourceKind === "video-direct" && (
          <p className="mt-2 text-[10px] text-[var(--text-tertiary)]">Use Video to Frame Conversion to calibrate on a 10-frame sample.</p>
        )}
      </div>
      )}

      <div className="mt-4 border-t border-[var(--border-color)] pt-4">
        <div className="mb-2 flex items-center justify-between">
          <div>
            <p className="text-sm font-bold">
              Active prompts
            </p>

          </div>

          <span className="rounded-full bg-[var(--accent-500)]/10 px-2 py-0.5 text-xs font-bold text-[var(--accent-500)]">
            {prompts.length}
          </span>
        </div>

        <div className="flex max-h-40 flex-wrap gap-2 overflow-y-auto">
          {prompts.length ? (
            prompts.map(
              (prompt, i) => (
                <div
                  key={`${prompt}-${i}`}
                  className="flex items-center overflow-hidden rounded-xl border border-[var(--accent-500)]/20 bg-[var(--accent-500)]/10 text-xs font-semibold text-[var(--accent-500)]"
                >
                  <span className="px-2.5 py-1.5">{i + 1}. {prompt}</span>
                  <button
                    type="button"
                    onClick={() => { setPromptMode("manual"); setPromptText(prompt); setEditingPromptIndex(i); }}
                    className="p-1.5 hover:bg-[var(--accent-500)]/15"
                    title="Edit selected prompt"
                    aria-label={`Edit selected prompt ${prompt}`}
                  >✎</button>
                  <button
                    type="button"
                    onClick={() => setPrompts((value) => value.filter((_, j) => j !== i))}
                    className="p-1.5 hover:bg-red-500/10 hover:text-red-500"
                    title="Remove selected prompt"
                    aria-label={`Remove selected prompt ${prompt}`}
                  >×</button>
                </div>
              )
            )
          ) : (
            <p className="text-xs text-[var(--text-tertiary)]">
              No prompt selected yet.
            </p>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="relative flex min-h-0 flex-1 overflow-hidden">
      {reprocessing && <ReprocessingQueue project={project} model={semiModel} onClose={() => setReprocessing(false)} />}
      {toast && (
        <div
          role="alert"
          className="absolute right-5 top-5 z-50 flex max-w-md gap-2 rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-700 shadow-xl"
        >
          <AlertCircle size={18} />
          {toast}
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col p-2.5 md:p-3.5">
        {dialog === "folder" && (
          <Dialog
            title="Link images folder"
            onClose={() =>
              setDialog(null)
            }
          >
           <div className="space-y-5 p-5">
  <div>
    <label className="mb-2 block text-sm font-medium">
      Images folder path on backend
    </label>

    <input
      autoFocus
      value={sourcePath}
      onChange={(event) =>
        setSourcePath(
          event.target.value
        )
      }
      onKeyDown={(event) =>
        event.key ===
          "Enter" &&
        linkSource("folder")
      }
      placeholder="C:\\Images\\Production batch"
      className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] px-3 py-3 text-sm outline-none focus:border-[var(--accent-500)]"
    />
  </div>

  <button
    onClick={() =>
      linkSource("folder")
    }
    className="w-full rounded-xl bg-[var(--accent-500)] py-3 text-sm font-bold text-white"
  >
    Link images folder
  </button>
</div>
          </Dialog>
        )}

        {dialog === "video" && (
          <Dialog
            title="Prepare backend video"
            onClose={() =>
              setDialog(null)
            }
          >
            <div className="space-y-4 p-5">
              <label className="text-sm">Video path on backend</label>

              <input
                autoFocus
                value={sourcePath}
                onChange={(event) =>
                  setSourcePath(
                    event.target.value
                  )
                }
                onKeyDown={(event) =>
                  event.key ===
                    "Enter" &&
                  linkSource("video")
                }
                placeholder="C:\\Videos\\training.avi"
                className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] px-3 py-3 text-sm outline-none focus:border-[var(--accent-500)]"
              />

              <button
                onClick={() =>
                  linkSource("video")
                }
                className="w-full rounded-xl bg-[var(--accent-500)] py-3 text-sm font-bold text-white"
              >
                Extract and link video frames
              </button>
            </div>
          </Dialog>
        )}

        {dialog === "video-mode" && (
          <Dialog title="Choose video loading mode" onClose={() => setDialog(null)}>
            <div className="grid gap-3 p-5 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setDialog("video")}
                className="rounded-2xl border border-[var(--border-color)] p-5 text-left transition hover:border-[var(--accent-500)] hover:bg-[var(--accent-500)]/5"
              >
                <p className="font-bold">Video to Frame Conversion</p>
                <p className="mt-2 text-xs leading-5 text-[var(--text-tertiary)]">Extract every frame and use the existing image navigation workflow.</p>
              </button>
              <button
                type="button"
                onClick={() => setDialog("video-direct")}
                className="rounded-2xl border border-[var(--border-color)] p-5 text-left transition hover:border-[var(--accent-500)] hover:bg-[var(--accent-500)]/5"
              >
                <p className="font-bold">Direct Video Loading</p>
                <p className="mt-2 text-xs leading-5 text-[var(--text-tertiary)]">Load and return one playable annotated video.</p>
              </button>
            </div>
          </Dialog>
        )}

        {dialog === "video-direct" && (
          <Dialog title="Link direct backend video" onClose={() => setDialog(null)}>
            <div className="space-y-4 p-5">
              <p className="text-sm leading-6 text-[var(--text-secondary)]">The backend processes the video sequentially and returns one playable annotated video.</p>
              <input
                autoFocus value={sourcePath} onChange={(event) => setSourcePath(event.target.value)}
                onKeyDown={(event) => event.key === "Enter" && linkSource("video-direct")}
                placeholder="C:\\Videos\\training.mp4"
                className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] px-3 py-3 text-sm outline-none focus:border-[var(--accent-500)]"
              />
              <button onClick={() => linkSource("video-direct")} className="w-full rounded-xl bg-[var(--accent-500)] py-3 text-sm font-bold text-white">
                Load direct video
              </button>
            </div>
          </Dialog>
        )}

        {/* TOP BAR */}
        <header className="mb-3 flex shrink-0 flex-col gap-2 xl:flex-row xl:items-center xl:justify-between">
          <div className="min-w-0 xl:flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-[var(--accent-500)]/10 px-2 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-[var(--accent-500)]">
                {mode} workspace
              </span>
              <span className="text-xs font-semibold text-[var(--text-secondary)]">{project.name}</span>
            </div>

            <p className="mt-1.5 truncate text-xs text-[var(--text-tertiary)]">
              {status ||
                "Link a backend source, choose prompts, then start streaming annotation."}
            </p>
          </div>

          <div className="relative flex flex-wrap items-center gap-2 xl:justify-end">
            <button
              onClick={() =>
                setDialog("folder")
              }
              disabled={running}
              title={sourcePath ? sourcePath.replace(/[\\/]+$/, "").split(/[\\/]/).pop() : "No images folder loaded"}
              aria-label={sourcePath ? `Images folder. Loaded folder: ${sourcePath}` : "Images folder. No folder loaded"}
              className="flex items-center gap-2 rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface)] px-3 py-2.5 text-xs font-bold shadow-sm transition hover:bg-[var(--bg-hover)]"
            >
              <FolderOpen size={16} />
              Images folder
            </button>

            <button
              onClick={refreshImageFolder}
              className="rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface)] p-2.5 shadow-sm transition hover:bg-[var(--bg-hover)] disabled:cursor-not-allowed disabled:opacity-40"
              title={running ? "Refresh annotation status" : sourceKind === "folder" && sourcePath ? "Refresh the linked images folder" : "Select an images folder to refresh"}
              aria-label="Refresh images folder"
            >
              <RefreshCw size={16} />
            </button>

            <button
              onClick={() =>
                setDialog("prompt")
              }
              title={prompts.length ? `Selected prompts:\n${prompts.join("\n")}` : "No prompts selected"}
              aria-label={prompts.length ? `Prompts. Selected: ${prompts.join(", ")}` : "Prompts. None selected"}
              className="flex items-center gap-2 rounded-xl border border-[var(--accent-500)]/25 bg-[var(--accent-500)]/10 px-3 py-2.5 text-xs font-bold text-[var(--accent-500)] shadow-sm transition hover:bg-[var(--accent-500)]/15"
            >
              <Sparkles size={16} />
              Prompts

              <span className="rounded-full bg-[var(--accent-500)] px-1.5 py-0.5 text-[9px] font-extrabold text-white">
                {prompts.length}
              </span>
            </button>

            <button
              onClick={() =>
                setSourceMenu(
                  (value) => !value
                )
              }
              className="rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface)] p-2.5 shadow-sm hover:bg-[var(--bg-hover)]"
              aria-label="Choose input source"
            >
              <Settings2 size={17} />
            </button>

            {sourceMenu && (
              <div className="absolute right-0 top-12 z-40 w-60 rounded-2xl border border-[var(--border-color)] bg-[var(--bg-surface)] p-2 shadow-2xl">
                <button
                  onClick={() => {
                    setDialog("folder");
                    setSourceMenu(false);
                  }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm hover:bg-[var(--bg-hover)]"
                >
                  <FolderOpen size={18} />
                  Backend images folder
                </button>

                <button
                  onClick={() => {
                    setDialog("video-mode");
                    setSourceMenu(false);
                  }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm hover:bg-[var(--bg-hover)]"
                >
                  <Video size={18} />
                  Backend video file
                </button>

                <button
                  onClick={() => {
                    setSourceMenu(false);

                    setToast(
                      "Live camera will be added as a backend capture source. It is not started in this browser because the GPU backend PC owns the capture pipeline."
                    );
                  }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm hover:bg-[var(--bg-hover)]"
                >
                  <Camera size={18} />
                  Live camera
                </button>
              </div>
            )}

            {images.length > 0 && (
              <div className="flex items-center rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface)] px-1 shadow-sm">
                <button
                  disabled={!index}
                  onClick={() =>
                    setIndex(
                      index - 1
                    )
                  }
                  className="p-2 disabled:opacity-25"
                  aria-label="Previous image"
                >
                  <ChevronLeft size={17} />
                </button>

                <label className="flex items-center text-[11px] font-extrabold tabular-nums" aria-label="Go to image number">
                  <input
                    value={pageInput ?? String(index + 1)}
                    onChange={(event) => setPageInput(event.target.value.replace(/\D/g, ""))}
                    onKeyDown={(event) => event.key === "Enter" && goToPage()}
                    onBlur={() => goToPage()}
                    inputMode="numeric"
                    className="w-12 bg-transparent px-1 py-1 text-right outline-none focus:text-[var(--accent-500)]"
                  />
                  <span className="pr-2 text-[var(--text-tertiary)]">/ {images.length.toLocaleString()}</span>
                </label>

                <button
                  disabled={
                    index ===
                    images.length - 1
                  }
                  onClick={() =>
                    setIndex(
                      index + 1
                    )
                  }
                  className="p-2 disabled:opacity-25"
                  aria-label="Next image"
                >
                  <ChevronRight size={17} />
                </button>
              </div>
            )}

            {running && (
              <button
                onClick={
                  cancelAnnotation
                }
                className="rounded-xl border border-red-300 bg-red-50 px-3 py-2.5 text-xs font-bold text-red-600"
              >
                Cancel
              </button>
            )}
          </div>
        </header>

        {/* IMAGE WORKSPACE */}
        <main
          className={`annotation-panels grid min-h-0 flex-1 grid-cols-1 gap-3 ${
            expandedPane
              ? ""
              : "xl:grid-cols-2"
          }`}
        >
          {/* RAW IMAGE */}
          {expandedPane !== "annotated" && (
            <ImagePane
              title="Raw image"
              image={current}
              mode={mode}
              onExpand={() => setExpandedPane((value) => value === "raw" ? null : "raw")}
              expanded={expandedPane === "raw"}
              onPrevious={previousImage}
              onNext={nextImage}
              previousDisabled={!index}
              nextDisabled={index === images.length - 1}
              sampleSelected={selectedSampleIndices.includes(current?.sourceIndex ?? index)}
              onToggleSample={current?.isVideo ? undefined : () => toggleSample(current?.sourceIndex ?? index)}
            >
              <div
                className="relative h-full w-full"
                onPointerDown={
                  beginRoi
                }
                onPointerMove={
                  extendRoi
                }
                onPointerUp={
                  finishRoi
                }
                onPointerCancel={
                  finishRoi
                }
              >
                {current ? (
                  <>
                    {current.isVideo ? (
                      <video ref={imageRef} src={current.url} controls className="h-full w-full object-contain" />
                    ) : (
                      <img
                        ref={imageRef}
                        src={current.url}
                        alt={current.name}
                        draggable="false"
                        className={`h-full w-full select-none object-fill ${drawing || drawingAoi ? "cursor-crosshair" : ""}`}
                      />
                    )}

                    <svg
                      className="pointer-events-none absolute inset-0 h-full w-full"
                      viewBox="0 0 1 1"
                      preserveAspectRatio="none"
                    >
                      {roi.length > 1 && (
                        <polygon
                          points={roi
                            .map(
                              (value) =>
                                `${value.x},${value.y}`
                            )
                            .join(" ")}
                          fill="rgba(250,204,21,.18)"
                          stroke="#facc15"
                          strokeWidth=".004"
                        />
                      )}
                      {aoi.length > 2 && (
                        <polygon
                          points={aoi.map((value) => `${value.x},${value.y}`).join(" ")}
                          fill="rgba(34,211,238,.12)"
                          stroke="#22d3ee"
                          strokeWidth=".005"
                        />
                      )}
                    </svg>
                  </>
                ) : (
                  <p className="grid h-full place-items-center text-sm text-[var(--text-tertiary)]">
                    Link an images folder or video to begin.
                  </p>
                )}
              </div>
            </ImagePane>
          )}

          {/* ANNOTATED IMAGE */}
          {expandedPane !== "raw" && <ImagePane
            title="Auto-annotated image"
            image={current}
            result={visibleResult}
            onExpand={() => setExpandedPane((value) => value === "annotated" ? null : "annotated")}
            expanded={expandedPane === "annotated"}
            onPrevious={previousImage}
            onNext={nextImage}
            previousDisabled={!index}
            nextDisabled={index === images.length - 1}
            mode={mode}
          >
            {visibleResult?.videoUrl ? (
              <video src={`${API_URL}${visibleResult.videoUrl}`} controls className="h-full w-full object-contain" />
            ) : visibleResult ? (
              <div className="relative h-full w-full">
                <img
                  src={previewEligible ? current.url : `${API_URL}${visibleResult.annotatedUrl}`}
                  alt="Annotation output"
                  className="h-full w-full object-fill"
                />
                <svg className="absolute inset-0 h-full w-full" viewBox="0 0 1 1" preserveAspectRatio="none">
                  {(visibleResult.overlays || []).map((overlay) => {
                    const labelX = Math.min(...overlay.polygon.map(([x]) => x));
                    const labelY = Math.max(0.025, Math.min(...overlay.polygon.map(([, y]) => y)) - 0.012);
                    const label = `${overlay.label}${overlay.confidence == null ? "" : ` ${overlay.confidence.toFixed(2)}`}`;
                    return (
                      <g key={overlay.id}>
                        <polygon
                          points={overlay.polygon.map(([x, y]) => `${x},${y}`).join(" ")}
                          fill={activeCalibrationPreview ? "rgba(99,102,241,.38)" : "transparent"}
                          stroke={activeCalibrationPreview ? "#818cf8" : "transparent"}
                          strokeWidth=".004"
                          className="cursor-pointer transition hover:fill-yellow-300/35 hover:stroke-yellow-300"
                        >
                          <title>{overlay.label}{overlay.confidence == null ? "" : ` · confidence ${overlay.confidence.toFixed(2)}`}</title>
                        </polygon>
                        {activeCalibrationPreview && (
                          <text
                            x={labelX}
                            y={labelY}
                            fill="white"
                            stroke="#111827"
                            strokeWidth=".006"
                            paintOrder="stroke"
                            fontSize=".018"
                            fontWeight="700"
                          >
                            {label}
                          </text>
                        )}
                      </g>
                    );
                  })}
                </svg>
              </div>
            ) : (
              <div className="grid h-full place-items-center px-8 text-center">
                <div>
                  <p className="font-semibold">
                    No output for this image yet
                  </p>

                  <p className="mt-2 text-sm text-[var(--text-tertiary)]">
                    Completed annotations appear here automatically while the job streams.
                  </p>
                </div>
              </div>
            )}
          </ImagePane>}
        </main>
      </div>

      {/* PROMPT SIDEBAR */}
      {dialog === "prompt" && (
        <aside className="flex w-[min(340px,36vw)] shrink-0 flex-col overflow-hidden border-l border-[var(--border-color)] bg-[var(--bg-surface)] shadow-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-[var(--border-color)] px-3 py-3">
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[var(--accent-500)]">
                Annotation setup
              </p>

              <h2 className="mt-1 text-base font-bold">
                Prompts & ROI
              </h2>
            </div>

            <button
              onClick={() =>
                setDialog(null)
              }
              className="rounded-xl p-2 text-[var(--text-tertiary)] hover:bg-[var(--bg-hover)]"
              aria-label="Close prompts"
            >
              <X size={18} />
            </button>
          </div>

          {promptContent}

          <div className="shrink-0 border-t border-[var(--border-color)] bg-[var(--bg-main)] p-3">
            <button
              onClick={() => startAnnotation(calibrationReady
                ? { modelOverride: semiModel, confidenceOverride: confidenceThreshold }
                : {})}
              disabled={
                running ||
                !prompts.length ||
                !images.length
              }
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[var(--accent-500)] px-4 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-indigo-500/15 transition hover:bg-[var(--accent-600)] disabled:cursor-not-allowed disabled:opacity-45"
            >
              <Play size={17} />

              {running
                ? runKind === "pre-annotation" ? "Running pre-annotation…" : "Streaming annotation…"
                : calibrationReady ? "Apply Recovery" : "Start Smart Annotation"}
            </button>

            {!images.length && (
              <p className="mt-2 text-center text-[10px] text-[var(--text-tertiary)]">
                Link an image folder or video first.
              </p>
            )}

            {!!images.length &&
              !prompts.length && (
                <p className="mt-2 text-center text-[10px] text-[var(--text-tertiary)]">
                  Add at least one prompt to start.
                </p>
              )}
          </div>
        </aside>
      )}
    </div>
  );
}
