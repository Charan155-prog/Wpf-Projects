"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Bot, ChevronDown, Database, Play, Settings2, Terminal,
} from "lucide-react";
import { MOCK_DATASETS } from "@/data/mockDatasetData";
import FormSelect from "@/components/ui/FormSelect";
import TrainingTerminal from "@/components/training/TrainingTerminal";

// ─── Scope options ────────────────────────────────────────────────────────────

const SCOPE_OPTIONS = [
  { value: "all",         label: "All"         },
  { value: "unannotated", label: "Unannotated" },
  { value: "train",       label: "Train"       },
  { value: "val",         label: "Val"         },
  { value: "test",        label: "Test"        },
];

// ─── Slider ───────────────────────────────────────────────────────────────────

function Slider({ label, value, onChange, min = 0, max = 1, step = 0.05, disabled }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-[var(--text-secondary)]">{label}</span>
        <span className="text-sm font-bold tabular-nums text-[var(--text-primary)] bg-[var(--bg-main)] border border-[var(--border-color)] px-2 py-0.5 rounded-lg min-w-[48px] text-center">
          {value.toFixed(2)}
        </span>
      </div>
      <div className="relative h-2 rounded-full bg-[var(--bg-main)] border border-[var(--border-color)]">
        <div
          className="absolute left-0 top-0 h-full rounded-full bg-[var(--accent-500)]"
          style={{ width: `${pct}%` }}
        />
        <input
          type="range" min={min} max={max} step={step} value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          disabled={disabled}
          className="absolute inset-0 w-full opacity-0 cursor-pointer h-full disabled:cursor-not-allowed"
        />
        <div
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[var(--accent-500)] border-2 border-[var(--bg-surface)] shadow-md pointer-events-none"
          style={{ left: `${pct}%` }}
        />
      </div>
    </div>
  );
}

// ─── Config card wrapper ──────────────────────────────────────────────────────

function ConfigCard({ icon: Icon, title, accent = false, children }) {
  return (
    <div className="flex flex-col bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-xl overflow-hidden flex-1 min-w-0">
      <div className={`flex items-center gap-2.5 px-4 py-3 border-b border-[var(--border-color)] ${accent ? "bg-[var(--accent-500)]/5" : "bg-[var(--bg-main)]"}`}>
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${accent ? "bg-[var(--accent-500)]/15" : "bg-[var(--bg-hover)]"}`}>
          <Icon size={14} className={accent ? "text-[var(--accent-500)]" : "text-[var(--text-tertiary)]"} />
        </div>
        <span className="text-sm font-bold text-[var(--text-primary)]">{title}</span>
      </div>
      <div className="flex flex-col gap-4 p-4 flex-1">{children}</div>
    </div>
  );
}

// ─── Stat mini pills ──────────────────────────────────────────────────────────

function StatRow({ label, value, color }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-[var(--border-color)]/50 last:border-0">
      <span className="text-xs text-[var(--text-tertiary)]">{label}</span>
      <span className={`text-xs font-bold tabular-nums ${color ?? "text-[var(--text-primary)]"}`}>{value}</span>
    </div>
  );
}

// ─── AnnotationSetup ──────────────────────────────────────────────────────────

export default function AnnotationSetup({ config, updateConfig, activeProject, phase, onStart, logs = [] }) {
  const [terminalOpen, setTerminalOpen] = useState(false);

  const projectDatasets = activeProject
    ? MOCK_DATASETS.filter((d) => d.projectId === activeProject.id)
    : [];

  const selectedDataset = projectDatasets.find((d) => d.id === config.datasetId) ?? null;

  const estimatedCount = (() => {
    if (!selectedDataset) return null;
    switch (config.imageScope) {
      case "train":       return selectedDataset.split.train;
      case "val":         return selectedDataset.split.val;
      case "test":        return selectedDataset.split.test;
      case "unannotated": return Math.floor(selectedDataset.totalImages * 0.38);
      default:            return selectedDataset.totalImages;
    }
  })();

  const canStart  = !!config.datasetId;
  const isRunning = phase === "running";

  return (
    <div className="flex flex-col h-full">

      {/* ── Scrollable body ── */}
      <div className="flex-1 min-h-0 overflow-auto p-5 flex flex-col gap-4">

        {/* Three config cards */}
        <div className="flex flex-col lg:flex-row gap-4">

          {/* Card 1 — Source */}
          <ConfigCard icon={Database} title="Source" accent>
            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Dataset</span>
                <FormSelect
                  value={config.datasetId}
                  onChange={(v) => updateConfig("datasetId", v)}
                  options={projectDatasets.map((d) => ({ value: d.id, label: d.name }))}
                  placeholder="Select dataset"
                  disabled={isRunning}
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Image Scope</span>
                <div className="flex flex-wrap gap-1.5">
                  {SCOPE_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => !isRunning && updateConfig("imageScope", opt.value)}
                      disabled={isRunning}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                        config.imageScope === opt.value
                          ? "bg-[var(--accent-500)] text-white border-[var(--accent-500)] shadow-sm"
                          : "border-[var(--border-color)] text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:border-[var(--border-hover)]"
                      } disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dataset stats */}
              <AnimatePresence>
                {selectedDataset && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="flex flex-col p-3 rounded-xl bg-[var(--bg-main)] border border-[var(--border-color)] mt-1">
                      <StatRow label="Total Images"  value={selectedDataset.totalImages.toLocaleString()} />
                      <StatRow label="To Annotate"   value={estimatedCount?.toLocaleString() ?? "—"} color="text-[var(--accent-500)]" />
                      <StatRow label="Classes"       value={selectedDataset.classes.length} />
                      <StatRow label="Status"        value={selectedDataset.status} color={selectedDataset.status === "Ready" ? "text-emerald-500" : "text-amber-500"} />
                      <div className="flex flex-wrap gap-1 mt-2 pt-2 border-t border-[var(--border-color)]/50">
                        {selectedDataset.classes.map((c) => (
                          <span key={c.name} className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-[var(--bg-hover)] text-[10px] text-[var(--text-tertiary)]">
                            <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: c.color }} />
                            {c.alias}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </ConfigCard>

          {/* Card 2 — Model */}
          <ConfigCard icon={Bot} title="Model">
            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Trained Model</span>
                <FormSelect
                  value={config.modelId}
                  onChange={(v) => updateConfig("modelId", v)}
                  options={[]}
                  placeholder="Select trained model"
                  disabled={isRunning}
                />
              </div>

              {/* Model placeholder info */}
              {!config.modelId && (
                <div className="flex flex-col items-center gap-2 py-6 rounded-xl border border-dashed border-[var(--border-color)] text-center">
                  <Bot size={22} className="text-[var(--text-tertiary)]" strokeWidth={1.5} />
                  <div>
                    <p className="text-xs font-medium text-[var(--text-secondary)]">No model selected</p>
                    <p className="text-[10px] text-[var(--text-tertiary)] mt-0.5">Train a model first to use Smart Annotation</p>
                  </div>
                </div>
              )}

              {config.modelId && (
                <div className="flex flex-col p-3 rounded-xl bg-[var(--bg-main)] border border-[var(--border-color)]">
                  <StatRow label="Architecture" value="YOLOv8n" />
                  <StatRow label="mAP50"        value="0.847" color="text-emerald-500" />
                  <StatRow label="Best Epoch"   value="#87" />
                  <StatRow label="Trained On"   value={selectedDataset?.name ?? "—"} />
                </div>
              )}
            </div>
          </ConfigCard>

          {/* Card 3 — Parameters */}
          <ConfigCard icon={Settings2} title="Parameters">
            <div className="flex flex-col gap-5">
              <Slider
                label="Confidence Threshold"
                value={config.confidenceThreshold}
                onChange={(v) => updateConfig("confidenceThreshold", v)}
                disabled={isRunning}
              />
              <Slider
                label="IoU Threshold"
                value={config.iouThreshold}
                onChange={(v) => updateConfig("iouThreshold", v)}
                disabled={isRunning}
              />

              <div className="h-px bg-[var(--border-color)]" />

              <button
                type="button"
                onClick={() => !isRunning && updateConfig("overwrite", !config.overwrite)}
                disabled={isRunning}
                className={`flex items-center gap-3 p-3 rounded-xl border-2 transition-all text-left ${
                  config.overwrite
                    ? "border-amber-500/50 bg-amber-500/5"
                    : "border-[var(--border-color)] bg-[var(--bg-main)] hover:border-[var(--border-hover)]"
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                <div className={`w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                  config.overwrite ? "bg-amber-500 border-amber-500" : "border-[var(--border-color)]"
                }`}>
                  {config.overwrite && (
                    <svg viewBox="0 0 10 8" className="w-2.5 h-2.5">
                      <path d="M1 4l3 3 5-6" stroke="white" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <div>
                  <p className="text-xs font-semibold text-[var(--text-primary)]">Overwrite existing annotations</p>
                  <p className="text-[10px] text-[var(--text-tertiary)] mt-0.5">Replace any manually created labels</p>
                </div>
              </button>
            </div>
          </ConfigCard>
        </div>

        {/* Terminal section */}
        <div className="flex flex-col rounded-xl border border-[var(--border-color)] overflow-hidden bg-[var(--bg-hover)]">
          <button
            onClick={() => setTerminalOpen((v) => !v)}
            className="flex items-center gap-2.5 px-4 py-3 bg-[var(--bg-main)] hover:bg-[var(--bg-hover)] transition-colors text-left"
          >
            <Terminal size={14} className="text-[var(--text-tertiary)]" />
            <span className="text-sm font-semibold text-[var(--text-secondary)]">Terminal</span>
            {logs.length > 0 && (
              <span className="ml-1 text-[10px] font-bold bg-[var(--accent-500)]/15 text-[var(--accent-500)] px-2 py-0.5 rounded-full">
                {logs.length} lines
              </span>
            )}
            <motion.div
              animate={{ rotate: terminalOpen ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="ml-auto"
            >
              <ChevronDown size={14} className="text-[var(--text-tertiary)]" />
            </motion.div>
          </button>

          <AnimatePresence initial={false}>
            {terminalOpen && (
              <motion.div
                initial={{ height: 0 }} animate={{ height: 220 }}
                exit={{ height: 0 }}
                transition={{ duration: 0.22, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <div className="h-[220px]">
                  <TrainingTerminal logs={logs.length > 0 ? logs : [{ type: "info", text: "No previous runs. Start Smart Annotation to see logs here." }]} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ── Footer action ── */}
      <div className="flex-shrink-0 flex items-center justify-between gap-4 px-5 py-4 border-t border-[var(--border-color)] bg-[var(--bg-main)]">
        <div className="text-xs text-[var(--text-tertiary)]">
          {canStart
            ? estimatedCount != null
              ? <><span className="font-bold text-[var(--text-primary)]">{estimatedCount.toLocaleString()}</span> images will be processed</>
              : "Ready to run"
            : "Select a dataset to continue"}
        </div>
        <motion.button
          onClick={canStart && !isRunning ? onStart : undefined}
          disabled={!canStart || isRunning}
          whileHover={canStart && !isRunning ? { scale: 1.02 } : {}}
          whileTap={canStart && !isRunning ? { scale: 0.97 } : {}}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-bold transition-all shadow-sm ${
            canStart && !isRunning
              ? "bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white"
              : "bg-[var(--bg-hover)] text-[var(--text-tertiary)] cursor-not-allowed border border-[var(--border-color)]"
          }`}
        >
          <Play size={14} />
          Run Smart Annotation
        </motion.button>
      </div>
    </div>
  );
}
