"use client";

import { useState } from "react";
import {
  Menu,
  Moon,
  Sun,
} from "lucide-react";
import { motion } from "framer-motion";
import {
  useMediaQuery,
} from "@/hooks/useMediaQuery";
import { APP_CONFIG } from "@/config/constants";
import { useTheme } from "@/context/ThemeContext";
import Sidebar from "./Sidebar";

export default function AppLayout({
  children,
}) {
  const [mobileOpen, setMobileOpen] =
    useState(false);

  const isMobile =
    useMediaQuery(
      "(max-width: 768px)"
    );

  const { theme, toggleTheme } =
    useTheme();

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{
        backgroundColor:
          "var(--bg-main)",
        color:
          "var(--text-primary)",
      }}
    >
      <Sidebar
        isMobile={isMobile}
        mobileOpen={mobileOpen}
        setMobileOpen={
          setMobileOpen
        }
      />

      <motion.div
        initial={false}
        animate={{
          marginLeft: isMobile
            ? 0
            : 108,
        }}
        className="flex h-screen min-w-0 flex-1 flex-col overflow-hidden"
      >

        {isMobile && (
          <div
            className="flex h-14 shrink-0 items-center border-b px-3"
            style={{
              backgroundColor:
                "var(--bg-sidebar)",
              borderColor:
                "var(--border-color)",
            }}
          >
            <button
              onClick={() =>
                setMobileOpen(true)
              }
              className="rounded-lg p-2 text-[var(--text-primary)] hover:bg-[var(--bg-hover)]"
              aria-label="Open navigation"
            >
              <Menu size={21} />
            </button>

            <div className="ml-2">
              <p className="text-xs font-extrabold">
                {APP_CONFIG.brandTitle}
              </p>

              <p className="text-[10px] text-[var(--text-tertiary)]">
                {APP_CONFIG.brandSubtitle}
              </p>
            </div>
          </div>
        )}

        <main className="min-h-0 flex-1 overflow-y-auto p-1.5 md:p-2">
          {children}
        </main>
      </motion.div>

      {/* Theme switcher */}
      <button
        onClick={toggleTheme}
        title={
          theme === "dark"
            ? "Switch to light theme"
            : "Switch to dark theme"
        }
        aria-label={
          theme === "dark"
            ? "Switch to light theme"
            : "Switch to dark theme"
        }
        className="fixed bottom-4 right-4 z-[120] flex h-11 w-11 items-center justify-center rounded-full border border-[var(--border-color)] bg-[var(--bg-surface)] text-[var(--text-secondary)] shadow-lg transition hover:border-[var(--border-hover)] hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)]"
      >
        {theme === "dark" ? (
          <Sun size={18} />
        ) : (
          <Moon size={18} />
        )}
      </button>
    </div>
  );
}
