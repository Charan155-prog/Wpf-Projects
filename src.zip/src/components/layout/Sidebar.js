"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronDown,
  Check,
  FolderKanban,
  Search,
  X,
} from "lucide-react";
import { useActiveProject } from "@/context/ProjectContext";
import { useTheme } from "@/context/ThemeContext";
import { APP_CONFIG, NAVIGATION } from "@/config/constants";

const statusDot = {
  Active: "bg-emerald-500",
  Inactive: "bg-slate-400",
};

function getInitials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0])
    .join("")
    .toUpperCase();
}

function ProjectDropdownContent({
  search,
  setSearch,
  filtered,
  activeProject,
  onSelect,
  onClear,
}) {
  return (
    <>
      <div className="border-b border-[var(--border-color)] p-2.5">
        <div className="relative">
          <Search
            size={14}
            className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)]"
          />

          <input
            value={search}
            onChange={(event) =>
              setSearch(event.target.value)
            }
            placeholder="Search projects…"
            autoFocus
            className="w-full rounded-lg border border-[var(--border-color)] bg-[var(--bg-hover)] py-2 pl-8 pr-3 text-xs text-[var(--text-primary)] outline-none focus:border-[var(--accent-500)]"
          />
        </div>
      </div>

      <div className="max-h-[min(24rem,calc(100vh-15rem))] overflow-y-auto py-1">
        {filtered.length === 0 ? (
          <p className="px-4 py-4 text-center text-xs text-[var(--text-tertiary)]">
            No projects found.
          </p>
        ) : (
          filtered.map((project) => {
            const active =
              activeProject?.id === project.id;

            return (
              <button
                key={project.id}
                onClick={() =>
                  onSelect(project)
                }
                className={`flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors ${
                  active
                    ? "bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
                    : "text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
                }`}
              >
                <span
                  className={`h-2 w-2 shrink-0 rounded-full ${
                    statusDot[project.status] ??
                    "bg-slate-400"
                  }`}
                />

                <span
                  className={`min-w-0 flex-1 whitespace-normal break-words text-sm leading-5 ${
                    active
                      ? "font-bold"
                      : "font-medium"
                  }`}
                >
                  {project.name}
                </span>

                {active && (
                  <Check
                    size={14}
                    className="shrink-0"
                  />
                )}
              </button>
            );
          })
        )}
      </div>

      {activeProject && (
        <div className="border-t border-[var(--border-color)] p-1.5">
          <button
            onClick={onClear}
            className="w-full rounded-lg px-3 py-2 text-left text-xs font-semibold text-[var(--text-tertiary)] hover:bg-red-500/5 hover:text-red-500"
          >
            Clear selection
          </button>
        </div>
      )}
    </>
  );
}

function ProjectSwitcher() {
  const {
    activeProject,
    setActiveProject,
    projects,
  } = useActiveProject();

  const [open, setOpen] =
    useState(false);

  const [search, setSearch] =
    useState("");

  const ref = useRef(null);

  const filtered =
    projects.filter((project) =>
      project.name
        .toLowerCase()
        .includes(
          search.toLowerCase()
        )
    );

  useEffect(() => {
    if (!open) return undefined;

    const handleOutside = (event) => {
      if (
        !ref.current?.contains(
          event.target
        )
      ) {
        setOpen(false);
        setSearch("");
      }
    };

    document.addEventListener(
      "mousedown",
      handleOutside
    );

    return () =>
      document.removeEventListener(
        "mousedown",
        handleOutside
      );
  }, [open]);

  const select = (project) => {
    setActiveProject(project);
    setOpen(false);
    setSearch("");
  };

  return (
    <div
      ref={ref}
      className="relative px-2.5 py-2.5"
    >
      <button
        onClick={() =>
          setOpen((value) => !value)
        }
        title={activeProject?.name ?? "Select a project"}
        aria-label={`Active project: ${activeProject?.name ?? "none"}. Select a project.`}
        className={`w-full rounded-xl border px-2 py-2.5 text-center transition-colors ${
          open
            ? "border-[var(--accent-500)] bg-[var(--accent-500)]/8"
            : "border-[var(--border-color)] bg-[var(--bg-hover)] hover:border-[var(--border-hover)]"
        }`}
      >
        <div className="flex flex-col items-center gap-1.5">

          <div className="relative mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[var(--accent-500)]/12 text-[var(--accent-500)]">

            {activeProject ? (
              <span className="text-[10px] font-extrabold">
                {getInitials(
                  activeProject.name
                )}
              </span>
            ) : (
              <FolderKanban size={15} />
            )}

            {activeProject && (
              <span
                className={`absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full border-2 border-[var(--bg-sidebar)] ${
                  statusDot[
                    activeProject.status
                  ] ??
                  "bg-slate-400"
                }`}
              />
            )}
          </div>

          <div className="w-full min-w-0">

            <p className="truncate text-[8px] font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
              Project
            </p>

            <p className="mt-0.5 truncate text-[10px] font-extrabold leading-4 text-[var(--text-primary)]">
              {activeProject?.name ??
                "Select a project"}
            </p>
          </div>

          <ChevronDown
            size={14}
            className={`shrink-0 text-[var(--text-tertiary)] transition-transform ${
              open ? "rotate-180" : ""
            }`}
          />
        </div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{
              opacity: 0,
              y: -5,
              scale: 0.98,
            }}
            animate={{
              opacity: 1,
              y: 0,
              scale: 1,
            }}
            exit={{
              opacity: 0,
              y: -5,
              scale: 0.98,
            }}
            className="absolute left-[calc(100%-0.25rem)] top-2.5 z-[100] w-72 max-w-[calc(100vw-7.5rem)] overflow-hidden rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface)] shadow-2xl"
          >
            <ProjectDropdownContent
              search={search}
              setSearch={setSearch}
              filtered={filtered}
              activeProject={
                activeProject
              }
              onSelect={select}
              onClear={() => {
                setActiveProject(null);
                setOpen(false);
                setSearch("");
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function Sidebar({
  isMobile,
  mobileOpen,
  setMobileOpen,
}) {
  const pathname =
    usePathname();

  const { theme } =
    useTheme();

  return (
    <>
      <AnimatePresence>
        {isMobile &&
          mobileOpen && (
            <motion.div
              initial={{
                opacity: 0,
              }}
              animate={{
                opacity: 1,
              }}
              exit={{
                opacity: 0,
              }}
              onClick={() =>
                setMobileOpen(false)
              }
              className="fixed inset-0 z-40 bg-slate-950/45 backdrop-blur-sm"
            />
          )}
      </AnimatePresence>

      <motion.aside
        initial={false}
        animate={{
          x: isMobile
            ? mobileOpen
              ? 0
              : "-100%"
            : 0,
        }}
        transition={{
          duration: 0.22,
          ease: "easeOut",
        }}
        className="fixed left-0 top-0 z-50 flex h-screen w-[108px] flex-col border-r shadow-xl md:shadow-none"
        style={{
          backgroundColor:
            "var(--bg-sidebar)",
          borderColor:
            "var(--border-color)",
        }}
      >
        {isMobile && (
          <button
            onClick={() =>
              setMobileOpen(false)
            }
            className="absolute right-2 top-2 z-10 rounded-lg p-1.5 text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
            aria-label="Close navigation"
          >
            <X size={17} />
          </button>
        )}

        {/* Logo */}
        <div className="flex shrink-0 flex-col items-center border-b border-[var(--border-color)] px-2 py-3">
          <Image
            src="/images/Only-E-Icon.png"
            alt={APP_CONFIG.companyName}
            width={38}
            height={38}
            className={`object-contain ${
              theme === "dark"
                ? "brightness-0 invert"
                : ""
            }`}
            priority
          />

          <p className="mt-1 text-[10px] font-extrabold tracking-wide text-[var(--text-primary)]">
            SAIL
          </p>

          <p className="text-[8px] font-semibold text-[var(--text-tertiary)]">
            AI Workspace
          </p>
        </div>

        {/* Project */}
        <div className="shrink-0 border-b border-[var(--border-color)]">
          <ProjectSwitcher />
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-2 py-3">

          <div className="flex flex-col gap-1.5">

            {NAVIGATION.map(
              (group, groupIndex) => (
                <div
                  key={group.category}
                  className="flex flex-col gap-1.5"
                >

                  {groupIndex > 0 && (
                    <div className="mx-2 my-2 border-t border-[var(--border-color)]" />
                  )}

                  {group.items.map(
                    (item) => {
                      const Icon =
                        item.icon;

                      const active =
                        pathname ===
                        item.href;

                      return (
                        <Link
                          key={
                            item.name
                          }
                          href={
                            item.href
                          }
                          onClick={() =>
                            isMobile &&
                            setMobileOpen(
                              false
                            )
                          }
                        >
                          <motion.div
                            whileTap={{
                              scale: 0.96,
                            }}
                            className={`relative flex min-h-[66px] flex-col items-center justify-center gap-1 rounded-xl px-1.5 py-2 text-center transition-colors ${
                              active
                                ? "bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
                                : "text-[var(--text-secondary)] hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)]"
                            }`}
                          >

                            {active && (
                              <span className="absolute left-0 top-1/2 h-8 w-1 -translate-y-1/2 rounded-r-full bg-[var(--accent-500)]" />
                            )}

                            <Icon
                              size={22}
                              strokeWidth={
                                active
                                  ? 2.4
                                  : 2
                              }
                            />

                            <span className="max-w-full break-words text-[10px] font-extrabold leading-3.5">
                              {item.name}
                            </span>

                          </motion.div>
                        </Link>
                      );
                    }
                  )}
                </div>
              )
            )}
          </div>
        </nav>
      </motion.aside>
    </>
  );
}
