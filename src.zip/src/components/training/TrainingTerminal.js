"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronsDown } from "lucide-react";

const LOG_COLORS = {
  info:    "text-[var(--text-secondary)]",
  metric:  "text-[var(--accent-500)]",
  success: "text-emerald-500",
  warning: "text-amber-500",
  error:   "text-red-500",
};

export default function TrainingTerminal({ logs }) {
  const bottomRef    = useRef(null);
  const containerRef = useRef(null);
  const [autoScroll, setAutoScroll] = useState(true);

  useEffect(() => {
    if (autoScroll && bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs, autoScroll]);

  function handleScroll() {
    const el = containerRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
    setAutoScroll(atBottom);
  }

  return (
    <div className="flex flex-col h-full bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-[var(--border-color)] bg-[var(--bg-main)] flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-bold text-[var(--text-secondary)]">Training Log</span>
        </div>
        <button
          onClick={() => { setAutoScroll(true); bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }}
          className={`flex items-center gap-1 text-[10px] font-semibold px-2 py-1 rounded-lg transition-colors ${
            autoScroll
              ? "text-[var(--accent-500)] bg-[var(--accent-500)]/10"
              : "text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-main)]"
          }`}
        >
          <ChevronsDown size={12} />
          Auto-scroll
        </button>
      </div>

      {/* Log body */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-3 font-mono text-[11px] leading-5 space-y-0.5"
        style={{ backgroundColor: "var(--bg-main)" }}
      >
        {logs.length === 0 ? (
          <p className="text-[var(--text-tertiary)] text-xs">Waiting for training to start…</p>
        ) : (
          logs.map((log, i) => (
            <p key={i} className={`whitespace-pre-wrap break-all ${LOG_COLORS[log.type] ?? LOG_COLORS.info}`}>
              {log.text}
            </p>
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
