"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ChevronDown, ChevronLeft, ChevronRight, Square, Trash2 } from "lucide-react";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";

export const activeRun = (run) => ["queued", "splitting", "waiting", "training", "testing"].includes(run?.state);

// Small "type a page number and jump" control, dropped in next to the
// Previous/Next buttons wherever there are multiple pages of images.
function PageJump({ page, pages, onJump }) {
  if (pages <= 1) return <span className="text-[var(--text-secondary)]">{page} / {pages}</span>;
  function commit(e) {
    const n = Math.min(pages, Math.max(1, Math.round(Number(e.target.value)) || page));
    if (n !== page) onJump(n);
    e.target.value = n;
  }
  return <span className="flex items-center gap-1 text-[var(--text-secondary)]">
    <input
      key={page}
      type="number"
      min={1}
      max={pages}
      defaultValue={page}
      aria-label="Jump to page"
      onKeyDown={(e) => { if (e.key === "Enter") e.target.blur(); }}
      onBlur={commit}
      className="w-12 rounded border border-[var(--border-color)] bg-[var(--bg-hover)] px-1 py-0.5 text-center text-xs text-[var(--text-primary)]"
    />
    <span>/ {pages}</span>
  </span>;
}

export function useRunDetail(id, refresh) {
  const [run, setRun] = useState(null);
  const [error, setError] = useState("");
  const [cancelling, setCancelling] = useState(false);
  useEffect(() => {
    if (!id) { setRun(null); setError(""); return; }
    let active = true, timer;
    async function poll() {
      try {
        const result = await datasetRequest(`/training/runs/${id}`);
        if (!active) return;
        setRun(result); setError("");
        if (activeRun(result)) timer = setTimeout(poll, 2500);
        else refresh();
      } catch (e) { if (active) { setError(e.message); timer = setTimeout(poll, 5000); } }
    }
    poll();
    return () => { active = false; clearTimeout(timer); };
  }, [id, refresh]);
  async function cancel() {
    if (!window.confirm("Stop this training run? Partial checkpoints remain on disk, but will not be registered as a completed model.")) return;
    setCancelling(true);
    try { await datasetRequest(`/training/runs/${id}/cancel`, { method: "POST" }); }
    catch (e) { setError(e.message); setCancelling(false); }
  }
  return { run, error, cancelling, cancel };
}

export function RunPicker({ runs, selectedId, onSelect }) {
  if (!runs.length) return <p className="text-xs text-[var(--text-secondary)]">No training runs for this project yet.</p>;
  return <select aria-label="Training run history" className="w-full bg-[var(--bg-hover)] p-2 rounded-lg text-xs border border-[var(--border-color)]" value={selectedId || ""} onChange={(e) => onSelect(e.target.value)}>
    {runs.map((r) => <option key={r.id} value={r.id}>{r.name} · {r.mode} · {r.state} · {new Date(r.createdAt).toLocaleString()} · {r.id.slice(0, 8)}</option>)}
  </select>;
}

export function RunStatusStrip({ run, cancelling, onCancel }) {
  if (!run) return null;
  return <div className="mx-3 mt-2 flex flex-shrink-0 flex-wrap items-center gap-3 rounded-lg border border-[var(--border-color)] bg-[var(--bg-hover)]/40 px-3 py-2 text-xs">
    <span className="font-semibold capitalize">{run.state === "training" ? run.progress?.phase || run.state : run.state}</span>
    {run.progress?.epoch > 0 && <span className="text-[var(--text-secondary)]">Epoch {run.progress.epoch}/{run.progress.epochs} · {run.progress.processedImages ?? 0}/{run.progress.totalImages || run.splitCounts?.train || 0} images</span>}
    {run.progress?.epoch > 0 && <progress
      className="h-1.5 w-28 rounded-full [&::-moz-progress-bar]:rounded-full [&::-moz-progress-bar]:bg-[var(--accent-500)] [&::-webkit-progress-bar]:rounded-full [&::-webkit-progress-bar]:bg-[var(--bg-hover)] [&::-webkit-progress-value]:rounded-full [&::-webkit-progress-value]:bg-[var(--accent-500)]"
      value={run.progress.processedImages || 0} max={run.progress.totalImages || run.splitCounts?.train || 1}
    />}
    {activeRun(run) && <button onClick={onCancel} disabled={cancelling} className="ml-auto inline-flex items-center gap-1 rounded-md border border-red-500/60 text-red-400 px-2 py-1 text-[11px] font-semibold hover:bg-red-500/10 disabled:opacity-50"><Square size={10} />{cancelling ? "Stopping…" : "Stop"}</button>}
  </div>;
}

export function RunDetailsPanel({ run }) {
  if (!run) return <p className="text-xs text-[var(--text-secondary)]">Select a completed run to see its details.</p>;
  return <div className="space-y-3 text-xs">
    <div className="flex flex-wrap items-center gap-2"><strong className="capitalize text-sm">{run.state}</strong><span className="text-[var(--text-secondary)]">{new Date(run.createdAt).toLocaleString()}{run.updatedAt ? ` → ${new Date(run.updatedAt).toLocaleString()}` : ""}</span></div>
    {run.splitCounts && <p>Train: {run.splitCounts.train} · Validation: {run.splitCounts.val} · Test: {run.splitCounts.test}</p>}
    {run.error && <p role="alert" className="text-red-400">{run.error}</p>}
    {run.warnings?.map((warning) => <p key={warning} className="text-amber-400">{warning}</p>)}
    {run.state === "complete" && <Link className="text-emerald-400 underline block" href={`/models?model=${run.id}`}>Model saved — view model and test metrics →</Link>}
    {run.progress?.metrics && <div className="flex flex-wrap gap-2">{Object.entries(run.progress.metrics).map(([key, value]) => <span key={key} className="bg-[var(--bg-hover)] px-2 py-1 rounded text-[11px]">{key}: {Number(value).toFixed(4)}</span>)}</div>}
  </div>;
}

// Lives on the main Training page (not the "Training Details" side panel) so
// it is visible the moment a run starts, not only once it reaches "complete".
export function TrainingLogPanel({ run }) {
  const [open, setOpen] = useState(true);
  if (!run) return null;
  // Inline flex (not just a Tailwind class) so the "full view" sizing can't
  // be silently dropped, and both this panel and SplitGallery below share
  // whatever space is left the moment either one is opened or collapsed —
  // that's the "sliding" resize between them.
  return <div style={{ flex: open ? "1 1 0%" : "0 0 auto" }} className="mx-3 mt-2 min-h-0 flex flex-col rounded-lg border border-[var(--border-color)] bg-[var(--bg-hover)]/40 text-xs transition-[flex-grow] duration-300 ease-in-out">
    <button type="button" onClick={() => setOpen((value) => !value)} aria-expanded={open} className="flex w-full flex-shrink-0 items-center gap-2 px-3 py-2 text-left hover:bg-[var(--bg-hover)]/60 rounded-lg">
      <ChevronDown size={14} className={`flex-shrink-0 transition-transform ${open ? "" : "-rotate-90"}`} />
      <span className="font-semibold flex-1">Training log &amp; output location</span>
      {activeRun(run) && <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-emerald-400"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />Live</span>}
    </button>
    {open && <div className="flex-1 min-h-0 flex flex-col border-t border-[var(--border-color)]">
      <p className="font-mono text-[11px] break-all px-3 pt-2 text-[var(--text-secondary)]">{run.directory}</p>
      <pre aria-label="Training log" className="mx-3 mb-3 mt-2 p-2 bg-black/40 rounded-lg flex-1 min-h-0 overflow-auto text-[11px] whitespace-pre-wrap">{run.log || "Waiting for the training process…"}</pre>
    </div>}
  </div>;
}

export function useSplitGallery(runId, excluded) {
  const [split, setSplit] = useState("train");
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [expandedIndex, setExpandedIndex] = useState(null);
  // Whole-panel expand/collapse, toggled by double-clicking a Train/Validation/Test tab.
  const [expanded, setExpanded] = useState(true);
  useEffect(() => { setPage(1); setExpandedIndex(null); }, [runId, split]);
  useEffect(() => {
    if (!runId) { setData(null); return; }
    const controller = new AbortController();
    datasetRequest(`/training/runs/${runId}/images?split=${split}&page=${page}&page_size=16`, { signal: controller.signal }).then((r) => { setData(r); setError(""); }).catch((e) => { if (!controller.signal.aborted) setError(e.message); });
    return () => controller.abort();
  }, [runId, split, page]);
  const items = (data?.items || []).filter((item) => !excluded.has(item.name));
  return { split, setSplit, page, setPage, data, error, items, expandedIndex, setExpandedIndex, expanded, setExpanded };
}

// Train/Validation/Test tabs + the image grid, as one panel. Double-clicking
// any tab (or the chevron) expands/collapses the whole panel, sharing
// leftover vertical space with TrainingLogPanel via the same inline-flex
// trick — so collapsing one gives the other the freed-up room immediately.
export function SplitGallery({ runId, gallery, excluded, onToggleExclude }) {
  const { split, setSplit, page, setPage, data, error, items, expandedIndex, setExpandedIndex, expanded, setExpanded } = gallery;
  if (!runId) return <div className="flex-1 min-h-0 flex items-center justify-center p-12 text-center text-sm text-[var(--text-secondary)]">Start a training run to see its Train / Validation / Test images here.</div>;
  const expandedItem = expandedIndex != null ? items[expandedIndex] : null;
  const toggleExpanded = () => setExpanded((value) => !value);
  return <div style={{ flex: expanded ? "1 1 0%" : "0 0 auto" }} className="mx-3 mt-3 min-h-0 flex flex-col rounded-lg border border-[var(--border-color)] bg-[var(--bg-hover)]/40 transition-[flex-grow] duration-300 ease-in-out">
    <div className="flex flex-shrink-0 flex-wrap items-center gap-2 px-3 py-2">
      {["train", "val", "test"].map((s) => <button key={s} onClick={() => setSplit(s)} onDoubleClick={toggleExpanded} title="Double-click to expand or collapse the images" className={`capitalize rounded-lg px-3 py-1.5 text-xs font-semibold ${s === split ? "bg-[var(--accent-500)] text-white" : "bg-[var(--bg-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`}>{s === "val" ? "Validation" : s}</button>)}
      <strong className="ml-auto text-xs text-[var(--text-secondary)]">{data?.total || 0} {split === "val" ? "validation" : split} images{excluded.size ? ` · ${excluded.size} excluded` : ""}</strong>
      {excluded.size > 0 && <button onClick={() => onToggleExclude(null)} className="text-xs underline text-[var(--accent-500)]">Restore all</button>}
      <button type="button" onClick={toggleExpanded} aria-expanded={expanded} aria-label={expanded ? "Collapse images" : "Expand images"} title={expanded ? "Collapse images" : "Expand images"} className="rounded p-1 hover:bg-[var(--bg-hover)]/60"><ChevronDown size={14} className={`transition-transform ${expanded ? "" : "-rotate-90"}`} /></button>
    </div>
    {expanded && <>
      {error && <p role="alert" className="px-3 pt-2 text-xs text-red-400">{error}</p>}
      <div className="flex-1 min-h-0 overflow-auto p-3">
        <div className="grid grid-cols-[repeat(auto-fit,minmax(min(100%,300px),1fr))] items-start gap-3">
        {items.map((item, index) => <div key={item.url} className="group relative min-w-0 rounded-lg bg-black/20 overflow-hidden">
          <button onClick={() => setExpandedIndex(index)} aria-label={`View ${item.name} full size`} className="relative block w-full aspect-video bg-black/40"><img loading="lazy" src={assetUrl(item.url)} alt={item.name} className="absolute inset-0 h-full w-full object-contain" /></button>
          <button onClick={() => onToggleExclude(item.name)} aria-label={`Delete ${item.name}`} title="Exclude from future training" className="absolute top-1.5 right-1.5 rounded bg-black/80 p-1.5 text-red-300 opacity-0 transition-opacity group-hover:opacity-100"><Trash2 size={14} /></button>
          <p className="truncate text-xs p-1.5 text-[var(--text-secondary)]">{item.name}</p>
        </div>)}
        {!items.length && !error && <p className="col-span-full py-8 text-center text-xs text-[var(--text-secondary)]">No images in this split.</p>}
        </div>
      </div>
      <div className="flex flex-shrink-0 justify-center gap-4 border-t border-[var(--border-color)] p-2 text-xs">
        <button disabled={page === 1} onClick={() => setPage(page - 1)} className="font-semibold disabled:opacity-30">Previous</button>
        <PageJump page={page} pages={Math.max(1, Math.ceil((data?.total || 0) / 16))} onJump={setPage} />
        <button disabled={page * 16 >= (data?.total || 0)} onClick={() => setPage(page + 1)} className="font-semibold disabled:opacity-30">Next</button>
      </div>
    </>}
    {expandedItem && <div role="dialog" aria-modal="true" aria-label="Training image" className="fixed inset-0 z-[110] bg-black/95 p-6 sm:p-12 flex items-center justify-center">
      <button onClick={() => setExpandedIndex(null)} aria-label="Close" className="absolute right-4 top-4 sm:right-6 sm:top-6 rounded-lg bg-white/10 px-3 py-1.5 text-sm text-white hover:bg-white/20">Close</button>
      <button onClick={() => onToggleExclude(expandedItem.name)} aria-label={`Delete ${expandedItem.name}`} title="Exclude from future training" className="absolute left-4 top-4 sm:left-6 sm:top-6 rounded-lg bg-red-500/20 p-2 text-red-300 hover:bg-red-500/30"><Trash2 size={16} /></button>
      {expandedIndex > 0 && <button onClick={() => setExpandedIndex(expandedIndex - 1)} aria-label="Previous image" className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-white hover:bg-white/20 sm:left-6"><ChevronLeft size={22} /></button>}
      {expandedIndex < items.length - 1 && <button onClick={() => setExpandedIndex(expandedIndex + 1)} aria-label="Next image" className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-2 text-white hover:bg-white/20 sm:right-6"><ChevronRight size={22} /></button>}
      <img src={assetUrl(expandedItem.url)} alt={expandedItem.name} className="max-h-[85vh] max-w-full object-contain" />
      <p className="absolute bottom-4 text-xs text-white/70 sm:bottom-6">{expandedIndex + 1} / {items.length} · {expandedItem.name}</p>
    </div>}
  </div>;
}