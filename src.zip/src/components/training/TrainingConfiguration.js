"use client";

const control = "w-full rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] px-2.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)]";

export const initialTrainingConfig = { architecture: "YOLOv8n", optimizer: "SGD", epochs: 100, batchSize: 4, imageSize: 720, learningRate: 0.01, pretrained: true, freezeLayers: 10, device: "0", patience: 0, seed: 42, ratios: [70, 20, 10], baseModelId: "" };

export function compatibleModels(dataset, models = []) {
  return models.filter((m) => m.projectName === dataset?.projectName && m.mode === dataset?.mode && JSON.stringify(m.classes) === JSON.stringify(dataset?.classes));
}

function Row({ label, children }) {
  return <label className="block space-y-1"><span className="text-xs text-[var(--text-secondary)]">{label}</span>{children}</label>;
}

export default function TrainingConfiguration({ mode, config, update, dataset, models = [] }) {
  const suffix = dataset?.mode === "segmentation" ? "-seg" : "";
  const compatible = compatibleModels(dataset, models);
  return <div className="space-y-3">
    {mode === "normal" ? <Row label="Architecture"><select className={control} value={config.architecture} onChange={(event) => update("architecture", event.target.value)}>{["YOLOv8n", "YOLOv8s", "YOLOv8m", "YOLOv8l", "YOLOv8x"].map((name) => <option key={name} value={name}>{name}{suffix}</option>)}</select></Row> : <>
      <Row label="Base Model"><select required className={control} value={compatible.some((m) => m.id === config.baseModelId) ? config.baseModelId : ""} onChange={(e) => update("baseModelId", e.target.value)}><option value="">Select compatible trained model</option>{compatible.map((m) => <option key={m.id} value={m.id}>{m.name} · {m.id.slice(0, 8)} · {new Date(m.createdAt).toLocaleString()}</option>)}</select></Row>
      <Row label="Freeze Layers"><input className={control} type="number" min="0" max="50" step="1" value={config.freezeLayers} onChange={(event) => update("freezeLayers", event.target.value)} /></Row>
    </>}
    <Row label="Optimizer"><select className={control} value={config.optimizer} onChange={(event) => update("optimizer", event.target.value)}>{["SGD", "Adam", "AdamW"].map((name) => <option key={name}>{name}</option>)}</select></Row>
    <div className="border-t border-[var(--border-color)]" />
    {[
      ["epochs", "Epochs", 1, 1000, 1], ["batchSize", "Batch Size", 1, 128, 1],
      ["imageSize", "Image Size", 320, 1280, 1], ["learningRate", "Learning Rate", 0.0001, 0.1, 0.0001],
    ].map(([key, label, min, max, step]) => <Row key={key} label={label}><input className={control} type="number" min={min} max={max} step={step} required value={config[key]} onChange={(event) => update(key, event.target.value)} /></Row>)}
    {mode === "normal" && <label className="flex gap-2.5 items-center p-2.5 rounded-lg border border-[var(--accent-500)]/50 bg-[var(--accent-500)]/5 cursor-pointer"><input type="checkbox" checked={config.pretrained} onChange={(event) => update("pretrained", event.target.checked)} className="accent-[var(--accent-500)] h-3.5 w-3.5" /><span><span className="block text-xs font-semibold">Use pretrained weights</span><span className="block text-[11px] text-[var(--text-secondary)] mt-0.5">Start from COCO-pretrained weights</span></span></label>}
    <Row label="Early stopping (0 = off)"><input className={control} type="number" min="0" max="1000" required value={config.patience} onChange={(e) => update("patience", e.target.value)} /></Row>
    <Row label="Split seed"><input className={control} type="number" min="0" max="2147483647" required value={config.seed} onChange={(e) => update("seed", e.target.value)} /></Row>
    <div className="grid grid-cols-3 gap-2">{["Train %", "Validation %", "Test %"].map((label, i) => <label key={label} className="text-[11px] text-[var(--text-secondary)] space-y-1 block">{label}<input aria-label={label} className={control} type="number" required min="1" max="98" value={config.ratios[i]} onChange={(e) => update("ratios", config.ratios.map((r, n) => n === i ? e.target.value : r))} /></label>)}</div>
    <p className="text-[11px] text-[var(--text-secondary)]">Split total: {config.ratios.reduce((s, r) => s + Number(r), 0)} / 100%</p>
  </div>;
}
