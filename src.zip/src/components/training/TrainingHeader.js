"use client";

import { BrainCircuit, Square } from "lucide-react";

export default function TrainingHeader({ phase, activeProject, currentEpoch, totalEpochs, onStop }) {
  const isRunning = phase === "training";

  return (
    <div className="app-page-header flex-shrink-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 surface rounded-xl shadow-sm">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)] flex items-center justify-center flex-shrink-0 border border-[var(--accent-500)]/20">
          <BrainCircuit size={24} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)] leading-tight">Training</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">
            {activeProject
              ? <>Project: <span className="font-semibold text-[var(--accent-500)]">{activeProject.name}</span></>
              : <span className="text-amber-500">No project selected — pick one from the sidebar.</span>}
          </p>
        </div>
      </div>

      {isRunning && (
        <button
          onClick={onStop}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm font-bold transition-colors shadow-sm"
        >
          <Square size={14} fill="white" />
          Stop Training
        </button>
      )}
    </div>
  );
}
