"use client";

import { motion } from "framer-motion";
import { CheckCircle2, RotateCcw, Trophy } from "lucide-react";
import TrainingGraphs from "./TrainingGraphs";

function formatTime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}h ${m % 60}m ${s % 60}s`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

function ResultCard({ label, value, sub, color }) {
  return (
    <div className="flex flex-col gap-1 p-4 rounded-xl bg-[var(--bg-hover)] border border-[var(--border-color)] flex-1 min-w-[110px]">
      <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">{label}</span>
      <span className={`text-2xl font-bold leading-none ${color ?? "text-[var(--text-primary)]"}`}>{value}</span>
      {sub && <span className="text-xs text-[var(--text-tertiary)] mt-0.5">{sub}</span>}
    </div>
  );
}

export default function TrainingComplete({ metrics, bestMetrics, elapsed, totalEpochs, onReset }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="md:flex-1 md:min-h-0 flex flex-col surface rounded-xl [overflow:clip]"
    >
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-4 bg-[var(--bg-main)] border-b border-[var(--border-color)]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
            <CheckCircle2 size={18} className="text-emerald-500" />
          </div>
          <div>
            <p className="text-sm font-bold text-[var(--text-primary)]">Training Complete</p>
            <p className="text-xs text-[var(--text-tertiary)]">Finished {totalEpochs} epochs in {formatTime(elapsed)}</p>
          </div>
        </div>
        <button
          onClick={onReset}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[var(--border-color)] text-sm font-semibold text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
        >
          <RotateCcw size={14} />
          Train Again
        </button>
      </div>

      {/* Scrollable body */}
      <div className="flex-1 min-h-0 overflow-auto p-5 flex flex-col gap-6">

        {/* Best metrics */}
        {bestMetrics && (
          <section className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Trophy size={14} className="text-amber-500" />
              <h2 className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)]">
                Best Results — Epoch {bestMetrics.epoch}
              </h2>
            </div>
            <div className="flex flex-wrap gap-3">
              <ResultCard label="mAP50"      value={bestMetrics.mAP50.toFixed(4)}     color="text-emerald-500" />
              <ResultCard label="Precision"  value={bestMetrics.precision.toFixed(4)}  color="text-amber-500"   />
              <ResultCard label="Recall"     value={bestMetrics.recall.toFixed(4)}     color="text-purple-500"  />
              <ResultCard label="Train Loss" value={bestMetrics.trainLoss.toFixed(4)}  color="text-red-500"     />
              <ResultCard label="Val Loss"   value={bestMetrics.valLoss.toFixed(4)}    color="text-[var(--accent-500)]" />
              <ResultCard label="Best Epoch" value={`#${bestMetrics.epoch}`}           sub={`of ${totalEpochs} total`} />
            </div>
          </section>
        )}

        {/* Full training graphs */}
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Training Curves</h2>
          <TrainingGraphs metrics={metrics} />
        </section>

      </div>
    </motion.div>
  );
}
