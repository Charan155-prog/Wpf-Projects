"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Layers, Play, RefreshCw } from "lucide-react";
import { MOCK_DATASETS } from "@/data/mockDatasetData";
import { ARCHITECTURES, OPTIMIZERS } from "@/hooks/useTraining";
import FormSelect from "@/components/ui/FormSelect";

// ─── compact input styles ─────────────────────────────────────────────────────

const inputCls = "w-full px-2.5 py-1.5 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] text-sm text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all";

// ─── Row — label + control on one line ───────────────────────────────────────

function Row({ label, children }) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-28 text-xs font-medium text-[var(--text-tertiary)] flex-shrink-0">{label}</span>
      <div className="flex-1">{children}</div>
    </div>
  );
}

function Divider() {
  return <div className="border-t border-[var(--border-color)]/60 my-1" />;
}

// ─── TrainingSetup ────────────────────────────────────────────────────────────

export default function TrainingSetup({ mode, setMode, config, updateConfig, activeProject, phase, onStart, onReset }) {
  const projectDatasets = activeProject
    ? MOCK_DATASETS.filter((d) => d.projectId === activeProject.id)
    : [];

  const selectedDataset = projectDatasets.find((d) => d.id === config.datasetId) ?? null;
  const canStart   = !!config.datasetId && (mode === "normal" || !!config.baseModelId);
  const isRunning  = phase === "training";
  const isComplete = phase === "complete";

  return (
    <div className="flex flex-col h-full">

      {/* ── Mode toggle ── */}
      <div className="flex-shrink-0 flex items-center gap-1.5 px-5 py-3 border-b border-[var(--border-color)] bg-[var(--bg-main)]">
        <span className="text-xs text-[var(--text-tertiary)] font-medium mr-1">Mode:</span>
        {[
          { id: "normal",      label: "Normal Training",      Icon: Layers    },
          { id: "incremental", label: "Incremental Learning", Icon: RefreshCw },
        ].map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => !isRunning && setMode(id)}
            disabled={isRunning}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              mode === id
                ? "bg-[var(--accent-500)] text-white shadow-sm"
                : "text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)]"
            } ${isRunning ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            <Icon size={13} />
            {label}
          </button>
        ))}
      </div>

      {/* ── Body ── */}
      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-[260px_minmax(0,1fr)] divide-y lg:divide-y-0 lg:divide-x divide-[var(--border-color)] overflow-auto">

        {/* Left — Dataset */}
        <div className="flex flex-col gap-4 p-5">
          <p className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)]">Dataset</p>

          <FormSelect
            value={config.datasetId}
            onChange={(val) => updateConfig("datasetId", val)}
            options={projectDatasets.map((d) => ({ value: d.id, label: d.name }))}
            placeholder="Select dataset"
            disabled={isRunning}
          />

          {/* Selected dataset info */}
          <AnimatePresence>
            {selectedDataset && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                className="flex flex-col gap-3"
              >
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-[var(--text-primary)] truncate">{selectedDataset.name}</p>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    selectedDataset.status === "Ready"
                      ? "text-emerald-500 bg-emerald-500/10 border-emerald-500/20"
                      : "text-amber-500 bg-amber-500/10 border-amber-500/20"
                  }`}>{selectedDataset.status}</span>
                </div>

                {/* Stats row */}
                <div className="flex items-center gap-3 text-xs text-[var(--text-tertiary)]">
                  <span><span className="font-bold text-[var(--text-primary)]">{selectedDataset.totalImages.toLocaleString()}</span> images</span>
                  <span className="text-[var(--border-color)]">·</span>
                  <span><span className="font-bold text-[var(--text-primary)]">{selectedDataset.classes.length}</span> classes</span>
                </div>

                {/* Split bar */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex h-1.5 rounded-full overflow-hidden gap-px">
                    <div className="bg-[var(--accent-500)]" style={{ width: `${(selectedDataset.split.train / selectedDataset.totalImages) * 100}%` }} />
                    <div className="bg-amber-500"           style={{ width: `${(selectedDataset.split.val   / selectedDataset.totalImages) * 100}%` }} />
                    <div className="bg-emerald-500"         style={{ width: `${(selectedDataset.split.test  / selectedDataset.totalImages) * 100}%` }} />
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-[var(--text-tertiary)]">
                    {[["Train", "bg-[var(--accent-500)]", selectedDataset.split.train],
                      ["Val",   "bg-amber-500",           selectedDataset.split.val  ],
                      ["Test",  "bg-emerald-500",         selectedDataset.split.test ]].map(([l, c, v]) => (
                      <span key={l} className="flex items-center gap-1">
                        <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${c}`} />
                        {l} {v}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Class pills */}
                <div className="flex flex-wrap gap-1">
                  {selectedDataset.classes.map((c) => (
                    <span key={c.name} className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-[var(--bg-hover)] border border-[var(--border-color)] text-[10px] text-[var(--text-tertiary)]">
                      <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: c.color }} />
                      {c.alias}
                    </span>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right — Configuration */}
        <div className="flex flex-col justify-between p-5 gap-5">
          <div className="flex flex-col gap-2.5">
            <p className="text-xs font-bold uppercase tracking-widest text-[var(--text-tertiary)] mb-1">
              {mode === "normal" ? "Model Configuration" : "Incremental Configuration"}
            </p>

            {/* Model params */}
            {mode === "normal" ? (
              <Row label="Architecture">
                <FormSelect
                  value={config.architecture}
                  onChange={(v) => updateConfig("architecture", v)}
                  options={ARCHITECTURES.map((a) => ({ value: a, label: a }))}
                  disabled={isRunning}
                />
              </Row>
            ) : (
              <>
                <Row label="Base Model">
                  <FormSelect
                    value={config.baseModelId}
                    onChange={(v) => updateConfig("baseModelId", v)}
                    options={[]}
                    placeholder="Select trained model"
                    disabled={isRunning}
                  />
                </Row>
                <Row label="Freeze Layers">
                  <input type="number" min={0} max={50} value={config.freezeLayers} onChange={(e) => updateConfig("freezeLayers", Number(e.target.value))} className={inputCls} disabled={isRunning} />
                </Row>
              </>
            )}

            <Row label="Optimizer">
              <FormSelect
                value={config.optimizer}
                onChange={(v) => updateConfig("optimizer", v)}
                options={OPTIMIZERS.map((o) => ({ value: o, label: o }))}
                disabled={isRunning}
              />
            </Row>

            <Divider />

            <Row label="Epochs">
              <input type="number" min={1} max={1000} value={config.epochs} onChange={(e) => updateConfig("epochs", Number(e.target.value))} className={inputCls} disabled={isRunning} />
            </Row>
            <Row label="Batch Size">
              <input type="number" min={1} max={128} value={config.batchSize} onChange={(e) => updateConfig("batchSize", Number(e.target.value))} className={inputCls} disabled={isRunning} />
            </Row>
            <Row label="Image Size">
              <input type="number" min={320} max={1280} step={32} value={config.imageSize} onChange={(e) => updateConfig("imageSize", Number(e.target.value))} className={inputCls} disabled={isRunning} />
            </Row>
            <Row label="Learning Rate">
              <input type="number" min={0.0001} max={0.1} step={0.0001} value={config.learningRate} onChange={(e) => updateConfig("learningRate", Number(e.target.value))} className={inputCls} disabled={isRunning} />
            </Row>

            {mode === "normal" && (
              <>
                <Divider />
                <button
                  type="button"
                  onClick={() => !isRunning && updateConfig("pretrained", !config.pretrained)}
                  disabled={isRunning}
                  className={`flex items-center gap-3 p-3 rounded-lg border transition-all text-left w-full ${
                    config.pretrained
                      ? "border-[var(--accent-500)]/50 bg-[var(--accent-500)]/5"
                      : "border-[var(--border-color)] bg-[var(--bg-hover)] hover:border-[var(--border-hover)]"
                  } ${isRunning ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  <div className={`w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                    config.pretrained ? "bg-[var(--accent-500)] border-[var(--accent-500)]" : "border-[var(--border-color)]"
                  }`}>
                    {config.pretrained && (
                      <svg viewBox="0 0 10 8" className="w-2.5 h-2.5"><path d="M1 4l3 3 5-6" stroke="white" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    )}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-[var(--text-primary)]">Use pretrained weights</p>
                    <p className="text-[10px] text-[var(--text-tertiary)] mt-0.5">Start from COCO-pretrained for faster convergence</p>
                  </div>
                </button>
              </>
            )}
          </div>

          {/* ── Action ── */}
          <div className="pt-4 border-t border-[var(--border-color)]">
            {isComplete ? (
              <motion.button onClick={onReset} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-bold bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white transition-all shadow-sm">
                <Play size={14} /> Train Again
              </motion.button>
            ) : isRunning ? (
              <div className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold bg-[var(--bg-hover)] text-[var(--text-tertiary)] border border-[var(--border-color)] cursor-not-allowed">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Training in progress…
              </div>
            ) : (
              <motion.button onClick={onStart} disabled={!canStart}
                whileHover={canStart ? { scale: 1.01 } : {}} whileTap={canStart ? { scale: 0.98 } : {}}
                className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-bold transition-all shadow-sm ${
                  canStart
                    ? "bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white"
                    : "bg-[var(--bg-hover)] text-[var(--text-tertiary)] cursor-not-allowed border border-[var(--border-color)]"
                }`}>
                <Play size={14} />
                {canStart ? "Start Training" : "Select a dataset to continue"}
              </motion.button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
