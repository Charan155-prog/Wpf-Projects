"use client";

import { motion } from "framer-motion";
import TrainingGraphs from "./TrainingGraphs";
import TrainingTerminal from "./TrainingTerminal";
import TrainingComplete from "./TrainingComplete";

function formatTime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}h ${m % 60}m`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

function LivePill({ label, value, color }) {
  return (
    <div className="flex flex-col items-center px-3 py-2 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] min-w-[80px]">
      <span className={`text-sm font-bold leading-none tabular-nums ${color}`}>{value}</span>
      <span className="text-[10px] font-semibold uppercase tracking-widest text-[var(--text-tertiary)] mt-1">{label}</span>
    </div>
  );
}

export default function TrainingMonitor({
  phase, currentEpoch, totalEpochs,
  metrics, logs, elapsed, bestMetrics,
  onReset,
}) {
  if (phase === "complete") {
    return (
      <TrainingComplete
        metrics={metrics}
        bestMetrics={bestMetrics}
        elapsed={elapsed}
        totalEpochs={totalEpochs}
        onReset={onReset}
      />
    );
  }

  const pct  = totalEpochs > 0 ? (currentEpoch / totalEpochs) * 100 : 0;
  const last = (arr) => arr.length ? arr[arr.length - 1] : null;
  const fmt  = (v) => v != null ? v.toFixed(4) : "—";

  return (
    <div className="flex flex-col h-full">
      {/* Progress strip */}
      <div className="flex-shrink-0 px-5 py-4 border-b border-[var(--border-color)] bg-[var(--bg-main)] flex flex-col gap-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-[var(--text-primary)]">
              Epoch{" "}
              <span className="text-[var(--accent-500)]">{currentEpoch}</span>
              {" "}/{" "}{totalEpochs}
            </span>
            {phase === "training" && (
              <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-500">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Running
              </span>
            )}
            {phase === "stopped" && (
              <span className="text-xs font-semibold text-amber-500">Stopped</span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-[var(--text-tertiary)]">{formatTime(elapsed)}</span>
            <span className="text-xs font-semibold text-[var(--text-tertiary)]">{pct.toFixed(1)}%</span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="h-2 rounded-full bg-[var(--bg-hover)] overflow-hidden border border-[var(--border-color)]">
          <motion.div
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-[var(--accent-500)] to-[var(--accent-600)]"
          />
        </div>

        {/* Live metrics */}
        <div className="flex items-center gap-2 flex-wrap">
          <LivePill label="Train Loss" value={fmt(last(metrics.trainLoss))} color="text-red-500" />
          <LivePill label="Val Loss"   value={fmt(last(metrics.valLoss))}   color="text-[var(--accent-500)]" />
          <LivePill label="mAP50"      value={fmt(last(metrics.mAP50))}     color="text-emerald-500" />
          <LivePill label="Precision"  value={fmt(last(metrics.precision))} color="text-amber-500" />
          <LivePill label="Recall"     value={fmt(last(metrics.recall))}    color="text-purple-500" />
        </div>
      </div>

      {/* Graphs + Terminal */}
      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] divide-y lg:divide-y-0 lg:divide-x divide-[var(--border-color)]">
        <div className="overflow-auto p-4">
          <TrainingGraphs metrics={metrics} />
        </div>
        <div className="flex flex-col min-h-[260px] lg:min-h-0 p-4">
          <TrainingTerminal logs={logs} />
        </div>
      </div>
    </div>
  );
}
