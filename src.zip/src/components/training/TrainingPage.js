"use client";
import { useCallback, useEffect, useMemo, useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { FolderOpen, Layers, Play, RefreshCw, ShieldCheck, Trash2 } from "lucide-react";
import { useDatasets } from "@/hooks/useDatasets";
import { datasetRequest } from "@/utils/datasetApi";
import TrainingConfiguration, { initialTrainingConfig, compatibleModels } from "./TrainingConfiguration";
import { activeRun, useRunDetail, useSplitGallery, RunPicker, RunStatusStrip, RunDetailsPanel, TrainingLogPanel, SplitGallery } from "./TrainingRuns";
import { useActiveProject } from "@/context/ProjectContext";
import SidePanel from "@/components/ui/SidePanel";

const subscribe = () => () => {};
const serverSelection = () => "";
const serverAutoSelect = () => true;
const browserSelection = () => new URLSearchParams(window.location.search).get("dataset") || sessionStorage.getItem("sail-training-dataset") || "";
// Which run's gallery/log are on screen, and whether we should keep following
// the newest run automatically. Persisted (per project) so navigating away and
// back — or an explicit Reset — restores exactly what was showing before,
// instead of always snapping back to the most recently created run.
const runKey = (projectId) => `sail-training-run:${projectId || "none"}`;
const autoKey = (projectId) => `sail-training-auto:${projectId || "none"}`;
const browserRunSelection = (projectId) => () => sessionStorage.getItem(runKey(projectId)) || "";
const browserAutoSelect = (projectId) => () => sessionStorage.getItem(autoKey(projectId)) !== "0";


export default function TrainingPage() {
  const { activeProject } = useActiveProject();
  const [resetVersion, setResetVersion] = useState(0);
  function resetTraining() {
    sessionStorage.removeItem("sail-training-dataset");
    sessionStorage.removeItem(runKey(activeProject?.id));
    // Explicitly "0" (not removed) so this blank state is distinguishable
    // from "never chosen anything yet" and survives navigating away and back.
    sessionStorage.setItem(autoKey(activeProject?.id), "0");
    const url = new URL(window.location.href);
    url.searchParams.delete("dataset");
    window.history.replaceState(window.history.state, "", `${url.pathname}${url.search}${url.hash}`);
    // Remount only this page: discard local previews, forms and in-flight UI
    // responses without cancelling jobs or changing persisted training data.
    setResetVersion((version) => version + 1);
  }
  return <ProjectTraining key={`${activeProject?.id || "none"}:${resetVersion}`} project={activeProject} freshStart={resetVersion > 0} onReset={resetTraining} />;
}

function ProjectTraining({ project, freshStart, onReset }) {
  const { datasets: allDatasets, loading, error, refresh } = useDatasets(true);
  const matches = (item) => !!project && [project.name, project.name.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._]+|[._]+$/g, "")].includes(item.projectName);
  const datasets = allDatasets.filter(matches);
  const [runs, setRuns] = useState([]);
  const [models, setModels] = useState([]);
  const [starting, setStarting] = useState(false);
  const [jobError, setJobError] = useState("");
  const refreshJobs = useCallback(async () => {
    try {
      const [jobs, saved] = await Promise.all([datasetRequest("/training/runs"), datasetRequest("/models")]);
      setRuns(jobs.items); setModels(saved.items); setJobError("");
    } catch (e) { setJobError(e.message); }
  }, []);
  useEffect(() => { const timer = setTimeout(refreshJobs, 0); const interval = setInterval(refreshJobs, 5000); return () => { clearTimeout(timer); clearInterval(interval); }; }, [refreshJobs]);
  const projectRuns = useMemo(() => runs.filter(matches).slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [runs, project]);
  const projectId = project?.id;
  const getRunSnapshot = useCallback(browserRunSelection(projectId), [projectId]);
  const getAutoSnapshot = useCallback(browserAutoSelect(projectId), [projectId]);
  const restoredRunId = useSyncExternalStore(subscribe, getRunSnapshot, serverSelection);
  const restoredAutoSelect = useSyncExternalStore(subscribe, getAutoSnapshot, serverAutoSelect);
  const [runOverride, setRunOverride] = useState(freshStart ? "" : null);
  const [autoOverride, setAutoOverride] = useState(freshStart ? false : null);
  const selectedRunId = runOverride ?? restoredRunId;
  const autoSelectRun = autoOverride ?? restoredAutoSelect;
  // Every explicit run choice (or "go back to auto-following the newest run")
  // goes through here so it survives navigating away and coming back.
  function applyRunSelection(id, auto) {
    setRunOverride(id); setAutoOverride(auto);
    sessionStorage.setItem(runKey(projectId), id || "");
    sessionStorage.setItem(autoKey(projectId), auto ? "1" : "0");
  }
  const defaultRunId = projectRuns.find(activeRun)?.id || projectRuns[0]?.id || "";
  const currentRunId = selectedRunId && projectRuns.some((r) => r.id === selectedRunId) ? selectedRunId : autoSelectRun ? defaultRunId : "";
  const { run, cancelling, cancel } = useRunDetail(currentRunId, refreshJobs);
  const restoredSelection = useSyncExternalStore(subscribe, browserSelection, serverSelection);
  const [selection, setSelectedId] = useState(freshStart ? "" : null);
  const selectedId = selection ?? restoredSelection;
  const [verified, setVerified] = useState(false);
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState("");
  const selected = datasets.find((item) => item.id === selectedId);
  async function verify() {
    setBusy(true); setProblem(""); setVerified(false);
    try { await datasetRequest(`/training/datasets/${selectedId}/verify`, { method: "POST" }); setVerified(true); }
    catch (error) { setProblem(error.message); }
    finally { setBusy(false); }
  }
  function select(id) {
    setSelectedId(id); setVerified(false); setProblem("");
    sessionStorage.setItem("sail-training-dataset", id);
    // Switching datasets must hide the previous dataset's epoch status,
    // gallery and training log right away. If this dataset already has a
    // run (trained before), restore that run's details immediately; only a
    // never-trained dataset stays blank until Start Training is clicked.
    applyRunSelection(projectRuns.find((item) => item.datasetId === id)?.id || "", false);
  }
  async function removeSelectedDataset() {
    if (!selected || !window.confirm(`Permanently delete validated dataset “${selected.name}”, its raw images and labels? This cannot be undone.`)) return;
    try {
      await datasetRequest(`/training/datasets/${selected.id}`, { method: "DELETE" });
      sessionStorage.removeItem("sail-training-dataset"); setSelectedId(""); applyRunSelection("", true); setPanel(null); await refresh();
    } catch (e) { setProblem(e.message); }
  }

  const [trainingMode, setTrainingMode] = useState("normal");
  const [config, setConfig] = useState(initialTrainingConfig);
  const update = (key, value) => setConfig((previous) => ({ ...previous, [key]: value }));
  const compatible = compatibleModels(selected, models);

  // Excluded images are persisted on the backend per validated dataset (see
  // /training/datasets/{id}/excluded), keyed to whichever dataset the run
  // currently shown in the gallery was trained from, so a Delete here still
  // applies the next time that same dataset is used to start a new run.
  const [excludedImages, setExcludedImages] = useState(new Set());
  const [excludedDatasetId, setExcludedDatasetId] = useState("");
  const [excludeError, setExcludeError] = useState("");
  useEffect(() => {
    const datasetId = run?.datasetId || "";
    setExcludedDatasetId(datasetId);
    if (!datasetId) { setExcludedImages(new Set()); return; }
    let active = true;
    datasetRequest(`/training/datasets/${datasetId}/excluded`).then((r) => { if (active) setExcludedImages(new Set(r.excludedImages)); }).catch((e) => { if (active) setExcludeError(e.message); });
    return () => { active = false; };
  }, [run?.datasetId]);
  async function toggleExclude(name) {
    if (!excludedDatasetId) return;
    const next = name === null ? new Set() : new Set(excludedImages);
    if (name !== null) { if (next.has(name)) next.delete(name); else next.add(name); }
    setExcludedImages(next); setExcludeError("");
    try { await datasetRequest(`/training/datasets/${excludedDatasetId}/excluded`, { method: "PUT", body: JSON.stringify({ excludedImages: Array.from(next) }) }); }
    catch (e) { setExcludeError(e.message); }
  }

  const gallery = useSplitGallery(run?.id || "", excludedImages);
  const [panel, setPanel] = useState(null);

  const startDisabled = !selected || starting || projectRuns.some((item) => activeRun(item) && item.datasetId === selected?.id);
  async function handleStart() {
    if (startDisabled) return;
    if (Number(config.imageSize) !== 720 && Number(config.imageSize) % 32) { window.alert("Use image size 720 from the training script, or a multiple of 32."); return; }
    if (config.ratios.reduce((s, r) => s + Number(r), 0) !== 100) { window.alert("Split percentages must total 100."); return; }
    if (trainingMode === "incremental" && !compatible.some((m) => m.id === config.baseModelId)) { window.alert("Select a compatible base model for incremental learning."); return; }
    if (!window.confirm("Start training on the backend test PC? This creates a new split and model run without changing your validated dataset.")) return;
    setStarting(true); setJobError("");
    try {
      // Always pull the freshest exclusion list for the dataset about to be
      // trained, since it can differ from whatever run's gallery is on screen.
      const persisted = await datasetRequest(`/training/datasets/${selected.id}/excluded`).catch(() => ({ excludedImages: [] }));
      const numeric = Object.fromEntries(["epochs", "batchSize", "imageSize", "learningRate", "freezeLayers", "patience", "seed"].map((key) => [key, Number(config[key])]));
      await datasetRequest("/training/runs", { method: "POST", body: JSON.stringify({ ...config, ...numeric, mode: trainingMode, datasetId: selected.id, ratios: config.ratios.map(Number), excludedImages: persisted.excludedImages }) });
      await refreshJobs(); applyRunSelection("", true);
    } catch (e) { setJobError(e.message); }
    finally { setStarting(false); }
  }

  return <section aria-label="Training" className="surface rounded-xl h-full min-h-0 flex flex-col overflow-hidden">
    <div className="flex-shrink-0 grid grid-cols-[1fr_auto_1fr] items-center gap-3 border-b border-[var(--border-color)] px-4 py-3">
      <div className="flex items-baseline gap-2 min-w-0">
        <h1 className="text-base font-bold">Training</h1>
        {project && <span className="truncate text-xs font-semibold text-[var(--text-secondary)]">{project.name}</span>}
      </div>
      <div className="flex items-center gap-2 justify-self-center">
        {[{ id: "normal", label: "Normal Training", Icon: Layers }, { id: "incremental", label: "Incremental Learning", Icon: RefreshCw }].map(({ id, label, Icon }) =>
          <button key={id} type="button" aria-pressed={trainingMode === id} onClick={() => setTrainingMode(id)} className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${trainingMode === id ? "bg-[var(--accent-500)] text-white shadow-sm" : "bg-[var(--bg-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`}><Icon size={13} />{label}</button>)}
      </div>
      <div className="flex items-center gap-2 justify-self-end">
        <button onClick={onReset} disabled={loading} aria-label="Reset training selections" title="Reset selections and configuration" className="rounded-lg p-2 hover:bg-[var(--bg-hover)]"><RefreshCw className={loading ? "animate-spin" : ""} size={16} /></button>
      </div>
    </div>

    <div className="flex flex-1 min-h-0 flex-col md:flex-row">
    <div className="flex flex-1 min-h-0 min-w-0 flex-col">
    <div className="flex flex-shrink-0 flex-wrap items-center gap-2 px-3 pt-3">
      <button onClick={() => setPanel(panel === "dataset" ? null : "dataset")} aria-expanded={panel === "dataset"} title={selected ? selected.name : "No dataset selected"} className="rounded-lg border border-[var(--border-color)] bg-[var(--bg-hover)] px-3 py-1.5 text-xs font-semibold hover:bg-[var(--bg-hover)]/70">Dataset</button>
      <button onClick={() => setPanel(panel === "config" ? null : "config")} aria-expanded={panel === "config"} className="rounded-lg border border-[var(--border-color)] bg-[var(--bg-hover)] px-3 py-1.5 text-xs font-semibold hover:bg-[var(--bg-hover)]/70">Model Configuration</button>
      <button onClick={handleStart} disabled={startDisabled} className="inline-flex items-center gap-1.5 rounded-lg bg-[var(--accent-500)] px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-40"><Play size={13} />{starting ? "Starting…" : projectRuns.some((item) => activeRun(item) && item.datasetId === selected?.id) ? "Training active" : "Start Training"}</button>
      <button onClick={() => setPanel(panel === "details" ? null : "details")} aria-expanded={panel === "details"} disabled={!run || run.state !== "complete"} className="rounded-lg border border-[var(--border-color)] px-3 py-1.5 text-xs font-semibold hover:bg-[var(--bg-hover)] disabled:opacity-40">Training Details</button>
    </div>

    <SplitGallery runId={run?.id || ""} gallery={gallery} excluded={excludedImages} onToggleExclude={toggleExclude} />
    <RunStatusStrip run={run} cancelling={cancelling} onCancel={cancel} />
    <TrainingLogPanel run={run} />
    {excludeError && <p role="alert" className="flex-shrink-0 px-3 pt-2 text-xs text-red-400">{excludeError}</p>}

    {(error || jobError || !project || (!loading && !error && !datasets.length)) && <div className="flex-shrink-0 space-y-2 px-3 pt-2 text-sm">
      {error && <p role="alert" className="text-red-400">{error}</p>}
      {jobError && <p role="alert" className="text-red-400">{jobError}</p>}
      {!project && <p>Select a project to view its validated datasets.</p>}
      {!loading && !error && !datasets.length && <div className="rounded-xl border border-dashed border-[var(--border-color)] p-8 text-center"><FolderOpen className="mx-auto mb-3" /><p>No validated datasets yet.</p><Link href="/datasets" className="mt-3 inline-block text-[var(--accent-500)] underline">Review and validate images in Datasets →</Link></div>}
    </div>}
    </div>

    <SidePanel open={panel === "dataset"} onClose={() => setPanel(null)} title="Dataset" subtitle={project ? project.name : undefined}>
      <div className="space-y-3">
        <select aria-label="Select dataset" value={selected ? selectedId : ""} disabled={loading || !!error} onChange={(e) => select(e.target.value)} className="block w-full rounded-lg border border-[var(--border-color)] bg-[var(--bg-hover)] p-2.5 text-xs"><option value="">Select dataset</option>{datasets.map((item) => <option key={item.id} value={item.id}>{item.name} — {item.projectName} — {item.mode} — Run {item.runNumber} — {item.imageCount} images — {new Date(item.createdAt).toLocaleString()}</option>)}</select>
        {selected && <div className="space-y-2.5 text-xs">
          <div className="flex items-start gap-2"><p className="font-semibold break-words text-sm flex-1">{selected.name}</p><button onClick={removeSelectedDataset} aria-label={`Delete ${selected.name}`} title="Permanently delete validated dataset" className="rounded p-1 text-red-400 hover:bg-red-500/10"><Trash2 size={15} /></button></div>
          <p className="text-emerald-400">Validated · <span className="capitalize">{selected.mode}</span></p>
          <p>{selected.imageCount} image pairs · {selected.classes.length} classes</p>
          <p className="text-[var(--text-secondary)]">{selected.labelFormat}</p>
          <div className="flex flex-wrap gap-1">{selected.classes.map((name, id) => <span key={id} className="rounded bg-[var(--bg-hover)] px-2 py-1 text-[11px]">{id}: {name}</span>)}</div>
          <dl className="space-y-2 pt-1"><div><dt className="text-[var(--text-tertiary)]">Raw images</dt><dd className="font-mono break-all mt-0.5 text-[11px]">{selected.imagesDirectory}</dd></div><div><dt className="text-[var(--text-tertiary)]">Labels</dt><dd className="font-mono break-all mt-0.5 text-[11px]">{selected.labelsDirectory}</dd></div></dl>
        </div>}
      </div>
    </SidePanel>

    <SidePanel open={panel === "config"} onClose={() => setPanel(null)} title="Model Configuration" subtitle={trainingMode === "normal" ? "Normal training" : "Incremental learning"}>
      <TrainingConfiguration mode={trainingMode} config={config} update={update} dataset={selected} models={models} />
    </SidePanel>

    <SidePanel open={panel === "details"} onClose={() => setPanel(null)} title="Training Details" subtitle={run?.name}>
      <div className="space-y-4">
        <RunPicker runs={projectRuns} selectedId={currentRunId} onSelect={(id) => applyRunSelection(id, false)} />
        <RunDetailsPanel run={run} />
        {selected && <div className="space-y-2 border-t border-[var(--border-color)] pt-3 text-xs">
          <p className="font-semibold text-sm">{selected.name}</p>
          <p>{selected.imageCount} raw images + label pairs · {selected.classes.length} classes</p>
          <p className="text-[var(--text-secondary)]">{selected.labelFormat}</p>
          <div className="flex items-center gap-2 pt-1"><button onClick={verify} disabled={busy} className="inline-flex items-center gap-1.5 rounded-lg bg-[var(--accent-500)] px-3 py-1.5 text-xs text-white disabled:opacity-40"><ShieldCheck size={13} />{busy ? "Checking…" : "Verify training files"}</button></div>
          {verified && <p role="status" className="text-emerald-400">All image/label checksums match the validated snapshot.</p>}
          {problem && <p role="alert" className="text-red-400">{problem}</p>}
        </div>}
      </div>
    </SidePanel>
    </div>
  </section>;
}