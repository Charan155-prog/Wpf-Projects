"use client";

import { useRef, useState } from "react";

// ─── Single line chart with hover crosshair + tooltip ────────────────────────

function LineChart({ series }) {
  const svgRef  = useRef(null);
  const [hover, setHover] = useState(null);

  const W   = 400;
  const H   = 160;
  const PAD = { t: 14, r: 14, b: 28, l: 42 };
  const cW  = W - PAD.l - PAD.r;
  const cH  = H - PAD.t - PAD.b;

  const allVals = series.flatMap((s) => s.data).filter(Number.isFinite);
  const hasData = allVals.length >= 2;

  const minY   = hasData ? Math.max(0, Math.min(...allVals) * 0.9)  : 0;
  const maxY   = hasData ? Math.max(...allVals) * 1.1                : 1;
  const maxIdx = Math.max(...series.map((s) => s.data.length - 1), 1);

  const toX = (i) => PAD.l + (maxIdx > 0 ? i / maxIdx : 0) * cW;
  const toY = (v) => PAD.t + cH - ((v - minY) / (maxY - minY || 1)) * cH;

  const path = (data) =>
    data.length < 2 ? "" :
    data.map((v, i) => `${i === 0 ? "M" : "L"}${toX(i).toFixed(1)},${toY(v).toFixed(1)}`).join(" ");

  const area = (data) => {
    if (data.length < 2) return "";
    const base = (PAD.t + cH).toFixed(1);
    return `${path(data)} L${toX(data.length - 1).toFixed(1)},${base} L${toX(0).toFixed(1)},${base} Z`;
  };

  const gradId = useRef(`grad_${Math.random().toString(36).slice(2, 8)}`).current;

  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((t) => {
    const v = minY + (maxY - minY) * t;
    return { y: toY(v), v };
  });

  function handleMouseMove(e) {
    if (!svgRef.current || !hasData) return;
    const pt   = svgRef.current.createSVGPoint();
    pt.x = e.clientX; pt.y = e.clientY;
    const svgP = pt.matrixTransform(svgRef.current.getScreenCTM().inverse());
    const idx  = Math.max(0, Math.min(Math.round(((svgP.x - PAD.l) / cW) * maxIdx), maxIdx));
    setHover({ idx, x: toX(idx) });
  }

  return (
    <div className="relative w-full" style={{ height: H }}>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${W} ${H}`}
        className="w-full h-full"
        preserveAspectRatio="none"
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setHover(null)}
      >
        <defs>
          {series.map((s, i) => (
            <linearGradient key={i} id={`${gradId}_${i}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%"   stopColor={s.color} stopOpacity="0.25" />
              <stop offset="100%" stopColor={s.color} stopOpacity="0.02" />
            </linearGradient>
          ))}
        </defs>

        {/* Grid lines */}
        {yTicks.map((t, i) => (
          <g key={i}>
            <line x1={PAD.l} y1={t.y} x2={W - PAD.r} y2={t.y}
              stroke="var(--border-color)" strokeWidth="0.8" strokeDasharray="3 3" />
            <text x={PAD.l - 5} y={t.y + 3.5} textAnchor="end" fontSize="8.5" fill="var(--text-tertiary)">
              {t.v < 1 ? t.v.toFixed(2) : t.v.toFixed(1)}
            </text>
          </g>
        ))}

        {/* Bottom axis */}
        <line x1={PAD.l} y1={PAD.t + cH} x2={W - PAD.r} y2={PAD.t + cH}
          stroke="var(--border-color)" strokeWidth="1" />

        {!hasData ? (
          /* Empty skeleton */
          <>
            {[0.55, 0.72, 0.48, 0.88, 0.65, 0.79, 0.6].map((h, i) => (
              <rect key={i}
                x={PAD.l + (i / 6) * cW + 4} y={PAD.t + cH * (1 - h)}
                width={(cW / 7) - 6} height={cH * h}
                rx="3" fill="var(--border-color)" fillOpacity="0.4"
              />
            ))}
            <text x={W / 2} y={H / 2 + 3} textAnchor="middle" fontSize="11" fill="var(--text-tertiary)">
              Waiting for data…
            </text>
          </>
        ) : (
          <>
            {/* Area fills */}
            {series.map((s, i) => (
              <path key={`a${i}`} d={area(s.data)} fill={`url(#${gradId}_${i})`} />
            ))}

            {/* Lines */}
            {series.map((s, i) => (
              <path key={`l${i}`} d={path(s.data)}
                stroke={s.color} strokeWidth="2" fill="none"
                strokeLinecap="round" strokeLinejoin="round"
              />
            ))}

            {/* Hover crosshair */}
            {hover && (
              <>
                <line
                  x1={hover.x} y1={PAD.t}
                  x2={hover.x} y2={PAD.t + cH}
                  stroke="var(--text-tertiary)" strokeWidth="1"
                  strokeDasharray="4 3" strokeOpacity="0.7"
                />
                {series.map((s, i) => s.data[hover.idx] != null && (
                  <circle key={i}
                    cx={hover.x} cy={toY(s.data[hover.idx])}
                    r="4.5" fill={s.color}
                    stroke="var(--bg-surface)" strokeWidth="2"
                  />
                ))}
              </>
            )}

            {/* Latest value dots (no hover) */}
            {!hover && series.map((s, i) => s.data.length > 0 && (
              <circle key={i}
                cx={toX(s.data.length - 1)} cy={toY(s.data[s.data.length - 1])}
                r="3.5" fill={s.color}
                stroke="var(--bg-surface)" strokeWidth="2"
              />
            ))}
          </>
        )}

        <text x={W / 2} y={H - 3} textAnchor="middle" fontSize="9" fill="var(--text-tertiary)">Epoch</text>
      </svg>

      {/* Hover tooltip */}
      {hover && hasData && (
        <div className="absolute top-2 right-2 pointer-events-none z-20 bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-xl shadow-2xl p-3 min-w-[130px]">
          <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)] mb-2">
            Epoch {hover.idx + 1}
          </p>
          {series.map((s, i) => s.data[hover.idx] != null && (
            <div key={i} className="flex items-center gap-2 text-[11px] py-0.5">
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }} />
              <span className="text-[var(--text-secondary)] flex-1">{s.label}</span>
              <span className="font-bold tabular-nums" style={{ color: s.color }}>
                {s.data[hover.idx].toFixed(4)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Chart card ───────────────────────────────────────────────────────────────

function ChartCard({ title, series, topColor }) {
  const latest = (s) => s.data.length > 0 ? s.data[s.data.length - 1] : null;

  return (
    <div
      className="flex flex-col bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-xl overflow-hidden"
      style={{ borderTop: `3px solid ${topColor}` }}
    >
      <div className="flex items-center justify-between px-4 py-2.5 bg-[var(--bg-main)] border-b border-[var(--border-color)]">
        <span className="text-xs font-bold text-[var(--text-secondary)]">{title}</span>
        <div className="flex items-center gap-3">
          {series.map((s) => (
            <span key={s.label} className="flex items-center gap-1.5 text-[10px] font-semibold">
              <span className="w-5 h-[2px] rounded-full" style={{ backgroundColor: s.color }} />
              <span style={{ color: s.color }}>{s.label}</span>
              {latest(s) != null && (
                <span className="tabular-nums font-bold" style={{ color: s.color }}>
                  {latest(s).toFixed(3)}
                </span>
              )}
            </span>
          ))}
        </div>
      </div>
      <div className="p-3">
        <LineChart series={series} />
      </div>
    </div>
  );
}

// ─── TrainingGraphs ───────────────────────────────────────────────────────────

export default function TrainingGraphs({ metrics }) {
  const { trainLoss, valLoss, mAP50, precision, recall } = metrics;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <ChartCard
        title="Loss"
        topColor="#ef4444"
        series={[
          { label: "Train", color: "#ef4444", data: trainLoss },
          { label: "Val",   color: "#6366f1", data: valLoss   },
        ]}
      />
      <ChartCard
        title="mAP50"
        topColor="#10b981"
        series={[{ label: "mAP50", color: "#10b981", data: mAP50 }]}
      />
      <ChartCard
        title="Precision"
        topColor="#f59e0b"
        series={[{ label: "Precision", color: "#f59e0b", data: precision }]}
      />
      <ChartCard
        title="Recall"
        topColor="#8b5cf6"
        series={[{ label: "Recall", color: "#8b5cf6", data: recall }]}
      />
    </div>
  );
}
