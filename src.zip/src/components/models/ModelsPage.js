"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Archive, BarChart3, Boxes, Check, ChevronDown, ChevronRight,
  Download, GitBranch, Layers, Package, Play, Rocket, Scale,
  Search, Server, SlidersHorizontal, Trash2, X, Zap,
  CheckSquare, Square as SquareIcon, ArrowLeftRight,
} from "lucide-react";
import { MOCK_MODELS } from "@/data/mockModelData";

// ─── Constants ────────────────────────────────────────────────────────────────

const ARCH_STYLE = {
  YOLOv8n: { bg: "bg-slate-500/10",  text: "text-slate-400",  ring: "ring-slate-500/20" },
  YOLOv8s: { bg: "bg-blue-500/10",   text: "text-blue-400",   ring: "ring-blue-500/20" },
  YOLOv8m: { bg: "bg-violet-500/10", text: "text-violet-400", ring: "ring-violet-500/20" },
  YOLOv8l: { bg: "bg-orange-500/10", text: "text-orange-400", ring: "ring-orange-500/20" },
  YOLOv8x: { bg: "bg-red-500/10",    text: "text-red-400",    ring: "ring-red-500/20" },
};

const STATUS_CFG = {
  ready:    { label: "Ready",    dot: "bg-emerald-500", text: "text-emerald-400" },
  training: { label: "Training", dot: "bg-amber-500 animate-pulse", text: "text-amber-400" },
  failed:   { label: "Failed",   dot: "bg-red-500",     text: "text-red-400" },
  archived: { label: "Archived", dot: "bg-slate-500",   text: "text-slate-400" },
};

const EXPORT_FORMATS = [
  { id: "pt",        label: "PyTorch",    ext: ".pt",    desc: "Native training format", color: "#ef4444" },
  { id: "onnx",      label: "ONNX",       ext: ".onnx",  desc: "Cross-platform inference", color: "#3b82f6" },
  { id: "tensorrt",  label: "TensorRT",   ext: ".engine",desc: "NVIDIA GPU optimized", color: "#10b981" },
  { id: "coreml",    label: "CoreML",     ext: ".mlmodel",desc: "Apple device deployment", color: "#8b5cf6" },
  { id: "tflite",    label: "TFLite",     ext: ".tflite",desc: "Mobile & edge devices", color: "#f59e0b" },
];

function mapColor(v) {
  if (v >= 0.9)  return "text-emerald-400";
  if (v >= 0.75) return "text-amber-400";
  return "text-red-400";
}
function mapBg(v) {
  if (v >= 0.9)  return "bg-emerald-500";
  if (v >= 0.75) return "bg-amber-500";
  return "bg-red-500";
}

// ─── Sparkline ────────────────────────────────────────────────────────────────

function Sparkline({ data, color = "#10b981", w = 72, h = 28 }) {
  if (!data?.length) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) =>
    `${((i / (data.length - 1)) * w).toFixed(1)},${(h - ((v - min) / range) * (h - 2) - 1).toFixed(1)}`
  ).join(" ");
  const fill = `0,${h} ${pts} ${w},${h}`;
  return (
    <svg width={w} height={h} className="overflow-visible flex-shrink-0">
      <defs>
        <linearGradient id={`spk_${color.replace("#","")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={fill} fill={`url(#spk_${color.replace("#","")})`} />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ─── Mini metric bar ──────────────────────────────────────────────────────────

function MetricBar({ value, color }) {
  return (
    <div className="flex-1 h-1 rounded-full bg-[var(--bg-hover)] overflow-hidden">
      <motion.div
        initial={{ width: 0 }} animate={{ width: `${value * 100}%` }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`h-full rounded-full ${color}`}
      />
    </div>
  );
}

// ─── Panel mini-chart (two lines) ────────────────────────────────────────────

function MiniLineChart({ lines, height = 80, gradId }) {
  const W = 400; const H = height;
  const allVals = lines.flatMap((l) => l.data);
  const min = Math.min(...allVals);
  const max = Math.max(...allVals);
  const range = max - min || 1;
  const pts = (data) => data.map((v, i) =>
    `${((i / (data.length - 1)) * W).toFixed(1)},${(H - ((v - min) / range) * (H - 4) - 2).toFixed(1)}`
  ).join(" ");

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none"
      className="w-full rounded-lg overflow-hidden" style={{ height }}>
      <defs>
        {lines.map((l, i) => (
          <linearGradient key={i} id={`${gradId}_${i}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={l.color} stopOpacity="0.2" />
            <stop offset="100%" stopColor={l.color} stopOpacity="0" />
          </linearGradient>
        ))}
      </defs>
      {lines.map((l, i) => (
        <g key={i}>
          <polygon
            points={`0,${H} ${pts(l.data)} ${W},${H}`}
            fill={`url(#${gradId}_${i})`}
          />
          <polyline points={pts(l.data)} fill="none"
            stroke={l.color} strokeWidth="1.8"
            strokeLinecap="round" strokeLinejoin="round" />
        </g>
      ))}
    </svg>
  );
}

// ─── Model card ───────────────────────────────────────────────────────────────

function ModelCard({ model, isSelected, onSelect, compareMode, isChecked, onCheck }) {
  const arch    = ARCH_STYLE[model.architecture] ?? ARCH_STYLE.YOLOv8s;
  const status  = STATUS_CFG[model.status] ?? STATUS_CFG.ready;
  const mColor  = mapColor(model.metrics.mAP50);
  const mBg     = mapBg(model.metrics.mAP50);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.25 }}
      onClick={() => !compareMode && onSelect(model)}
      className={`relative flex flex-col gap-3 p-4 rounded-xl border cursor-pointer
        transition-all duration-200 group
        ${isSelected
          ? "border-[var(--accent-500)]/60 bg-[var(--accent-500)]/5 shadow-[0_0_0_1px_var(--accent-500)/30]"
          : "border-[var(--border-color)] bg-[var(--bg-surface)] hover:border-[var(--border-hover)] hover:bg-[var(--bg-hover)]"}
        ${model.isDeployed ? "border-l-2 border-l-[var(--accent-500)]" : ""}
        ${model.status === "archived" ? "opacity-60" : ""}
      `}
    >
      {/* Compare checkbox */}
      {compareMode && (
        <button
          onClick={(e) => { e.stopPropagation(); onCheck(model.id); }}
          className="absolute top-3 right-3 z-10"
        >
          {isChecked
            ? <CheckSquare size={18} className="text-[var(--accent-500)]" />
            : <SquareIcon size={18} className="text-[var(--text-tertiary)]" />}
        </button>
      )}

      {/* Top row */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ring-1 ${arch.bg} ${arch.text} ${arch.ring}`}>
            {model.architecture}
          </span>
          {model.config.baseModel && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-semibold text-[var(--text-tertiary)] bg-[var(--bg-hover)] border border-[var(--border-color)]">
              <GitBranch size={9} /> incremental
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5 flex-shrink-0">
          <span className={`w-1.5 h-1.5 rounded-full ${status.dot}`} />
          <span className={`text-[10px] font-semibold ${status.text}`}>{status.label}</span>
        </div>
      </div>

      {/* Name + version */}
      <div>
        <div className="flex items-baseline gap-2">
          <span className="text-sm font-bold text-[var(--text-primary)]">{model.name}</span>
          <span className="text-xs font-mono text-[var(--text-tertiary)]">v{model.version}</span>
        </div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span className="text-xs text-[var(--text-tertiary)] truncate">{model.projectName}</span>
          {model.isDeployed && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-[var(--accent-500)]/10 text-[var(--accent-500)] border border-[var(--accent-500)]/20">
              <Rocket size={8} /> Deployed
            </span>
          )}
        </div>
      </div>

      {/* mAP50 + sparkline */}
      <div className="flex items-end justify-between">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)] mb-0.5">mAP50</div>
          <div className={`text-2xl font-black tabular-nums leading-none ${mColor}`}>
            {(model.metrics.mAP50 * 100).toFixed(1)}
            <span className="text-sm font-bold opacity-60">%</span>
          </div>
        </div>
        <Sparkline data={model.mAP50History} color={model.metrics.mAP50 >= 0.9 ? "#10b981" : model.metrics.mAP50 >= 0.75 ? "#f59e0b" : "#ef4444"} />
      </div>

      {/* Metric bars */}
      <div className="flex flex-col gap-1.5">
        {[
          { label: "Prec", value: model.metrics.precision },
          { label: "Rec",  value: model.metrics.recall },
        ].map(({ label, value }) => (
          <div key={label} className="flex items-center gap-2">
            <span className="w-7 text-[9px] font-bold uppercase tracking-wider text-[var(--text-tertiary)]">{label}</span>
            <MetricBar value={value} color={mBg} />
            <span className="w-8 text-right text-[10px] font-bold tabular-nums text-[var(--text-secondary)]">
              {(value * 100).toFixed(1)}%
            </span>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-1 border-t border-[var(--border-color)]">
        <div className="flex items-center gap-2 text-[10px] text-[var(--text-tertiary)]">
          <span className="flex items-center gap-1"><Scale size={9} /> {model.size} MB</span>
          <span className="text-[var(--border-color)]">·</span>
          <span className="flex items-center gap-1"><Zap size={9} /> {model.inferenceMs}ms</span>
        </div>
        <span className="text-[10px] text-[var(--text-tertiary)]">{model.trainedAt}</span>
      </div>
    </motion.div>
  );
}

// ─── Detail panel ─────────────────────────────────────────────────────────────

function DetailPanel({ model, onClose, onToggleDeploy }) {
  const [tab, setTab]             = useState("overview");
  const [exportStates, setExport] = useState({});

  function triggerExport(fmtId) {
    setExport((p) => ({ ...p, [fmtId]: "exporting" }));
    setTimeout(() => setExport((p) => ({ ...p, [fmtId]: "done" })), 2200);
  }

  const allExports = new Set([...model.exports, ...Object.entries(exportStates).filter(([,v]) => v === "done").map(([k]) => k)]);
  const arch  = ARCH_STYLE[model.architecture] ?? ARCH_STYLE.YOLOv8s;

  return (
    <motion.div
      key={model.id}
      initial={{ x: "100%", opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: "100%", opacity: 0 }}
      transition={{ type: "spring", stiffness: 380, damping: 38 }}
      className="w-[440px] flex-shrink-0 flex flex-col border-l border-[var(--border-color)] bg-[var(--bg-surface)]"
    >
      {/* Panel header */}
      <div className="flex-shrink-0 flex items-start justify-between gap-3 px-5 pt-5 pb-4 border-b border-[var(--border-color)]">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ring-1 ${arch.bg} ${arch.text} ${arch.ring}`}>
              {model.architecture}
            </span>
            {model.isDeployed && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-[var(--accent-500)]/10 text-[var(--accent-500)] border border-[var(--accent-500)]/20">
                <Rocket size={8} /> Deployed
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-2 mt-1.5">
            <span className="font-bold text-[var(--text-primary)]">{model.name}</span>
            <span className="text-xs font-mono text-[var(--text-tertiary)]">v{model.version}</span>
          </div>
          <p className="text-xs text-[var(--text-tertiary)] mt-0.5">{model.projectName}</p>
        </div>
        <button onClick={onClose}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors flex-shrink-0">
          <X size={15} />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex-shrink-0 flex items-center gap-0 px-5 border-b border-[var(--border-color)] bg-[var(--bg-main)]">
        {[["overview","Overview"], ["classes","Classes"], ["export","Export"]].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={`relative px-3 py-2.5 text-xs font-semibold transition-colors ${
              tab === id ? "text-[var(--text-primary)]" : "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]"
            }`}>
            {label}
            {tab === id && (
              <motion.div layoutId="panel_tab_line"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--accent-500)] rounded-full" />
            )}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        <AnimatePresence mode="wait">
          {tab === "overview" && (
            <motion.div key="overview"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="p-5 flex flex-col gap-5"
            >
              {/* Big metrics */}
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: "mAP50",    value: model.metrics.mAP50 },
                  { label: "mAP50:95", value: model.metrics.mAP5095 },
                  { label: "Precision",value: model.metrics.precision },
                  { label: "Recall",   value: model.metrics.recall },
                ].map(({ label, value }) => (
                  <div key={label} className="flex flex-col gap-0.5 px-3 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)]">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-tertiary)]">{label}</span>
                    <span className={`text-xl font-black tabular-nums ${mapColor(value)}`}>
                      {(value * 100).toFixed(1)}<span className="text-xs opacity-60">%</span>
                    </span>
                    <div className="h-1 rounded-full bg-[var(--bg-hover)] overflow-hidden mt-1">
                      <motion.div initial={{ width: 0 }} animate={{ width: `${value * 100}%` }}
                        transition={{ duration: 0.7, ease: "easeOut" }}
                        className={`h-full rounded-full ${mapBg(value)}`} />
                    </div>
                  </div>
                ))}
              </div>

              {/* Training curves */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)]">Training Loss</span>
                <div className="rounded-xl overflow-hidden border border-[var(--border-color)] bg-[var(--bg-main)] p-2">
                  <MiniLineChart
                    gradId={`loss_${model.id}`}
                    height={72}
                    lines={[
                      { data: model.trainLoss, color: "#6366f1", label: "Train" },
                      { data: model.valLoss,   color: "#ec4899", label: "Val" },
                    ]}
                  />
                  <div className="flex items-center gap-3 mt-2 px-1">
                    {[{ label: "Train", color: "#6366f1" }, { label: "Val", color: "#ec4899" }].map((l) => (
                      <div key={l.label} className="flex items-center gap-1">
                        <span className="w-3 h-0.5 rounded-full" style={{ backgroundColor: l.color }} />
                        <span className="text-[9px] text-[var(--text-tertiary)]">{l.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)]">mAP50 Progress</span>
                <div className="rounded-xl overflow-hidden border border-[var(--border-color)] bg-[var(--bg-main)] p-2">
                  <MiniLineChart
                    gradId={`map_${model.id}`}
                    height={72}
                    lines={[{ data: model.mAP50History, color: "#10b981" }]}
                  />
                </div>
              </div>

              {/* Model info */}
              <div className="flex flex-col gap-0 rounded-xl border border-[var(--border-color)] overflow-hidden">
                {[
                  { label: "Architecture", value: model.architecture },
                  { label: "Epochs",       value: model.config.epochs },
                  { label: "Image Size",   value: `${model.config.imageSize}px` },
                  { label: "Batch Size",   value: model.config.batchSize },
                  { label: "Optimizer",    value: model.config.optimizer },
                  { label: "Dataset",      value: model.config.dataset },
                  { label: "Model Size",   value: `${model.size} MB` },
                  { label: "Inference",    value: `${model.inferenceMs} ms/img` },
                  { label: "Trained",      value: model.trainedAt },
                ].map(({ label, value }, i, arr) => (
                  <div key={label} className={`flex items-center justify-between px-3 py-2 text-xs ${i < arr.length - 1 ? "border-b border-[var(--border-color)]" : ""} ${i % 2 === 0 ? "bg-[var(--bg-main)]" : "bg-[var(--bg-surface)]"}`}>
                    <span className="text-[var(--text-tertiary)] font-medium">{label}</span>
                    <span className="font-semibold text-[var(--text-primary)] font-mono">{value}</span>
                  </div>
                ))}
              </div>

              {/* Deploy toggle */}
              {model.status === "ready" && (
                <button onClick={() => onToggleDeploy(model.id)}
                  className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all ${
                    model.isDeployed
                      ? "bg-[var(--bg-hover)] text-[var(--text-secondary)] border border-[var(--border-color)] hover:border-red-500/40 hover:text-red-400"
                      : "bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white shadow-sm"
                  }`}>
                  <Rocket size={15} />
                  {model.isDeployed ? "Undeploy Model" : "Deploy Model"}
                </button>
              )}
            </motion.div>
          )}

          {tab === "classes" && (
            <motion.div key="classes"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="p-5 flex flex-col gap-4"
            >
              <div className="grid grid-cols-3 gap-x-3 gap-y-1 pb-2 border-b border-[var(--border-color)]">
                <span className="text-[9px] font-bold uppercase tracking-wider text-[var(--text-tertiary)]">Class</span>
                <span className="text-[9px] font-bold uppercase tracking-wider text-[var(--text-tertiary)] text-center">mAP50</span>
                <span className="text-[9px] font-bold uppercase tracking-wider text-[var(--text-tertiary)] text-right">Prec / Rec</span>
              </div>

              {model.classMetrics.map((cls) => (
                <div key={cls.name} className="flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: cls.color }} />
                      <span className="text-xs font-semibold text-[var(--text-primary)] truncate">{cls.name}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] font-mono">
                      <span className={`font-bold ${mapColor(cls.mAP50)}`}>{(cls.mAP50 * 100).toFixed(1)}%</span>
                      <span className="text-[var(--text-tertiary)]">
                        {(cls.precision * 100).toFixed(0)} / {(cls.recall * 100).toFixed(0)}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    {[
                      { label: "mAP50",     value: cls.mAP50,     color: cls.color },
                      { label: "Precision", value: cls.precision, color: cls.color + "cc" },
                      { label: "Recall",    value: cls.recall,    color: cls.color + "88" },
                    ].map(({ label, value, color }) => (
                      <div key={label} className="flex items-center gap-2">
                        <span className="w-12 text-[9px] text-[var(--text-tertiary)]">{label}</span>
                        <div className="flex-1 h-1.5 rounded-full bg-[var(--bg-hover)] overflow-hidden">
                          <motion.div initial={{ width: 0 }} animate={{ width: `${value * 100}%` }}
                            transition={{ duration: 0.6, ease: "easeOut" }}
                            className="h-full rounded-full" style={{ backgroundColor: color }} />
                        </div>
                        <span className="w-8 text-right text-[9px] font-mono text-[var(--text-tertiary)]">
                          {(value * 100).toFixed(0)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {tab === "export" && (
            <motion.div key="export"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="p-5 flex flex-col gap-3"
            >
              <p className="text-xs text-[var(--text-tertiary)]">
                Export this model to different formats for deployment.
              </p>
              {EXPORT_FORMATS.map((fmt) => {
                const exported  = allExports.has(fmt.id);
                const exporting = exportStates[fmt.id] === "exporting";
                return (
                  <div key={fmt.id}
                    className="flex items-center gap-3 p-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] hover:border-[var(--border-hover)] transition-colors">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: fmt.color + "20", border: `1px solid ${fmt.color}30` }}>
                      <Package size={15} style={{ color: fmt.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[var(--text-primary)]">{fmt.label}</span>
                        <span className="text-[9px] font-mono text-[var(--text-tertiary)] bg-[var(--bg-hover)] px-1.5 py-0.5 rounded">{fmt.ext}</span>
                      </div>
                      <p className="text-[10px] text-[var(--text-tertiary)] mt-0.5">{fmt.desc}</p>
                    </div>
                    {exported ? (
                      <button
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/15 transition-colors">
                        <Download size={11} /> Download
                      </button>
                    ) : exporting ? (
                      <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[10px] font-bold text-[var(--text-tertiary)] bg-[var(--bg-hover)] border border-[var(--border-color)]">
                        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                          <Zap size={11} />
                        </motion.div>
                        Exporting…
                      </div>
                    ) : (
                      <button onClick={() => triggerExport(fmt.id)}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[10px] font-bold text-[var(--text-secondary)] bg-[var(--bg-hover)] border border-[var(--border-color)] hover:border-[var(--border-hover)] hover:text-[var(--text-primary)] transition-colors">
                        <Zap size={11} /> Export
                      </button>
                    )}
                  </div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// ─── Compare modal ────────────────────────────────────────────────────────────

function CompareModal({ models, onClose }) {
  const metrics = [
    { label: "mAP50",      key: (m) => m.metrics.mAP50,      fmt: (v) => `${(v * 100).toFixed(1)}%`, higherBetter: true },
    { label: "mAP50:95",   key: (m) => m.metrics.mAP5095,    fmt: (v) => `${(v * 100).toFixed(1)}%`, higherBetter: true },
    { label: "Precision",  key: (m) => m.metrics.precision,  fmt: (v) => `${(v * 100).toFixed(1)}%`, higherBetter: true },
    { label: "Recall",     key: (m) => m.metrics.recall,     fmt: (v) => `${(v * 100).toFixed(1)}%`, higherBetter: true },
    { label: "F1 Score",   key: (m) => m.metrics.f1,         fmt: (v) => `${(v * 100).toFixed(1)}%`, higherBetter: true },
    { label: "Model Size", key: (m) => m.size,               fmt: (v) => `${v} MB`,                  higherBetter: false },
    { label: "Speed",      key: (m) => m.inferenceMs,        fmt: (v) => `${v} ms`,                  higherBetter: false },
    { label: "Epochs",     key: (m) => m.config.epochs,      fmt: (v) => v,                           higherBetter: null },
    { label: "Image Size", key: (m) => m.config.imageSize,   fmt: (v) => `${v}px`,                   higherBetter: null },
  ];

  function isBest(metric, model) {
    if (metric.higherBetter === null) return false;
    const vals = models.map(metric.key);
    const best = metric.higherBetter ? Math.max(...vals) : Math.min(...vals);
    return metric.key(model) === best;
  }

  const archStyle = (m) => ARCH_STYLE[m.architecture] ?? ARCH_STYLE.YOLOv8s;

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }}
        transition={{ type: "spring", stiffness: 400, damping: 35 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl max-h-[90vh] flex flex-col surface rounded-2xl shadow-2xl [overflow:clip]"
      >
        {/* Header */}
        <div className="flex-shrink-0 flex items-center justify-between px-6 py-4 border-b border-[var(--border-color)]">
          <div className="flex items-center gap-2">
            <ArrowLeftRight size={16} className="text-[var(--accent-500)]" />
            <span className="font-bold text-[var(--text-primary)]">Model Comparison</span>
            <span className="text-xs text-[var(--text-tertiary)]">({models.length} models)</span>
          </div>
          <button onClick={onClose}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors">
            <X size={15} />
          </button>
        </div>

        {/* Table */}
        <div className="flex-1 min-h-0 overflow-auto">
          <table className="w-full text-sm border-collapse">
            <thead className="sticky top-0 z-10 bg-[var(--bg-main)]">
              <tr>
                <th className="text-left px-4 py-3 text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)] border-b border-[var(--border-color)] w-32">Metric</th>
                {models.map((m) => {
                  const a = archStyle(m);
                  return (
                    <th key={m.id} className="px-4 py-3 border-b border-[var(--border-color)] text-center min-w-[160px]">
                      <div className="flex flex-col items-center gap-1">
                        <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ring-1 ${a.bg} ${a.text} ${a.ring}`}>
                          {m.architecture}
                        </span>
                        <span className="font-bold text-[var(--text-primary)] text-xs">{m.name} v{m.version}</span>
                        <span className="text-[9px] text-[var(--text-tertiary)]">{m.projectName}</span>
                        {m.isDeployed && (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[8px] font-bold bg-[var(--accent-500)]/10 text-[var(--accent-500)] border border-[var(--accent-500)]/20">
                            <Rocket size={7} /> Deployed
                          </span>
                        )}
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {metrics.map(({ label, key, fmt, higherBetter }, ri) => (
                <tr key={label} className={ri % 2 === 0 ? "bg-[var(--bg-surface)]" : "bg-[var(--bg-main)]"}>
                  <td className="px-4 py-2.5 text-xs font-medium text-[var(--text-tertiary)] border-r border-[var(--border-color)]">{label}</td>
                  {models.map((m) => {
                    const best = isBest({ key, higherBetter }, m);
                    return (
                      <td key={m.id} className="px-4 py-2.5 text-center">
                        <span className={`text-xs font-bold tabular-nums px-2 py-0.5 rounded-md ${
                          best ? "bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/25" : "text-[var(--text-primary)]"
                        }`}>
                          {fmt(key(m))}
                          {best && <Check size={10} className="inline ml-1" />}
                        </span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function ModelsPage() {
  const [models, setModels]           = useState(MOCK_MODELS);
  const [search, setSearch]           = useState("");
  const [archFilter, setArchFilter]   = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [projectFilter, setProjectFilter] = useState("All");
  const [selectedModel, setSelectedModel] = useState(null);
  const [compareMode, setCompareMode] = useState(false);
  const [checkedIds, setCheckedIds]   = useState([]);
  const [showCompare, setShowCompare] = useState(false);

  const allArchs    = ["All", ...new Set(MOCK_MODELS.map((m) => m.architecture))];
  const allStatuses = ["All", ...new Set(MOCK_MODELS.map((m) => m.status))];
  const allProjects = ["All", ...new Set(MOCK_MODELS.map((m) => m.projectName))];

  const filtered = models.filter((m) => {
    if (search && !m.name.toLowerCase().includes(search.toLowerCase()) && !m.version.includes(search)) return false;
    if (archFilter   !== "All" && m.architecture !== archFilter) return false;
    if (statusFilter !== "All" && m.status       !== statusFilter) return false;
    if (projectFilter !== "All" && m.projectName  !== projectFilter) return false;
    return true;
  });

  const stats = {
    total:    models.length,
    deployed: models.filter((m) => m.isDeployed).length,
    bestMAP:  Math.max(...models.map((m) => m.metrics.mAP50)),
    avgSpeed: Math.round(models.reduce((s, m) => s + m.inferenceMs, 0) / models.length),
  };

  function toggleDeploy(id) {
    setModels((prev) => prev.map((m) =>
      m.id === id ? { ...m, isDeployed: !m.isDeployed } :
      m.projectId === prev.find((x) => x.id === id)?.projectId && m.isDeployed ? { ...m, isDeployed: false } : m
    ));
  }

  function toggleCheck(id) {
    setCheckedIds((p) => p.includes(id) ? p.filter((x) => x !== id) : p.length < 3 ? [...p, id] : p);
  }

  function handleCompareToggle() {
    setCompareMode((v) => {
      if (v) setCheckedIds([]);
      return !v;
    });
    setSelectedModel(null);
  }

  const checkedModels = models.filter((m) => checkedIds.includes(m.id));

  const FilterPill = ({ label, options, value, onChange }) => {
    const [open, setOpen] = useState(false);
    const ref = useRef(null);
    useEffect(() => {
      const h = (e) => { if (!ref.current?.contains(e.target)) setOpen(false); };
      document.addEventListener("mousedown", h);
      return () => document.removeEventListener("mousedown", h);
    }, []);
    return (
      <div ref={ref} className="relative">
        <button onClick={() => setOpen((v) => !v)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
            value !== "All"
              ? "border-[var(--accent-500)]/50 bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
              : "border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
          }`}>
          {label}: <span className="font-bold">{value}</span>
          <ChevronDown size={12} className={`transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -4, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.97 }}
              transition={{ duration: 0.12 }}
              className="absolute top-full mt-1.5 left-0 z-20 min-w-[140px] surface rounded-xl border border-[var(--border-color)] shadow-xl py-1 [overflow:clip]"
            >
              {options.map((opt) => (
                <button key={opt} onClick={() => { onChange(opt); setOpen(false); }}
                  className={`w-full text-left px-3 py-1.5 text-xs font-medium flex items-center justify-between gap-2 transition-colors ${
                    value === opt ? "text-[var(--accent-500)] bg-[var(--accent-500)]/5" : "text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
                  }`}>
                  {opt}
                  {value === opt && <Check size={11} />}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="w-full md:h-full flex flex-col gap-4"
    >
      {/* Header + stats */}
      <div className="app-page-header flex-shrink-0 surface rounded-xl shadow-sm">
        <div className="flex items-center justify-between gap-4 px-5 pt-5 pb-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[var(--accent-500)]/10 text-[var(--accent-500)] flex items-center justify-center flex-shrink-0 border border-[var(--accent-500)]/20">
              <Boxes size={22} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[var(--text-primary)] leading-tight">Models Registry</h1>
              <p className="text-sm text-[var(--text-secondary)] mt-0.5">Manage trained models and deployments</p>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-4 divide-x divide-[var(--border-color)] border-t border-[var(--border-color)]">
          {[
            { label: "Total Models",  value: stats.total,                              icon: Layers,  color: "text-[var(--text-primary)]" },
            { label: "Deployed",      value: stats.deployed,                           icon: Rocket,  color: "text-[var(--accent-500)]" },
            { label: "Best mAP50",    value: `${(stats.bestMAP * 100).toFixed(1)}%`,  icon: BarChart3,color: "text-emerald-400" },
            { label: "Avg Speed",     value: `${stats.avgSpeed}ms`,                   icon: Zap,     color: "text-amber-400" },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="flex items-center gap-3 px-5 py-3">
              <Icon size={15} className={color} />
              <div>
                <div className={`text-lg font-black tabular-nums leading-none ${color}`}>{value}</div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)] mt-0.5">{label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main card */}
      <div className="md:flex-1 md:min-h-0 flex flex-col surface rounded-xl [overflow:clip]">

        {/* Controls bar */}
        <div className="flex-shrink-0 flex items-center gap-2 px-4 py-3 border-b border-[var(--border-color)] bg-[var(--bg-main)] flex-wrap">
          {/* Search */}
          <div className="relative flex-1 min-w-[180px] max-w-[240px]">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)]" />
            <input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search models…"
              className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-[var(--bg-hover)] border border-[var(--border-color)] text-xs text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] transition-all" />
          </div>

          <div className="w-px h-4 bg-[var(--border-color)]" />

          <FilterPill label="Arch"    options={allArchs}    value={archFilter}    onChange={setArchFilter} />
          <FilterPill label="Status"  options={allStatuses} value={statusFilter}  onChange={setStatusFilter} />
          <FilterPill label="Project" options={allProjects} value={projectFilter} onChange={setProjectFilter} />

          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs text-[var(--text-tertiary)]">{filtered.length} model{filtered.length !== 1 ? "s" : ""}</span>
            <button onClick={handleCompareToggle}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                compareMode
                  ? "border-[var(--accent-500)]/50 bg-[var(--accent-500)]/10 text-[var(--accent-500)]"
                  : "border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--bg-hover)]"
              }`}>
              <ArrowLeftRight size={12} />
              Compare
            </button>
          </div>
        </div>

        {/* Content: grid + detail panel */}
        <div className="flex-1 min-h-0 flex">

          {/* Model grid */}
          <div className="flex-1 min-w-0 overflow-y-auto p-4">
            {filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 gap-2 text-[var(--text-tertiary)]">
                <Boxes size={32} strokeWidth={1.5} />
                <p className="text-sm">No models match your filters</p>
              </div>
            ) : (
              <motion.div layout className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-3"
                style={{ gridTemplateColumns: selectedModel ? "repeat(auto-fill, minmax(240px, 1fr))" : undefined }}>
                <AnimatePresence>
                  {filtered.map((m) => (
                    <ModelCard
                      key={m.id}
                      model={m}
                      isSelected={selectedModel?.id === m.id}
                      onSelect={(model) => setSelectedModel(selectedModel?.id === model.id ? null : model)}
                      compareMode={compareMode}
                      isChecked={checkedIds.includes(m.id)}
                      onCheck={toggleCheck}
                    />
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </div>

          {/* Detail panel */}
          <AnimatePresence>
            {selectedModel && !compareMode && (
              <DetailPanel
                key={selectedModel.id}
                model={models.find((m) => m.id === selectedModel.id) ?? selectedModel}
                onClose={() => setSelectedModel(null)}
                onToggleDeploy={(id) => { toggleDeploy(id); setSelectedModel((p) => p ? { ...p, isDeployed: !p.isDeployed } : p); }}
              />
            )}
          </AnimatePresence>
        </div>

        {/* Compare floating bar */}
        <AnimatePresence>
          {compareMode && (
            <motion.div
              initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 400, damping: 38 }}
              className="flex-shrink-0 flex items-center gap-4 px-5 py-3 border-t border-[var(--border-color)] bg-[var(--bg-main)]"
            >
              <div className="flex items-center gap-2 flex-1">
                <span className="text-xs font-semibold text-[var(--text-secondary)]">Select 2–3 models to compare</span>
                <div className="flex items-center gap-1.5">
                  {[0, 1, 2].map((i) => {
                    const m = checkedModels[i];
                    return (
                      <div key={i} className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs border transition-all ${
                        m ? "border-[var(--accent-500)]/30 bg-[var(--accent-500)]/8 text-[var(--accent-500)]" : "border-dashed border-[var(--border-color)] text-[var(--text-tertiary)]"
                      }`}>
                        {m ? (
                          <>
                            <span className="font-semibold">{m.name} v{m.version}</span>
                            <button onClick={() => toggleCheck(m.id)}><X size={10} /></button>
                          </>
                        ) : (
                          <span className="text-[10px]">Slot {i + 1}</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              <button onClick={() => setShowCompare(true)}
                disabled={checkedIds.length < 2}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                  checkedIds.length >= 2
                    ? "bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white shadow-sm"
                    : "bg-[var(--bg-hover)] text-[var(--text-tertiary)] border border-[var(--border-color)] cursor-not-allowed"
                }`}>
                <ArrowLeftRight size={14} />
                Compare ({checkedIds.length})
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Compare modal */}
      <AnimatePresence>
        {showCompare && checkedModels.length >= 2 && (
          <CompareModal models={checkedModels} onClose={() => setShowCompare(false)} />
        )}
      </AnimatePresence>
    </motion.div>
  );
}
