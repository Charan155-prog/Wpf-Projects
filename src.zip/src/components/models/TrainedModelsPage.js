"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Download, RefreshCw, Trash2 } from "lucide-react";
import { useActiveProject } from "@/context/ProjectContext";
import { assetUrl, datasetRequest } from "@/utils/datasetApi";

export default function TrainedModelsPage() {
  const { activeProject } = useActiveProject();
  const [models, setModels] = useState([]);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const refresh = useCallback(async () => {
    setRefreshing(true);
    try { const result = await datasetRequest("/models"); setModels(result.items); setError(""); }
    catch (e) { setError(e.message); }
    finally { setRefreshing(false); }
  }, []);
  useEffect(() => { const timer = setTimeout(refresh, 0); window.addEventListener("focus", refresh); return () => { clearTimeout(timer); window.removeEventListener("focus", refresh); }; }, [refresh]);
  async function remove(model) {
    if (!window.confirm(`Permanently delete trained model “${model.name}” and its training run files? This cannot be undone.`)) return;
    try { await datasetRequest(`/models/${model.id}`, { method: "DELETE" }); setSelected((ids) => ids.filter((id) => id !== model.id)); await refresh(); }
    catch (e) { setError(e.message); }
  }
  const visible = models.filter((m) => activeProject && [activeProject.name, activeProject.name.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._]+|[._]+$/g, "")].includes(m.projectName) && `${m.name} ${m.mode} ${m.id}`.toLowerCase().includes(search.toLowerCase()));
  const compared = visible.filter((m) => selected.includes(m.id));
  const metricKeys = [...new Set(compared.flatMap((m) => Object.keys(m.testMetrics || {})))];
  return <section className="surface rounded-xl h-full overflow-auto p-3 space-y-4">
    <header className="flex flex-wrap items-center gap-3"><div className="flex items-baseline gap-2 min-w-fit"><h1 className="text-base font-bold">Models</h1>{activeProject && <span className="text-xs font-semibold text-[var(--text-secondary)]">{activeProject.name}</span>}</div><input aria-label="Search models" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search trained models" className="min-w-48 flex-1 rounded-lg bg-[var(--bg-hover)] px-3 py-2 text-sm" /><button aria-label="Refresh models" title="Refresh models" onClick={refresh} disabled={refreshing} className="rounded-lg p-2 hover:bg-[var(--bg-hover)]"><RefreshCw className={refreshing ? "animate-spin" : ""} size={17} /></button></header>
    {error && <p role="alert" className="text-red-400">{error}</p>}
    {!visible.length && <p>No completed models yet. <Link href="/training" className="underline">Train a validated dataset →</Link></p>}
    <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{visible.map((m) => <article key={m.id} className="rounded-2xl border border-[var(--border-color)] bg-gradient-to-br from-[var(--bg-hover)] to-[var(--bg-surface)] p-4 space-y-3 shadow-sm transition hover:-translate-y-0.5 hover:border-[var(--accent-500)] hover:shadow-lg">
      <div className="flex gap-2 items-center"><div className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--accent-500)]/10 text-xs font-bold text-[var(--accent-500)]">PT</div><h2 className="font-semibold flex-1 truncate">{m.name}</h2><span className="rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-bold text-emerald-400">READY</span><button onClick={() => remove(m)} aria-label={`Delete ${m.name}`} title="Permanently delete model" className="rounded p-1.5 text-red-400 hover:bg-red-500/10"><Trash2 size={15} /></button><input aria-label={`Compare ${m.name} ${m.id.slice(0,8)}`} type="checkbox" checked={selected.includes(m.id)} onChange={(e) => setSelected(e.target.checked ? [...selected, m.id] : selected.filter((id) => id !== m.id))} /></div>
      <p className="text-sm font-medium">{m.config.architecture}{m.mode === "segmentation" ? "-seg" : ""} · <span className="capitalize">{m.mode}</span></p>
      <p className="text-xs text-[var(--text-secondary)]">{new Date(m.createdAt).toLocaleString()} · {m.id.slice(0,8)}</p>
      <div className="grid grid-cols-3 gap-2 rounded-xl bg-black/10 p-2 text-center text-xs"><div><strong className="block text-sm">{m.splitCounts.train}</strong>Train</div><div><strong className="block text-sm">{m.splitCounts.val}</strong>Val</div><div><strong className="block text-sm">{m.splitCounts.test}</strong>Test</div></div>
      <p className="text-xs truncate" title={m.classes.join(", ")}>Classes: {m.classes.join(", ")}</p>
      <details><summary className="text-sm cursor-pointer">Measured metrics & configuration</summary><h3 className="mt-3 text-xs font-semibold">Held-out test</h3><Metrics values={m.testMetrics} /><h3 className="mt-3 text-xs font-semibold">Validation</h3><Metrics values={m.validationMetrics} /><pre className="text-xs overflow-auto mt-3">{JSON.stringify(m.config, null, 2)}</pre></details>
      <p className="text-xs font-mono truncate text-[var(--accent-500)]" title={m.filename}>{m.filename || `${m.name}_${m.mode}_${m.id.slice(0,8)}_best.pt`}</p>
      <div className="flex flex-wrap gap-4 text-sm"><a href={assetUrl(`/models/${m.id}/download`)} className="inline-flex items-center gap-1 underline"><Download size={15} />Download model</a><Link href={`/inference?model=${m.id}`} className="text-[var(--accent-500)] underline">Use in Inference →</Link></div>
    </article>)}</div>
    {compared.length > 1 && <div className="overflow-auto"><h2 className="font-semibold mb-3">Selected model metrics</h2><table className="text-xs w-full text-left"><thead><tr><th className="p-2">Test metric</th>{compared.map((m) => <th className="p-2" key={m.id}>{m.name} · {m.id.slice(0,8)}</th>)}</tr></thead><tbody>{metricKeys.map((key) => <tr key={key}><td className="p-2">{key}</td>{compared.map((m) => <td className="p-2" key={m.id}>{Number.isFinite(m.testMetrics?.[key]) ? m.testMetrics[key].toFixed(4) : "—"}</td>)}</tr>)}</tbody></table></div>}
  </section>;
}

function Metrics({ values }) {
  return <dl className="text-xs space-y-1 mt-2">{Object.entries(values || {}).map(([key, value]) => <div key={key} className="flex justify-between gap-2"><dt>{key}</dt><dd>{Number(value).toFixed(4)}</dd></div>)}</dl>;
}
