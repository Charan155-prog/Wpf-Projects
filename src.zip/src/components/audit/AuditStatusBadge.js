"use client";

import { Info, AlertTriangle, AlertCircle, XOctagon } from "lucide-react";

export default function AuditStatusBadge({ status }) {
  let styleClasses = "";
  let Icon = null;

  switch (status) {
    case "Info":
      styleClasses = "bg-blue-500/10 text-blue-500 border-blue-500/20";
      Icon = Info;
      break;
    case "Warning":
      styleClasses = "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      Icon = AlertTriangle;
      break;
    case "Error":
      styleClasses = "bg-red-500/10 text-red-500 border-red-500/20";
      Icon = AlertCircle;
      break;
    case "Critical":
      styleClasses = "bg-purple-500/10 text-purple-500 border-purple-500/20";
      Icon = XOctagon;
      break;
    default:
      styleClasses = "bg-gray-500/10 text-gray-500 border-gray-500/20";
      Icon = Info;
  }

  return (
    <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${styleClasses}`}>
      <Icon size={12} strokeWidth={3} />
      {status}
    </div>
  );
}
