"use client";

import { Search, Download, RefreshCw, X } from "lucide-react";
import Select from "@/components/ui/Select";
import DatePicker from "@/components/ui/DatePicker";

export default function AuditFilters({
  searchTerm, setSearchTerm,
  filterModule, setFilterModule,
  filterLevel, setFilterLevel,
  fromDate, handleFromDateChange,
  toDate, handleToDateChange,
  activeDateShortcut, setDateShortcut,
  filteredEntries,
  totalEntries,
  clearFilters,
}) {
  const levelOptions = ["All Levels", "Info", "Warning", "Error", "Critical"];
  const moduleOptions = [
    "All Modules", "Auth", "Projects", "Datasets",
    "Training", "Models", "User Management", "Settings", "System",
  ];
  const shortcutOptions = ["Today", "This Week", "This Month"];

  const isFiltered =
    searchTerm ||
    filterModule !== "All Modules" ||
    filterLevel !== "All Levels" ||
    fromDate ||
    toDate;

  const pillGroupCls =
    "flex items-center bg-[var(--bg-sidebar)] p-1 rounded-lg border border-[var(--border-color)]";
  const pillBase =
    "px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap";
  const pillActive =
    "bg-[var(--bg-surface)] text-[var(--text-primary)] shadow-sm border border-[var(--border-color)]";
  const pillInactive =
    "text-[var(--text-tertiary)] hover:text-[var(--text-secondary)] border border-transparent";

  return (
    <div className="flex flex-col gap-3 mb-2 surface rounded-xl shadow-sm p-4">

      {/* Row 1: Search + Export */}
      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={16} className="text-[var(--text-tertiary)]" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by action, user, module or details..."
            className="w-full pl-9 pr-4 py-2 bg-[var(--bg-hover)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-500)] focus:border-transparent transition-all placeholder:text-[var(--text-tertiary)]"
          />
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <button className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-[var(--bg-sidebar)] border border-[var(--border-color)] hover:bg-[var(--accent-500)]/10 hover:text-[var(--accent-500)] hover:border-[var(--accent-500)]/40 text-[var(--text-primary)] text-sm font-medium rounded-lg transition-all">
            <Download size={16} />
            Export CSV
          </button>
          <button
            className="flex items-center justify-center p-2.5 bg-[var(--bg-sidebar)] border border-[var(--border-color)] hover:bg-[var(--accent-500)]/10 hover:text-[var(--accent-500)] hover:border-[var(--accent-500)]/40 text-[var(--text-secondary)] rounded-lg transition-all"
            title="Refresh Logs"
          >
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* Row 2: Level · Module · From · To · Shortcuts · Clear · Count */}
      <div className="flex flex-wrap items-center gap-3 pt-1">

        {/* 1. Level pills */}
        <div className={pillGroupCls}>
          {levelOptions.map((level) => (
            <button
              key={level}
              onClick={() => setFilterLevel(level)}
              className={`${pillBase} ${filterLevel === level ? pillActive : pillInactive}`}
            >
              {level}
            </button>
          ))}
        </div>

        {/* 2. Module — custom Select (global component) */}
        <Select
          value={filterModule}
          onChange={setFilterModule}
          options={moduleOptions}
        />

        {/* 3 & 4. From / To — custom DatePicker (global component) */}
        <DatePicker
          label="From"
          value={fromDate}
          onChange={handleFromDateChange}
          placeholder="Start date"
        />
        <DatePicker
          label="To"
          value={toDate}
          onChange={handleToDateChange}
          placeholder="End date"
          align="right"
        />

        {/* 5. Shortcut pills */}
        <div className={pillGroupCls}>
          {shortcutOptions.map((s) => (
            <button
              key={s}
              onClick={() => setDateShortcut(s)}
              className={`${pillBase} ${
                activeDateShortcut === s
                  ? "bg-[var(--accent-500)] text-white shadow-sm"
                  : pillInactive
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* 6. Clear Filters with icon */}
        {isFiltered && (
          <button
            onClick={clearFilters}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-red-500 hover:text-red-600 hover:bg-red-500/10 rounded-md transition-colors whitespace-nowrap"
          >
            <X size={12} strokeWidth={3} />
            Clear Filters
          </button>
        )}

        {/* 7. Entries count */}
        {totalEntries !== undefined && (
          <span className="text-xs font-medium text-[var(--text-tertiary)] whitespace-nowrap ml-auto">
            {filteredEntries} of {totalEntries} entries
          </span>
        )}

      </div>
    </div>
  );
}
