"use client";

import { ListChecks } from "lucide-react";

export default function AuditHeader({ title, description, stats }) {
  return (
    <div className="app-page-header flex flex-col lg:flex-row lg:items-start justify-between gap-2 mb-2 p-4 surface rounded-xl shadow-sm">
      {/* Title & Icon */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center flex-shrink-0 border border-indigo-500/20">
          <ListChecks size={24} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)] mb-1 leading-tight">{title}</h1>
          <p className="text-sm text-[var(--text-secondary)]">{description}</p>
        </div>
      </div>
      
      {/* Metric Cards */}
      {stats && (
        <div className="flex items-center gap-3 overflow-x-auto pb-2 lg:pb-0">
          <StatBox label="TOTAL" value={stats.total} valueColor="text-[var(--text-primary)]" />
          <StatBox label="TODAY" value={stats.today} valueColor="text-blue-500" />
          <StatBox label="WARNINGS" value={stats.warnings} valueColor="text-orange-500" />
          <StatBox label="ERRORS" value={stats.errors} valueColor="text-red-500" />
        </div>
      )}
    </div>
  );
}

function StatBox({ label, value, valueColor }) {
  return (
    <div className="flex flex-col justify-center px-5 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-sidebar)] min-w-[100px]">
      <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-tertiary)] mb-1">{label}</span>
      <span className={`text-2xl font-bold leading-none ${valueColor}`}>{value}</span>
    </div>
  );
}
