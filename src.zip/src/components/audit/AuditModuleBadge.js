"use client";

export default function AuditModuleBadge({ moduleName }) {
  // Let's create a subtle standard pill for modules
  return (
    <span className="inline-flex items-center px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-widest bg-slate-500/10 text-slate-500 border border-slate-500/20">
      {moduleName}
    </span>
  );
}
