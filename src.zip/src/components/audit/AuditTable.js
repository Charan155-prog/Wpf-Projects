"use client";

import { motion } from "framer-motion";
import { User, Download } from "lucide-react";
import AuditStatusBadge from "./AuditStatusBadge";
import AuditModuleBadge from "./AuditModuleBadge";
import Pagination from "@/components/ui/Pagination";

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.05 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
};

export default function AuditTable({
  logs,
  loading,
  page,
  pageSize,
  totalFiltered,
  onPageChange,
  onPageSizeChange,
}) {
  if (loading) {
    return (
      <div className="md:flex-1 md:min-h-0 flex flex-col gap-3 min-h-[200px]">
        {Array.from({ length: pageSize ?? 5 }).map((_, i) => (
          <div
            key={`skeleton-${i}`}
            className="flex-1 rounded-xl bg-[var(--bg-surface)] animate-pulse border border-[var(--border-color)]"
          />
        ))}
      </div>
    );
  }

  if (totalFiltered === 0) {
    return (
      <div className="md:flex-1 md:min-h-0 min-h-[200px] flex items-center justify-center rounded-xl bg-[var(--bg-surface)] border border-[var(--border-color)] border-dashed">
        <p className="text-[var(--text-secondary)] text-sm">No audit logs found matching your criteria.</p>
      </div>
    );
  }

  return (
    /* md:flex-1 md:min-h-0 — fills remaining height on desktop; flows naturally on mobile */
    <div className="md:flex-1 md:min-h-0 flex flex-col [overflow:clip] rounded-xl border border-[var(--border-color)] bg-[var(--bg-surface)] shadow-sm">

      {/* Mobile: horizontal scroll only (page scrolls vertically). Desktop: both axes with sticky header */}
      <div className="overflow-x-auto md:overflow-auto md:flex-1 md:min-h-0">
        <table className="w-full text-left min-w-[1000px]">

          <thead className="sticky top-0 z-10 bg-[var(--bg-sidebar)]">
            <tr className="border-b border-[var(--border-color)]">
              <th className="px-6 py-4 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Timestamp</th>
              <th className="px-6 py-4 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">User</th>
              <th className="px-6 py-4 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Action</th>
              <th className="px-6 py-4 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Module</th>
              <th className="px-6 py-4 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest">Level</th>
              <th className="px-6 py-4 text-xs font-bold text-[var(--text-tertiary)] uppercase tracking-widest w-1/3">Details</th>
            </tr>
          </thead>

          <motion.tbody
            key={page}
            variants={containerVariants}
            initial="hidden"
            animate="show"
            className="divide-y divide-[var(--border-color)]/50"
          >
            {logs.map((log) => (
              <motion.tr
                key={log.id}
                variants={itemVariants}
                className="group hover:bg-[var(--bg-hover)] transition-colors duration-150"
              >
                <td className="px-6 py-3.5 whitespace-nowrap">
                  <span className="block text-xs font-mono text-[var(--text-secondary)]">
                    {new Date(log.timestamp).toISOString().split("T")[0]}
                  </span>
                  <span className="block text-xs font-mono text-[var(--text-tertiary)] mt-0.5">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour12: false })}
                  </span>
                </td>
                <td className="px-6 py-3.5 whitespace-nowrap">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[var(--accent-500)]/10 flex items-center justify-center text-[var(--accent-500)] flex-shrink-0">
                      <User size={16} />
                    </div>
                    <span className="text-sm font-medium text-[var(--text-primary)]">{log.user}</span>
                  </div>
                </td>
                <td className="px-6 py-3.5 whitespace-nowrap">
                  <span className="text-sm font-semibold text-[var(--text-primary)]">{log.action}</span>
                </td>
                <td className="px-6 py-3.5 whitespace-nowrap">
                  <AuditModuleBadge moduleName={log.module} />
                </td>
                <td className="px-6 py-3.5 whitespace-nowrap">
                  <AuditStatusBadge status={log.level} />
                </td>
                <td className="px-6 py-3.5 text-sm text-[var(--text-secondary)] leading-relaxed">
                  {log.details}
                </td>
              </motion.tr>
            ))}
          </motion.tbody>

        </table>
      </div>

      {/* Footer — always visible, never scrolls away */}
      <div className="flex-shrink-0 px-6 py-4 border-t border-[var(--border-color)] bg-[var(--bg-surface)] flex flex-col sm:flex-row items-center gap-4">
        <Pagination
          page={page}
          pageSize={pageSize}
          totalItems={totalFiltered}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
        <button className="flex-shrink-0 flex items-center gap-2 px-4 py-2 bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white text-sm font-semibold rounded-lg transition-colors shadow-sm whitespace-nowrap">
          <Download size={16} />
          Download {totalFiltered} entries
        </button>
      </div>

    </div>
  );
}
