"use client";

import { useState, useRef, useEffect } from "react";
import { ChevronDown, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * Global reusable custom dropdown. Props:
 *   value        — currently selected option string
 *   onChange     — (option: string) => void
 *   options      — string[]  (first item treated as the "default / all" state)
 *   defaultValue — override which value counts as "default" for accent highlighting
 *   placeholder  — shown when value is empty
 *   className    — extra classes on the wrapper div
 *   maxHeight    — max-height of the open list (default 260px)
 *   direction    — "down" (default) | "up"  — which way the panel opens
 */
export default function Select({
  value,
  onChange,
  options = [],
  defaultValue,
  placeholder,
  className = "",
  maxHeight = 260,
  direction = "down",
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const listRef = useRef(null);

  const defaultVal = defaultValue ?? options[0];
  const isDefault = value === defaultVal || !value;
  const displayLabel = value || placeholder || defaultVal;

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // Scroll selected option into view when opening
  useEffect(() => {
    if (open && listRef.current) {
      const selected = listRef.current.querySelector("[data-selected='true']");
      if (selected) selected.scrollIntoView({ block: "nearest" });
    }
  }, [open]);

  return (
    <div ref={ref} className={`relative ${className}`}>
      {/* Trigger */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={`flex items-center gap-1.5 bg-[var(--bg-sidebar)] p-1 pl-3 pr-2 rounded-lg border transition-all ${
          !isDefault
            ? "border-[var(--accent-500)] text-[var(--accent-500)]"
            : "border-[var(--border-color)] text-[var(--text-tertiary)] hover:text-[var(--text-secondary)]"
        }`}
      >
        <span className="py-1.5 text-xs font-semibold whitespace-nowrap select-none">
          {displayLabel}
        </span>
        <ChevronDown
          size={13}
          className={`flex-shrink-0 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        />
      </button>

      {/* Dropdown panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: direction === "up" ? 6 : -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: direction === "up" ? 6 : -6, scale: 0.97 }}
            transition={{ duration: 0.14, ease: "easeOut" }}
            className={`absolute ${direction === "up" ? "bottom-full mb-1.5" : "top-full mt-1.5"} left-0 z-50 min-w-[180px] bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-xl shadow-2xl overflow-hidden`}
          >
            <div
              ref={listRef}
              className="py-1.5 overflow-y-auto"
              style={{ maxHeight }}
            >
              {options.map((opt) => {
                const active = value === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    data-selected={active}
                    onClick={() => { onChange(opt); setOpen(false); }}
                    className={`w-full flex items-center justify-between gap-3 px-3.5 py-2.5 text-xs font-semibold transition-colors hover:bg-[var(--bg-hover)] ${
                      active
                        ? "text-[var(--accent-500)]"
                        : "text-[var(--text-secondary)]"
                    }`}
                  >
                    <span>{opt}</span>
                    {active && <Check size={12} strokeWidth={3} className="flex-shrink-0" />}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
