"use client";

import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

/**
 * Global reusable success dialog. Props:
 *   open        - boolean
 *   title       - string
 *   message     - string (optional)
 *   actionLabel - default "Done"
 *   autoCloseMs - number | null, default 2600
 *   onClose     - () => void
 */
export default function SuccessDialog({
  open,
  title,
  message,
  actionLabel = "Done",
  autoCloseMs = 2600,
  onClose,
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onClose]);

  useEffect(() => {
    if (!open || !autoCloseMs) return;
    const timer = window.setTimeout(onClose, autoCloseMs);
    return () => window.clearTimeout(timer);
  }, [open, autoCloseMs, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="absolute inset-0 bg-black/45 backdrop-blur-[1.5px]"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.82, y: 28 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.88, y: 16 }}
            transition={{ type: "spring", stiffness: 380, damping: 26 }}
            className="relative z-10 w-full max-w-sm bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-2xl shadow-2xl p-6 flex flex-col items-center text-center gap-5"
          >
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 520, damping: 22, delay: 0.12 }}
              className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{
                  opacity: 1,
                  scale: [0.8, 1.18, 0.96, 1],
                  rotate: [0, -8, 6, 0],
                }}
                transition={{ delay: 0.24, duration: 0.5, ease: "easeOut" }}
              >
                <CheckCircle2 size={32} className="text-emerald-500" strokeWidth={1.9} />
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.18, duration: 0.28, ease: "easeOut" }}
              className="flex flex-col gap-1.5"
            >
              <h3 className="text-base font-bold text-[var(--text-primary)]">{title}</h3>
              {message && (
                <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{message}</p>
              )}
            </motion.div>

            <motion.button
              type="button"
              onClick={onClose}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.24, duration: 0.28, ease: "easeOut" }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              className="w-full px-4 py-2.5 text-sm font-semibold rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white transition-colors shadow-sm"
            >
              {actionLabel}
            </motion.button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
