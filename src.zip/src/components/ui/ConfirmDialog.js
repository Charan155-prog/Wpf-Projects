"use client";

import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Trash2, AlertTriangle, Info } from "lucide-react";

const VARIANTS = {
  danger: {
    Icon: Trash2,
    iconBg: "bg-red-500/10",
    iconColor: "text-red-500",
    confirmCls: "bg-red-500 hover:bg-red-600 text-white",
    // Icon shakes left-right — feels destructive
    iconMotion: { rotate: [0, -14, 14, -9, 9, -4, 0] },
  },
  warning: {
    Icon: AlertTriangle,
    iconBg: "bg-orange-500/10",
    iconColor: "text-orange-500",
    confirmCls: "bg-orange-500 hover:bg-orange-600 text-white",
    // Icon bounces up — feels cautionary
    iconMotion: { y: [0, -8, 0, -4, 0] },
  },
  info: {
    Icon: Info,
    iconBg: "bg-[var(--accent-500)]/10",
    iconColor: "text-[var(--accent-500)]",
    confirmCls: "bg-[var(--accent-500)] hover:bg-[var(--accent-600)] text-white",
    // Icon pulses scale — feels informational
    iconMotion: { scale: [1, 1.2, 0.93, 1.07, 1] },
  },
};

/**
 * Global reusable confirmation dialog. Props:
 *   open         — boolean
 *   title        — string
 *   message      — string (optional)
 *   confirmLabel — default "Confirm"
 *   cancelLabel  — default "Cancel"
 *   variant      — "danger" | "warning" | "info"
 *   onConfirm    — () => void
 *   onCancel     — () => void
 */
export default function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  variant = "danger",
  onConfirm,
  onCancel,
}) {
  const v = VARIANTS[variant] ?? VARIANTS.danger;
  const { Icon } = v;

  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (e.key === "Escape") onCancel(); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onCancel]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">

          {/* Backdrop — fades in */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="absolute inset-0 bg-black/55 backdrop-blur-[1.5px]"
            onClick={onCancel}
          />

          {/* Panel — springs up with a slight overshoot */}
          <motion.div
            initial={{ opacity: 0, scale: 0.82, y: 28 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.88, y: 16 }}
            transition={{ type: "spring", stiffness: 380, damping: 26 }}
            className="relative z-10 w-full max-w-sm bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-2xl shadow-2xl p-6 flex flex-col items-center text-center gap-5"
          >
            {/* Icon circle — pops in after panel */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 520, damping: 22, delay: 0.12 }}
              className={`w-16 h-16 rounded-full flex items-center justify-center ${v.iconBg}`}
            >
              {/* Icon itself — variant-specific motion after appearing */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1, ...v.iconMotion }}
                transition={{ delay: 0.28, duration: 0.55, ease: "easeInOut" }}
              >
                <Icon size={28} className={v.iconColor} strokeWidth={1.8} />
              </motion.div>
            </motion.div>

            {/* Text — slides up */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.18, duration: 0.28, ease: "easeOut" }}
              className="flex flex-col gap-1.5"
            >
              <h3 className="text-base font-bold text-[var(--text-primary)]">{title}</h3>
              {message && (
                <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{message}</p>
              )}
            </motion.div>

            {/* Buttons — slides up, slightly more delay */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.24, duration: 0.28, ease: "easeOut" }}
              className="flex items-center gap-3 w-full"
            >
              <motion.button
                type="button"
                onClick={onCancel}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                className="flex-1 px-4 py-2.5 text-sm font-semibold rounded-lg border border-[var(--border-color)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
              >
                {cancelLabel}
              </motion.button>

              <motion.button
                type="button"
                onClick={onConfirm}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                className={`flex-1 px-4 py-2.5 text-sm font-semibold rounded-lg transition-colors shadow-sm ${v.confirmCls}`}
              >
                {confirmLabel}
              </motion.button>
            </motion.div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
