"use client";

import { motion } from "framer-motion";

const SIZE_MAP = {
  sm: { track: "w-9 h-5", knobPx: 14, offX: 3, onX: 18 },
  md: { track: "w-11 h-6", knobPx: 16, offX: 4, onX: 23 },
};

export default function Toggle({ checked, onChange, disabled = false, size = "md" }) {
  const s = SIZE_MAP[size] ?? SIZE_MAP.md;

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => !disabled && onChange(!checked)}
      className={`relative inline-flex flex-shrink-0 items-center rounded-full transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-500)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-surface)] ${s.track} ${
        checked ? "bg-[var(--accent-500)]" : "bg-[var(--border-hover)]"
      } ${disabled ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}
    >
      <motion.span
        animate={{ x: checked ? s.onX : s.offX }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        style={{
          position: "absolute",
          width: s.knobPx,
          height: s.knobPx,
          borderRadius: "9999px",
          backgroundColor: "white",
          boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
        }}
      />
    </button>
  );
}
