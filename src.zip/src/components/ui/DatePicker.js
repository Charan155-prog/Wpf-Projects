"use client";

import { useState, useRef, useEffect } from "react";
import { Calendar, ChevronLeft, ChevronRight, ChevronDown, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const DAY_LABELS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

function buildCalendarGrid(year, month) {
  const firstDay = new Date(year, month, 1).getDay();
  const totalDays = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= totalDays; d++) cells.push(d);
  return cells;
}

/**
 * Global reusable custom date picker. Props:
 *   value       — ISO date string "YYYY-MM-DD" or ""
 *   onChange    — (value: string) => void  (empty string = cleared)
 *   label       — small prefix label shown in the trigger (e.g. "From" / "To")
 *   placeholder — text shown when no date selected
 *   align       — "left" | "right"  — which side the calendar panel aligns to
 */
export default function DatePicker({
  value,
  onChange,
  label,
  placeholder = "Pick date",
  align = "left",
}) {
  const [open, setOpen] = useState(false);
  const today = new Date();
  const ref = useRef(null);

  const parsedValue = value ? new Date(value + "T00:00:00") : null;

  const [viewYear, setViewYear] = useState(
    parsedValue ? parsedValue.getFullYear() : today.getFullYear()
  );
  const [viewMonth, setViewMonth] = useState(
    parsedValue ? parsedValue.getMonth() : today.getMonth()
  );

  // Keep calendar view in sync when value is set externally (e.g. shortcuts)
  useEffect(() => {
    if (value) {
      const d = new Date(value + "T00:00:00");
      setViewYear(d.getFullYear());
      setViewMonth(d.getMonth());
    }
  }, [value]);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const cells = buildCalendarGrid(viewYear, viewMonth);

  const isSelected = (d) =>
    d &&
    parsedValue &&
    parsedValue.getFullYear() === viewYear &&
    parsedValue.getMonth() === viewMonth &&
    parsedValue.getDate() === d;

  const isToday = (d) =>
    d &&
    today.getFullYear() === viewYear &&
    today.getMonth() === viewMonth &&
    today.getDate() === d;

  const handleSelect = (d) => {
    if (!d) return;
    const m = String(viewMonth + 1).padStart(2, "0");
    const day = String(d).padStart(2, "0");
    onChange(`${viewYear}-${m}-${day}`);
    setOpen(false);
  };

  const prevMonth = () => {
    if (viewMonth === 0) { setViewMonth(11); setViewYear((y) => y - 1); }
    else setViewMonth((m) => m - 1);
  };

  const nextMonth = () => {
    if (viewMonth === 11) { setViewMonth(0); setViewYear((y) => y + 1); }
    else setViewMonth((m) => m + 1);
  };

  const displayValue = parsedValue
    ? parsedValue.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })
    : null;

  const panelAlign = align === "right" ? "right-0" : "left-0";

  return (
    <div ref={ref} className="relative">
      {/* Trigger button — same p-1 container height as pill groups */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={`flex items-center gap-1.5 bg-[var(--bg-sidebar)] p-1 pl-2 pr-2 rounded-lg border transition-all ${
          value
            ? "border-[var(--accent-500)]"
            : "border-[var(--border-color)]"
        }`}
      >
        {label && (
          <span className="pl-1 text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)] select-none">
            {label}
          </span>
        )}
        <Calendar
          size={13}
          className={value ? "text-[var(--accent-500)]" : "text-[var(--text-tertiary)]"}
        />
        <span
          className={`py-1.5 text-xs font-semibold whitespace-nowrap ${
            value ? "text-[var(--accent-500)]" : "text-[var(--text-tertiary)]"
          }`}
        >
          {displayValue ?? placeholder}
        </span>
        <ChevronDown
          size={12}
          className={`flex-shrink-0 transition-transform duration-200 text-[var(--text-tertiary)] ${open ? "rotate-180" : ""}`}
        />
      </button>

      {/* Calendar panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.14, ease: "easeOut" }}
            className={`absolute top-full mt-1.5 ${panelAlign} z-50 w-72 bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-xl shadow-2xl p-4`}
          >
            {/* Month / Year header */}
            <div className="flex items-center justify-between mb-4">
              <button
                type="button"
                onClick={prevMonth}
                className="p-1.5 rounded-lg hover:bg-[var(--bg-hover)] text-[var(--text-secondary)] transition-colors"
              >
                <ChevronLeft size={14} />
              </button>
              <span className="text-sm font-bold text-[var(--text-primary)]">
                {MONTHS[viewMonth]} {viewYear}
              </span>
              <button
                type="button"
                onClick={nextMonth}
                className="p-1.5 rounded-lg hover:bg-[var(--bg-hover)] text-[var(--text-secondary)] transition-colors"
              >
                <ChevronRight size={14} />
              </button>
            </div>

            {/* Day-of-week headers */}
            <div className="grid grid-cols-7 mb-1">
              {DAY_LABELS.map((d) => (
                <div
                  key={d}
                  className="text-center text-[10px] font-bold uppercase tracking-wide text-[var(--text-tertiary)] py-1"
                >
                  {d}
                </div>
              ))}
            </div>

            {/* Day grid */}
            <div className="grid grid-cols-7 gap-0.5">
              {cells.map((d, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSelect(d)}
                  disabled={!d}
                  className={`aspect-square flex items-center justify-center rounded-lg text-xs font-medium transition-all ${
                    !d
                      ? "invisible pointer-events-none"
                      : isSelected(d)
                      ? "bg-[var(--accent-500)] text-white font-bold shadow-sm scale-105"
                      : isToday(d)
                      ? "border border-[var(--accent-500)] text-[var(--accent-500)] font-semibold hover:bg-[var(--accent-500)]/10"
                      : "text-[var(--text-primary)] hover:bg-[var(--bg-hover)]"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>

            {/* Clear date */}
            {value && (
              <button
                type="button"
                onClick={() => { onChange(""); setOpen(false); }}
                className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-red-500 hover:text-red-600 py-2 rounded-lg hover:bg-red-500/10 transition-colors border border-dashed border-red-500/30"
              >
                <X size={12} strokeWidth={3} />
                Clear date
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
