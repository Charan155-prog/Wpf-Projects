"use client";

import { useEffect, useId } from "react";
import { X } from "lucide-react";

export default function SidePanel({ open, onClose, title, subtitle, children }) {
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (event) => {
      if (event.key === "Escape" && !event.defaultPrevented) onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <aside
      aria-labelledby={titleId}
      className="flex min-h-0 w-full shrink-0 flex-col border-t border-[var(--border-color)] bg-[var(--bg-surface)] text-[var(--text-primary)] max-h-[45dvh] md:max-h-none md:w-[360px] md:border-t-0 md:border-l xl:w-[400px]"
    >
      <header className="flex shrink-0 items-center justify-between gap-3 border-b border-[var(--border-color)] px-4 py-3">
        <div className="min-w-0">
          <h2 id={titleId} className="text-sm font-semibold">{title}</h2>
          {subtitle && <p className="mt-0.5 truncate text-xs text-[var(--text-secondary)]">{subtitle}</p>}
        </div>
        <button
          type="button"
          aria-label={`Close ${title}`}
          onClick={onClose}
          className="shrink-0 rounded-lg p-2 hover:bg-[var(--bg-hover)] focus-visible:outline-2 focus-visible:outline-offset-2"
        >
          <X size={18} aria-hidden="true" />
        </button>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-4">{children}</div>
    </aside>
  );
}
