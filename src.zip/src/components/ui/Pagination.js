"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";

function buildPageNumbers(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);

  if (current <= 4)
    return [1, 2, 3, 4, 5, "...", total];

  if (current >= total - 3)
    return [1, "...", total - 4, total - 3, total - 2, total - 1, total];

  return [1, "...", current - 1, current, current + 1, "...", total];
}

/**
 * Global reusable pagination bar. Props:
 *   page              — current page (1-based)
 *   pageSize          — rows per page
 *   totalItems        — total number of items (after filtering)
 *   onPageChange      — (page: number) => void
 *   onPageSizeChange  — (size: number) => void
 */
export default function Pagination({
  page,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
}) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const from = totalItems === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, totalItems);
  const pageNumbers = buildPageNumbers(page, totalPages);

  const goTo = (p) => {
    if (p < 1 || p > totalPages) return;
    onPageChange(p);
  };

  return (
    <div className="flex w-full items-center justify-center">
      <div className="flex items-center gap-1">
        <button
          onClick={() => goTo(page - 1)}
          disabled={page === 1}
          className="p-1.5 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--accent-500)]/10 hover:text-[var(--accent-500)] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          aria-label="Previous page"
        >
          <ChevronLeft size={15} />
        </button>

        {pageNumbers.map((p, i) =>
          p === "..." ? (
            <span
              key={`ellipsis-${i}`}
              className="min-w-[32px] text-center text-xs text-[var(--text-tertiary)] select-none"
            >
              …
            </span>
          ) : (
            <button
              key={p}
              onClick={() => goTo(p)}
              className={`min-w-[32px] h-8 px-2 rounded-lg text-xs font-semibold transition-all ${
                p === page
                  ? "bg-[var(--accent-500)] text-white shadow-sm scale-105"
                  : "text-[var(--text-secondary)] hover:bg-[var(--accent-500)]/10 hover:text-[var(--accent-500)]"
              }`}
            >
              {p}
            </button>
          )
        )}

        <button
          onClick={() => goTo(page + 1)}
          disabled={page >= totalPages}
          className="p-1.5 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--accent-500)]/10 hover:text-[var(--accent-500)] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          aria-label="Next page"
        >
          <ChevronRight size={15} />
        </button>
      </div>

    </div>
  );
}
