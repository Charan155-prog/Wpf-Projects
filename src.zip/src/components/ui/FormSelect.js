"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown } from "lucide-react";

/**
 * Full-width form-style custom select. Props:
 *   value       — selected option value (string)
 *   onChange    — (value: string) => void
 *   options     — { value: string, label: string }[]
 *   placeholder — shown when nothing is selected
 *   disabled    — disables the control
 *   direction   — "down" (default) | "up"
 */
export default function FormSelect({
  value,
  onChange,
  options = [],
  placeholder = "Select…",
  disabled = false,
  direction = "down",
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const selected = options.find((o) => o.value === value) ?? null;

  useEffect(() => {
    if (!open) return;
    function handler(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  function pick(opt) {
    onChange(opt.value);
    setOpen(false);
  }

  return (
    <div ref={ref} className="relative w-full">
      {/* Trigger */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => !disabled && setOpen((v) => !v)}
        className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition-all text-left ${
          open
            ? "border-[var(--accent-500)] ring-2 ring-[var(--accent-500)]/20 bg-[var(--bg-hover)]"
            : "border-[var(--border-color)] bg-[var(--bg-hover)] hover:border-[var(--border-hover)]"
        } ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
      >
        <span className={`flex-1 truncate ${selected ? "text-[var(--text-primary)]" : "text-[var(--text-tertiary)]"}`}>
          {selected ? selected.label : placeholder}
        </span>
        <motion.div
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.18 }}
          className="flex-shrink-0"
        >
          <ChevronDown size={14} className="text-[var(--text-tertiary)]" />
        </motion.div>
      </button>

      {/* Dropdown panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: direction === "up" ? 6 : -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: direction === "up" ? 6 : -6, scale: 0.97 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className={`absolute ${direction === "up" ? "bottom-full mb-1.5" : "top-full mt-1.5"} left-0 right-0 z-50 bg-[var(--bg-surface)] border border-[var(--border-color)] rounded-xl shadow-2xl overflow-hidden`}
          >
            <div className="py-1 max-h-56 overflow-y-auto">
              {options.length === 0 ? (
                <p className="px-4 py-3 text-xs text-[var(--text-tertiary)] text-center">No options available.</p>
              ) : (
                options.map((opt) => {
                  const isActive = opt.value === value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => pick(opt)}
                      className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-sm text-left transition-colors hover:bg-[var(--bg-hover)] ${
                        isActive ? "text-[var(--accent-500)] font-semibold" : "text-[var(--text-secondary)]"
                      }`}
                    >
                      <span className="flex-1 truncate">{opt.label}</span>
                      {isActive && <Check size={13} strokeWidth={2.5} className="flex-shrink-0 text-[var(--accent-500)]" />}
                    </button>
                  );
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
