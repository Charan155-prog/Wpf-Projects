"use client";

import { useState, useMemo } from "react";
import { MOCK_USERS } from "@/data/mockUserData";

export function useUserManagement() {
  const [users, setUsers] = useState(MOCK_USERS);
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState("table");
  const [activeTab, setActiveTab] = useState("users");

  const filteredUsers = useMemo(() => {
    if (!searchTerm.trim()) return users;
    const lower = searchTerm.toLowerCase();
    return users.filter(
      (u) =>
        u.name.toLowerCase().includes(lower) ||
        u.email.toLowerCase().includes(lower) ||
        u.role.toLowerCase().includes(lower)
    );
  }, [users, searchTerm]);

  const stats = useMemo(() => ({
    total: users.length,
    active: users.filter((u) => u.status === "Active").length,
    admins: users.filter((u) => u.role === "Admin").length,
    operators: users.filter((u) => u.role === "Operator").length,
    technicians: users.filter((u) => u.role === "Technician").length,
  }), [users]);

  function addUser(userData) {
    const newUser = {
      id: `usr_${Date.now()}`,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      ...userData,
    };
    setUsers((prev) => [newUser, ...prev]);
  }

  function deleteUser(id) {
    setUsers((prev) => prev.filter((u) => u.id !== id));
  }

  function updateUser(id, updates) {
    setUsers((prev) =>
      prev.map((u) => (u.id === id ? { ...u, ...updates } : u))
    );
  }

  return {
    users,
    filteredUsers,
    searchTerm,
    setSearchTerm,
    viewMode,
    setViewMode,
    activeTab,
    setActiveTab,
    stats,
    addUser,
    deleteUser,
    updateUser,
  };
}
