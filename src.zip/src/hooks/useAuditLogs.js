import { useState, useEffect, useMemo } from "react";
import { MOCK_AUDIT_LOGS } from "@/data/mockAuditData";

function toDateStr(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function useAuditLogs() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filter states
  const [searchTerm, setSearchTerm] = useState("");
  const [filterModule, setFilterModule] = useState("All Modules");
  const [filterLevel, setFilterLevel] = useState("All Levels");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeDateShortcut, setActiveDateShortcut] = useState("");

  // Pagination states
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);

  const [stats, setStats] = useState({ total: 0, today: 0, warnings: 0, errors: 0 });

  // Reset to page 1 whenever any filter changes
  useEffect(() => {
    setPage(1);
  }, [searchTerm, filterModule, filterLevel, fromDate, toDate]);

  const setDateShortcut = (shortcut) => {
    const today = new Date();
    const todayStr = toDateStr(today);
    if (shortcut === "Today") {
      setFromDate(todayStr);
      setToDate(todayStr);
    } else if (shortcut === "This Week") {
      const start = new Date(today);
      start.setDate(today.getDate() - today.getDay());
      setFromDate(toDateStr(start));
      setToDate(todayStr);
    } else if (shortcut === "This Month") {
      setFromDate(`${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-01`);
      setToDate(todayStr);
    }
    setActiveDateShortcut(shortcut);
  };

  const handleFromDateChange = (val) => { setFromDate(val); setActiveDateShortcut(""); };
  const handleToDateChange  = (val) => { setToDate(val);   setActiveDateShortcut(""); };

  const clearFilters = () => {
    setSearchTerm("");
    setFilterModule("All Modules");
    setFilterLevel("All Levels");
    setFromDate("");
    setToDate("");
    setActiveDateShortcut("");
  };

  // Main filter effect
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      let filtered = [...MOCK_AUDIT_LOGS];

      const todayDate = new Date();
      todayDate.setHours(0, 0, 0, 0);

      setStats({
        total: MOCK_AUDIT_LOGS.length,
        today: MOCK_AUDIT_LOGS.filter(l => new Date(l.timestamp) >= todayDate).length,
        warnings: MOCK_AUDIT_LOGS.filter(l => l.level === "Warning").length,
        errors: MOCK_AUDIT_LOGS.filter(l => l.level === "Error" || l.level === "Critical").length,
      });

      if (searchTerm) {
        const lower = searchTerm.toLowerCase();
        filtered = filtered.filter(log =>
          log.user.toLowerCase().includes(lower) ||
          log.action.toLowerCase().includes(lower) ||
          log.details.toLowerCase().includes(lower)
        );
      }

      if (filterModule !== "All Modules") {
        filtered = filtered.filter(log =>
          log.module.toLowerCase() === filterModule.toLowerCase()
        );
      }

      if (filterLevel !== "All Levels") {
        filtered = filtered.filter(log => log.level === filterLevel);
      }

      if (fromDate) {
        filtered = filtered.filter(log =>
          new Date(log.timestamp) >= new Date(fromDate + "T00:00:00Z")
        );
      }

      if (toDate) {
        filtered = filtered.filter(log =>
          new Date(log.timestamp) <= new Date(toDate + "T23:59:59Z")
        );
      }

      filtered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
      setLogs(filtered);
      setLoading(false);
    }, 600);

    return () => clearTimeout(timer);
  }, [searchTerm, filterModule, filterLevel, fromDate, toDate]);

  // Paginate the filtered results — computed, not stored
  const totalPages = Math.max(1, Math.ceil(logs.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const paginatedLogs = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return logs.slice(start, start + pageSize);
  }, [logs, safePage, pageSize]);

  return {
    paginatedLogs,
    loading,
    stats,
    totalFiltered: logs.length,
    totalLogs: MOCK_AUDIT_LOGS.length,
    page: safePage,
    pageSize,
    setPage,
    setPageSize,
    searchTerm, setSearchTerm,
    filterModule, setFilterModule,
    filterLevel, setFilterLevel,
    fromDate, handleFromDateChange,
    toDate, handleToDateChange,
    activeDateShortcut, setDateShortcut,
    clearFilters,
  };
}
