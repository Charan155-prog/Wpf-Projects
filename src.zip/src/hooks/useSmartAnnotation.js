"use client";

import { useEffect, useRef, useState } from "react";
import { MOCK_DATASETS } from "@/data/mockDatasetData";

const DEFAULT_CONFIG = {
  datasetId:           "",
  imageScope:          "unannotated", // all | unannotated | train | val | test
  modelId:             "",
  confidenceThreshold: 0.50,
  iouThreshold:        0.45,
  overwrite:           false,
};

function getTotal(config) {
  const ds = MOCK_DATASETS.find((d) => d.id === config.datasetId);
  if (!ds) return 0;
  switch (config.imageScope) {
    case "train":       return ds.split.train;
    case "val":         return ds.split.val;
    case "test":        return ds.split.test;
    case "unannotated": return Math.floor(ds.totalImages * 0.38);
    default:            return ds.totalImages;
  }
}

function mockAnnotations(classes, conf) {
  const count = Math.floor(Math.random() * 4); // 0-3 per image
  return Array.from({ length: count }, () => {
    const cls = classes[Math.floor(Math.random() * classes.length)];
    return { className: cls.alias, confidence: +(conf + Math.random() * (1 - conf) * 0.8).toFixed(3), color: cls.color };
  });
}

function makeLog(imgIdx, annotations) {
  const ts    = new Date().toLocaleTimeString();
  const fname = `img_${String(imgIdx).padStart(4, "0")}.jpg`;
  if (annotations.length === 0)
    return { type: "warning", text: `[${ts}]  ${fname}  →  0 annotations (below threshold)` };
  const detail = annotations.map((a) => `${a.className}: ${a.confidence}`).join("  ·  ");
  return { type: "metric", text: `[${ts}]  ${fname}  →  ${annotations.length} annotation${annotations.length > 1 ? "s" : ""}  (${detail})` };
}

export function useSmartAnnotation() {
  const [phase,   setPhase]   = useState("setup"); // setup | running | complete
  const [config,  setConfig]  = useState(DEFAULT_CONFIG);
  const [processed, setProcessed] = useState(0);
  const [total,     setTotal]     = useState(0);
  const [logs,      setLogs]      = useState([]);
  const [elapsed,   setElapsed]   = useState(0);
  const [results,   setResults]   = useState(null);

  const intervalRef = useRef(null);
  const clockRef    = useRef(null);
  const startRef    = useRef(null);
  const countRef    = useRef(0);
  const allAnnotRef = useRef([]);

  useEffect(() => () => { clearInterval(intervalRef.current); clearInterval(clockRef.current); }, []);

  function updateConfig(field, value) {
    setConfig((p) => ({ ...p, [field]: value }));
  }

  function start() {
    const ds = MOCK_DATASETS.find((d) => d.id === config.datasetId);
    if (!ds) return;
    const n = getTotal(config);
    setTotal(n);
    setProcessed(0);
    setLogs([{ type: "success", text: `[${new Date().toLocaleTimeString()}]  Smart Annotation started — ${n} images · confidence ≥ ${config.confidenceThreshold} · IoU ${config.iouThreshold}` }]);
    setPhase("running");
    setElapsed(0);
    countRef.current    = 0;
    allAnnotRef.current = [];
    startRef.current    = Date.now();

    clockRef.current = setInterval(() => setElapsed(Date.now() - startRef.current), 1000);

    intervalRef.current = setInterval(() => {
      countRef.current += 1;
      const idx         = countRef.current;
      const annotations = mockAnnotations(ds.classes, config.confidenceThreshold);
      allAnnotRef.current.push(...annotations);

      setProcessed(idx);
      setLogs((prev) => [...prev, makeLog(idx, annotations)]);

      if (idx >= n) {
        clearInterval(intervalRef.current);
        clearInterval(clockRef.current);

        // Build results
        const all = allAnnotRef.current;
        const avgConf = all.length > 0
          ? +(all.reduce((s, a) => s + a.confidence, 0) / all.length).toFixed(3)
          : 0;

        const classDist = ds.classes.map((c) => ({
          ...c,
          count: all.filter((a) => a.className === c.alias).length,
        }));

        setResults({ imagesProcessed: n, totalAnnotations: all.length, avgConfidence: avgConf, classDist, duration: Date.now() - startRef.current });
        setPhase("complete");
      }
    }, 120); // ~8 images/sec simulation
  }

  function stop() {
    clearInterval(intervalRef.current);
    clearInterval(clockRef.current);
    setLogs((prev) => [...prev, { type: "warning", text: `[${new Date().toLocaleTimeString()}]  Annotation stopped by user at image ${countRef.current}.` }]);
    setPhase("stopped");
  }

  function reset() {
    clearInterval(intervalRef.current);
    clearInterval(clockRef.current);
    setPhase("setup");
    setProcessed(0);
    setTotal(0);
    setLogs([]);
    setElapsed(0);
    setResults(null);
    countRef.current    = 0;
    allAnnotRef.current = [];
  }

  return {
    phase, config, updateConfig,
    processed, total, logs, elapsed, results,
    start, stop, reset,
  };
}
