"use client";

import { useState, useMemo } from "react";
import { MOCK_SECURITY_SETTINGS } from "@/data/mockUserData";

export function useSecuritySettings() {
  const [settings, setSettings] = useState({ ...MOCK_SECURITY_SETTINGS });
  const [original] = useState({ ...MOCK_SECURITY_SETTINGS });

  const hasChanges = useMemo(() => {
    return JSON.stringify(settings) !== JSON.stringify(original);
  }, [settings, original]);

  function updateSetting(key, value) {
    setSettings((prev) => ({ ...prev, [key]: value }));
  }

  function saveSettings() {
    // no-op — will call API
  }

  return {
    settings,
    updateSetting,
    saveSettings,
    hasChanges,
  };
}
