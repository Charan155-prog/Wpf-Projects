"use client";
import { useCallback, useEffect, useState } from "react";
import { datasetRequest } from "@/utils/datasetApi";
export function useDatasets(training = false) {
  const [datasets, setDatasets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    try { const data = await datasetRequest(training ? "/training/datasets" : "/datasets"); setDatasets(data.datasets || []); setError(""); }
    catch (error) { setError(error.message || "Cannot reach dataset storage."); }
    finally { setLoading(false); }
  }, [training]);
  useEffect(() => {
    const initialFetch = window.setTimeout(refresh, 0);
    window.addEventListener("focus", refresh);
    return () => { window.clearTimeout(initialFetch); window.removeEventListener("focus", refresh); };
  }, [refresh]);
  return { datasets, loading, error, refresh };
}
