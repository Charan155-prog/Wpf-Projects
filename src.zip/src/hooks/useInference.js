"use client";

import { useRef, useState } from "react";

// ─── Mock WebSocket simulation ────────────────────────────────────────────────
// In production: replace startMockSocket() with a real WebSocket connection.
// Backend sends: { type: "frame", imageUrl, detections, frameIdx, total, ms }
// Frontend just renders whatever it receives.

const MOCK_SEEDS = [
  "inf01","inf02","inf03","inf04","inf05","inf06","inf07","inf08","inf09","inf10",
  "inf11","inf12","inf13","inf14","inf15","inf16","inf17","inf18","inf19","inf20",
];

const rnd = (a, b) => +(a + Math.random() * (b - a)).toFixed(3);

function mockDetections(classes, conf) {
  const n = Math.floor(Math.random() * 4);
  return Array.from({ length: n }, (_, i) => {
    const cls = classes[i % classes.length];
    return {
      id:         `d${i}`,
      alias:      cls.alias,
      color:      cls.color,
      confidence: +(conf + Math.random() * (1 - conf) * 0.85).toFixed(3),
      x: rnd(0.04, 0.52), y: rnd(0.04, 0.40),
      w: rnd(0.12, 0.38), h: rnd(0.12, 0.36),
    };
  }).filter((d) => d.confidence >= conf);
}

const DEFAULT_CONFIG = {
  modelId:             "",
  confidenceThreshold: 0.50,
  iouThreshold:        0.45,
};

export function useInference() {
  const [phase,           setPhase]           = useState("idle"); // idle | running | done | stopped
  const [folderPath,      setFolderPath]      = useState("");
  const [config,          setConfig]          = useState(DEFAULT_CONFIG);
  const [currentFrame,    setCurrentFrame]    = useState(null);
  const [processedFrames, setProcessedFrames] = useState([]);
  const [totalFrames,     setTotalFrames]     = useState(0);

  const socketRef = useRef(null);

  function updateConfig(field, value) {
    setConfig((p) => ({ ...p, [field]: value }));
  }

  // Start inference — in production this opens a real WebSocket to the backend
  function start(classes) {
    if (!folderPath.trim() || phase === "running") return;

    const total = MOCK_SEEDS.length;
    setTotalFrames(total);
    setCurrentFrame(null);
    setProcessedFrames([]);
    setPhase("running");

    let idx = 0;

    // Simulate WebSocket messages arriving from backend
    socketRef.current = setInterval(() => {
      const seed       = MOCK_SEEDS[idx];
      const imageUrl   = `https://picsum.photos/seed/${seed}/800/600`;
      const detections = mockDetections(classes, config.confidenceThreshold);
      const ms         = Math.floor(18 + Math.random() * 40);

      const frame = { id: `f_${idx}`, imageUrl, detections, frameIdx: idx + 1, total, ms };

      setCurrentFrame(frame);
      setProcessedFrames((prev) => [...prev, frame]);

      idx += 1;
      if (idx >= total) {
        clearInterval(socketRef.current);
        setPhase("done");
      }
    }, 500); // simulate ~500ms per frame
  }

  function stop() {
    clearInterval(socketRef.current);
    setPhase("stopped");
  }

  function reset() {
    clearInterval(socketRef.current);
    setCurrentFrame(null);
    setProcessedFrames([]);
    setTotalFrames(0);
    setPhase("idle");
  }

  const stats = {
    processed:  processedFrames.length,
    total:      totalFrames,
    detections: processedFrames.reduce((s, f) => s + f.detections.length, 0),
    avgMs:      processedFrames.length
      ? Math.round(processedFrames.reduce((s, f) => s + f.ms, 0) / processedFrames.length)
      : 0,
  };

  return {
    phase, folderPath, setFolderPath,
    config, updateConfig,
    currentFrame, processedFrames, stats,
    start, stop, reset,
  };
}
