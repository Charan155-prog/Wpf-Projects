"use client";

import { useEffect, useRef, useState } from "react";

const ARCHITECTURES  = ["YOLOv8n", "YOLOv8s", "YOLOv8m", "YOLOv8l", "YOLOv8x"];
const OPTIMIZERS     = ["SGD", "Adam", "AdamW"];

export { ARCHITECTURES, OPTIMIZERS };

const DEFAULT_CONFIG = {
  // shared
  datasetId:    "",
  epochs:       100,
  batchSize:    16,
  imageSize:    640,
  learningRate: 0.01,
  optimizer:    "SGD",
  // normal training
  architecture: "YOLOv8n",
  pretrained:   true,
  // incremental
  baseModelId:  "",
  freezeLayers: 10,
};

function generateEpochMetrics(epoch, total) {
  const p   = epoch / total;
  const n   = () => (Math.random() - 0.5) * 0.04;
  return {
    epoch,
    trainLoss: Math.max(0.04, 1.3  * Math.exp(-4   * p) + 0.09 + n()),
    valLoss:   Math.max(0.07, 1.55 * Math.exp(-3.2 * p) + 0.13 + n()),
    mAP50:     Math.min(0.97, 0.28 + 0.68 * (1 - Math.exp(-5 * p)) + n() * 0.4),
    precision: Math.min(0.98, 0.38 + 0.58 * (1 - Math.exp(-4 * p)) + n() * 0.3),
    recall:    Math.min(0.96, 0.32 + 0.62 * (1 - Math.exp(-4 * p)) + n() * 0.3),
  };
}

function makeLog(epoch, total, m) {
  const ts  = new Date().toLocaleTimeString();
  const pct = ((epoch / total) * 100).toFixed(0);
  return [
    { type: "info",    text: `[${ts}] Epoch ${epoch}/${total}  (${pct}%)` },
    { type: "metric",  text: `          train_loss: ${m.trainLoss.toFixed(4)}   val_loss: ${m.valLoss.toFixed(4)}` },
    { type: "metric",  text: `          mAP50: ${m.mAP50.toFixed(4)}   precision: ${m.precision.toFixed(4)}   recall: ${m.recall.toFixed(4)}` },
  ];
}

export function useTraining() {
  const [phase,   setPhase]   = useState("setup");  // setup | training | complete | stopped
  const [mode,    setMode]    = useState("normal");  // normal | incremental
  const [config,  setConfig]  = useState(DEFAULT_CONFIG);
  const [metrics, setMetrics] = useState({ epochs: [], trainLoss: [], valLoss: [], mAP50: [], precision: [], recall: [] });
  const [logs,    setLogs]    = useState([]);
  const [currentEpoch, setCurrentEpoch] = useState(0);
  const [startTime,    setStartTime]    = useState(null);
  const [elapsed,      setElapsed]      = useState(0);

  const intervalRef = useRef(null);
  const clockRef    = useRef(null);
  const epochRef    = useRef(0);

  // Elapsed clock
  useEffect(() => {
    if (phase !== "training") { clearInterval(clockRef.current); return; }
    clockRef.current = setInterval(() => setElapsed(Date.now() - startTime), 1000);
    return () => clearInterval(clockRef.current);
  }, [phase, startTime]);

  // Cleanup on unmount
  useEffect(() => () => { clearInterval(intervalRef.current); clearInterval(clockRef.current); }, []);

  function updateConfig(field, value) {
    setConfig((prev) => ({ ...prev, [field]: value }));
  }

  function startTraining() {
    const total = config.epochs;
    epochRef.current = 0;
    setPhase("training");
    setStartTime(Date.now());
    setElapsed(0);
    setCurrentEpoch(0);
    setMetrics({ epochs: [], trainLoss: [], valLoss: [], mAP50: [], precision: [], recall: [] });
    setLogs([{ type: "success", text: `[${new Date().toLocaleTimeString()}] Training started — ${mode === "normal" ? config.architecture : "Incremental"} | ${total} epochs | batch ${config.batchSize} | img ${config.imageSize}` }]);

    intervalRef.current = setInterval(() => {
      epochRef.current += 1;
      const epoch = epochRef.current;
      const m     = generateEpochMetrics(epoch, total);

      setCurrentEpoch(epoch);
      setMetrics((prev) => ({
        epochs:    [...prev.epochs,    epoch],
        trainLoss: [...prev.trainLoss, m.trainLoss],
        valLoss:   [...prev.valLoss,   m.valLoss],
        mAP50:     [...prev.mAP50,     m.mAP50],
        precision: [...prev.precision, m.precision],
        recall:    [...prev.recall,    m.recall],
      }));
      setLogs((prev) => [...prev, ...makeLog(epoch, total, m)]);

      if (epoch >= total) {
        clearInterval(intervalRef.current);
        setPhase("complete");
      }
    }, 600); // 600ms per epoch for demo — replace with backend SSE/WebSocket
  }

  function stopTraining() {
    clearInterval(intervalRef.current);
    setPhase("stopped");
    setLogs((prev) => [...prev, { type: "warning", text: `[${new Date().toLocaleTimeString()}] Training stopped by user at epoch ${epochRef.current}.` }]);
  }

  function reset() {
    clearInterval(intervalRef.current);
    setPhase("setup");
    setMetrics({ epochs: [], trainLoss: [], valLoss: [], mAP50: [], precision: [], recall: [] });
    setLogs([]);
    setCurrentEpoch(0);
    setElapsed(0);
    epochRef.current = 0;
  }

  const bestEpochIdx = metrics.mAP50.length
    ? metrics.mAP50.indexOf(Math.max(...metrics.mAP50))
    : -1;

  const bestMetrics = bestEpochIdx >= 0 ? {
    epoch:     metrics.epochs[bestEpochIdx],
    mAP50:     metrics.mAP50[bestEpochIdx],
    trainLoss: metrics.trainLoss[bestEpochIdx],
    valLoss:   metrics.valLoss[bestEpochIdx],
    precision: metrics.precision[bestEpochIdx],
    recall:    metrics.recall[bestEpochIdx],
  } : null;

  return {
    phase, mode, setMode,
    config, updateConfig,
    metrics, logs,
    currentEpoch, totalEpochs: config.epochs,
    elapsed, bestMetrics,
    startTraining, stopTraining, reset,
  };
}
