"use client";

import { useState, useMemo } from "react";
import { MOCK_PERMISSIONS } from "@/data/mockUserData";

function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

export function usePermissions() {
  const [permissions, setPermissions] = useState(deepClone(MOCK_PERMISSIONS));
  const [original] = useState(deepClone(MOCK_PERMISSIONS));

  const hasChanges = useMemo(
    () => JSON.stringify(permissions) !== JSON.stringify(original),
    [permissions, original]
  );

  function togglePermission(role, group, key) {
    if (role === "Admin") return;

    setPermissions((prev) => {
      const next = deepClone(prev);
      const newVal = !next[role][group][key];
      next[role][group][key] = newVal;

      // Cascade up: Technician ON → Operator must also be ON
      if (role === "Technician" && newVal === true) {
        next["Operator"][group][key] = true;
      }

      // Cascade down: Operator OFF → Technician must also be OFF
      if (role === "Operator" && newVal === false) {
        next["Technician"][group][key] = false;
      }

      return next;
    });
  }

  function savePermissions() {
    // will call API
  }

  return {
    permissions,
    togglePermission,
    savePermissions,
    hasChanges,
  };
}
