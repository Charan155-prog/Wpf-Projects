// Deterministic seeded LCG — avoids SSR/client hydration mismatch
function lcg(seed) {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(1664525, s) + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

function makeLoss(rng, n, from, to) {
  return Array.from({ length: n }, (_, i) => {
    const t = i / (n - 1);
    const base = from * Math.exp(-t * 4) + to;
    return +(base * (1 + (rng() - 0.5) * 0.12)).toFixed(4);
  });
}

function makeMAP(rng, n, target) {
  return Array.from({ length: n }, (_, i) => {
    const t = i / (n - 1);
    const base = target * (1 - Math.exp(-t * 5));
    return +Math.min(0.999, Math.max(0, base + (rng() - 0.5) * 0.016 * (1 - t * 0.7))).toFixed(4);
  });
}

export const MOCK_MODELS = [
  // ── proj_cap_inspection ──────────────────────────────────────────────────────
  {
    id: "mdl_001",
    name: "CDI-Detector",
    version: "2.1.0",
    projectId: "proj_cap_inspection",
    projectName: "Bottle Cap Inspection",
    architecture: "YOLOv8s",
    status: "ready",
    isDeployed: true,
    trainedAt: "2025-04-12",
    config: { epochs: 80, imageSize: 640, batchSize: 16, optimizer: "AdamW", dataset: "Cap Defects v3", baseModel: null },
    metrics: { mAP50: 0.923, mAP5095: 0.748, precision: 0.901, recall: 0.878, f1: 0.889 },
    classMetrics: [
      { name: "Good Cap",     color: "#22c55e", mAP50: 0.951, precision: 0.934, recall: 0.921 },
      { name: "Crack",        color: "#ef4444", mAP50: 0.912, precision: 0.889, recall: 0.876 },
      { name: "Flash",        color: "#f59e0b", mAP50: 0.897, precision: 0.875, recall: 0.854 },
      { name: "Print Missing",color: "#6366f1", mAP50: 0.931, precision: 0.908, recall: 0.861 },
    ],
    size: 22.4,
    inferenceMs: 23,
    trainLoss:    makeLoss(lcg(1001), 80, 3.2, 0.18),
    valLoss:      makeLoss(lcg(1002), 80, 3.4, 0.22),
    mAP50History: makeMAP(lcg(1003),  80, 0.923),
    exports: ["pt"],
  },
  {
    id: "mdl_002",
    name: "CDI-Detector",
    version: "1.8.0",
    projectId: "proj_cap_inspection",
    projectName: "Bottle Cap Inspection",
    architecture: "YOLOv8n",
    status: "ready",
    isDeployed: false,
    trainedAt: "2025-02-28",
    config: { epochs: 100, imageSize: 640, batchSize: 32, optimizer: "SGD", dataset: "Cap Defects v2", baseModel: null },
    metrics: { mAP50: 0.891, mAP5095: 0.701, precision: 0.867, recall: 0.843, f1: 0.855 },
    classMetrics: [
      { name: "Good Cap",     color: "#22c55e", mAP50: 0.921, precision: 0.908, recall: 0.891 },
      { name: "Crack",        color: "#ef4444", mAP50: 0.878, precision: 0.851, recall: 0.832 },
      { name: "Flash",        color: "#f59e0b", mAP50: 0.862, precision: 0.845, recall: 0.812 },
      { name: "Print Missing",color: "#6366f1", mAP50: 0.903, precision: 0.863, recall: 0.837 },
    ],
    size: 6.2,
    inferenceMs: 11,
    trainLoss:    makeLoss(lcg(2001), 100, 3.0, 0.21),
    valLoss:      makeLoss(lcg(2002), 100, 3.2, 0.26),
    mAP50History: makeMAP(lcg(2003),  100, 0.891),
    exports: ["pt", "onnx"],
  },
  {
    id: "mdl_003",
    name: "CDI-Detector",
    version: "1.5.0",
    projectId: "proj_cap_inspection",
    projectName: "Bottle Cap Inspection",
    architecture: "YOLOv8n",
    status: "archived",
    isDeployed: false,
    trainedAt: "2024-12-10",
    config: { epochs: 80, imageSize: 640, batchSize: 32, optimizer: "SGD", dataset: "Cap Defects v1", baseModel: null },
    metrics: { mAP50: 0.834, mAP5095: 0.658, precision: 0.812, recall: 0.791, f1: 0.801 },
    classMetrics: [
      { name: "Good Cap",     color: "#22c55e", mAP50: 0.862, precision: 0.841, recall: 0.821 },
      { name: "Crack",        color: "#ef4444", mAP50: 0.824, precision: 0.803, recall: 0.781 },
      { name: "Flash",        color: "#f59e0b", mAP50: 0.811, precision: 0.792, recall: 0.771 },
      { name: "Print Missing",color: "#6366f1", mAP50: 0.839, precision: 0.813, recall: 0.791 },
    ],
    size: 6.1,
    inferenceMs: 10,
    trainLoss:    makeLoss(lcg(3001), 80, 2.9, 0.24),
    valLoss:      makeLoss(lcg(3002), 80, 3.1, 0.29),
    mAP50History: makeMAP(lcg(3003),  80, 0.834),
    exports: ["pt", "onnx"],
  },

  // ── proj_label_alignment ──────────────────────────────────────────────────────
  {
    id: "mdl_004",
    name: "Label-Net",
    version: "1.0.0",
    projectId: "proj_label_alignment",
    projectName: "Label Alignment",
    architecture: "YOLOv8m",
    status: "ready",
    isDeployed: true,
    trainedAt: "2025-03-20",
    config: { epochs: 120, imageSize: 1280, batchSize: 8, optimizer: "AdamW", dataset: "Label Dataset v1", baseModel: null },
    metrics: { mAP50: 0.876, mAP5095: 0.712, precision: 0.852, recall: 0.831, f1: 0.841 },
    classMetrics: [
      { name: "Aligned", color: "#22c55e", mAP50: 0.921, precision: 0.904, recall: 0.889 },
      { name: "Skew",    color: "#f59e0b", mAP50: 0.843, precision: 0.819, recall: 0.798 },
      { name: "Wrinkle", color: "#ef4444", mAP50: 0.864, precision: 0.831, recall: 0.806 },
    ],
    size: 52.0,
    inferenceMs: 41,
    trainLoss:    makeLoss(lcg(4001), 120, 2.8, 0.20),
    valLoss:      makeLoss(lcg(4002), 120, 3.0, 0.26),
    mAP50History: makeMAP(lcg(4003),  120, 0.876),
    exports: ["pt", "onnx", "tensorrt"],
  },

  // ── proj_tablet_surface ───────────────────────────────────────────────────────
  {
    id: "mdl_005",
    name: "Tablet-QC",
    version: "3.2.0",
    projectId: "proj_tablet_surface",
    projectName: "Tablet Surface Defects",
    architecture: "YOLOv8l",
    status: "ready",
    isDeployed: true,
    trainedAt: "2025-04-28",
    config: { epochs: 200, imageSize: 640, batchSize: 8, optimizer: "AdamW", dataset: "Tablet Defects v5", baseModel: "mdl_006" },
    metrics: { mAP50: 0.944, mAP5095: 0.791, precision: 0.921, recall: 0.903, f1: 0.912 },
    classMetrics: [
      { name: "Clean",         color: "#22c55e", mAP50: 0.967, precision: 0.951, recall: 0.938 },
      { name: "Edge Chip",     color: "#ef4444", mAP50: 0.938, precision: 0.914, recall: 0.897 },
      { name: "Dark Spot",     color: "#8b5cf6", mAP50: 0.931, precision: 0.908, recall: 0.884 },
      { name: "Surface Crack", color: "#f97316", mAP50: 0.939, precision: 0.911, recall: 0.893 },
    ],
    size: 87.5,
    inferenceMs: 63,
    trainLoss:    makeLoss(lcg(5001), 200, 3.5, 0.15),
    valLoss:      makeLoss(lcg(5002), 200, 3.7, 0.19),
    mAP50History: makeMAP(lcg(5003),  200, 0.944),
    exports: ["pt"],
  },
  {
    id: "mdl_006",
    name: "Tablet-QC",
    version: "2.0.0",
    projectId: "proj_tablet_surface",
    projectName: "Tablet Surface Defects",
    architecture: "YOLOv8s",
    status: "ready",
    isDeployed: false,
    trainedAt: "2025-03-05",
    config: { epochs: 100, imageSize: 640, batchSize: 16, optimizer: "AdamW", dataset: "Tablet Defects v3", baseModel: null },
    metrics: { mAP50: 0.891, mAP5095: 0.718, precision: 0.869, recall: 0.847, f1: 0.858 },
    classMetrics: [
      { name: "Clean",         color: "#22c55e", mAP50: 0.921, precision: 0.908, recall: 0.891 },
      { name: "Edge Chip",     color: "#ef4444", mAP50: 0.878, precision: 0.852, recall: 0.831 },
      { name: "Dark Spot",     color: "#8b5cf6", mAP50: 0.871, precision: 0.848, recall: 0.823 },
      { name: "Surface Crack", color: "#f97316", mAP50: 0.894, precision: 0.868, recall: 0.843 },
    ],
    size: 22.3,
    inferenceMs: 24,
    trainLoss:    makeLoss(lcg(6001), 100, 3.1, 0.20),
    valLoss:      makeLoss(lcg(6002), 100, 3.3, 0.25),
    mAP50History: makeMAP(lcg(6003),  100, 0.891),
    exports: ["pt", "onnx"],
  },

  // ── proj_pcb (extra project for variety) ────────────────────────────────────
  {
    id: "mdl_007",
    name: "PCB-Inspector",
    version: "0.9.0",
    projectId: "proj_pcb",
    projectName: "PCB Inspection",
    architecture: "YOLOv8s",
    status: "training",
    isDeployed: false,
    trainedAt: "2025-05-08",
    config: { epochs: 150, imageSize: 640, batchSize: 16, optimizer: "AdamW", dataset: "PCB Defects v1", baseModel: null },
    metrics: { mAP50: 0.721, mAP5095: 0.541, precision: 0.698, recall: 0.674, f1: 0.686 },
    classMetrics: [
      { name: "Missing Component", color: "#ef4444", mAP50: 0.768, precision: 0.741, recall: 0.712 },
      { name: "Solder Bridge",     color: "#f59e0b", mAP50: 0.698, precision: 0.672, recall: 0.651 },
      { name: "Lifted Pad",        color: "#3b82f6", mAP50: 0.697, precision: 0.681, recall: 0.659 },
    ],
    size: 22.3,
    inferenceMs: 24,
    trainLoss:    makeLoss(lcg(7001), 70, 3.1, 0.45),
    valLoss:      makeLoss(lcg(7002), 70, 3.3, 0.52),
    mAP50History: makeMAP(lcg(7003),  70, 0.721),
    exports: [],
  },
];
